var a = [{a:1},{b:1},{c:1}]
var b = a.concat()
b.pop()
console.log(a)
console.log(b)