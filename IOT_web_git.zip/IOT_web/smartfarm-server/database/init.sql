CREATE SCHEMA application;

CREATE TABLE application.audit_log (
	id                   serial  NOT NULL,
	user_id              integer   ,
	user_name            varchar(100)   ,
	entity_id            integer   ,
	entity_type          integer   ,
	entity_name          varchar(100)   ,
	action_type          integer   ,
	action_data          varchar(10000)   ,
	action_status        integer   ,
	action_failure_details varchar(10000)   ,
	audit_time           timestamp DEFAULT ('now'::text)::timestamp without time zone NOT NULL ,
	CONSTRAINT pk_audit_log_id PRIMARY KEY ( id )
 );

COMMENT ON TABLE application.audit_log IS '审计日志';

COMMENT ON COLUMN application.audit_log.user_id IS '操作用户id';

COMMENT ON COLUMN application.audit_log.user_name IS '操作用户名';

COMMENT ON COLUMN application.audit_log.entity_id IS '操作对象id';

COMMENT ON COLUMN application.audit_log.entity_type IS '操作对象类型';

COMMENT ON COLUMN application.audit_log.entity_name IS '操作对象名称';

COMMENT ON COLUMN application.audit_log.action_type IS '操作类型';

COMMENT ON COLUMN application.audit_log.action_data IS '操作数据';

COMMENT ON COLUMN application.audit_log.action_status IS '操作结果';

COMMENT ON COLUMN application.audit_log.action_failure_details IS '操作失败详情';

COMMENT ON COLUMN application.audit_log.audit_time IS '时间';

CREATE TABLE application.base_piggy_info (
	id                   serial  NOT NULL ,
	earcard              varchar(20)   ,
	individual           varchar(20)   ,
	status               varchar(20)   ,
	statusdate           date   ,
	piggery              varchar(20)   ,
	piggeryname          varchar(100)   ,
	CONSTRAINT pk_humu_piggy_id PRIMARY KEY ( id )
 );

COMMENT ON TABLE application.base_piggy_info IS '猪只基础数据, 从原系统导出(互牧)';

CREATE TABLE application."dictionary" (
	id                   serial  NOT NULL ,
	dic_cat              integer   ,
	dic_code             integer   ,
	dic_value            varchar(50)   ,
	CONSTRAINT pk_disease_type_id PRIMARY KEY ( id )
 );

COMMENT ON TABLE application."dictionary" IS '数据字典';

COMMENT ON COLUMN application."dictionary".dic_cat IS '分类';

COMMENT ON COLUMN application."dictionary".dic_code IS '编号';

COMMENT ON COLUMN application."dictionary".dic_value IS '值';

CREATE TABLE application.environment (
	id                   serial  NOT NULL ,
	env_temp             numeric   ,
	env_humidity         numeric   ,
	record_time          timestamp DEFAULT ('now'::text)::timestamp without time zone NOT NULL ,
	CONSTRAINT pk_environment_id PRIMARY KEY ( id )
 );

COMMENT ON TABLE application.environment IS '环境信息';

COMMENT ON COLUMN application.environment.env_temp IS '环境温度';

COMMENT ON COLUMN application.environment.env_humidity IS '环境湿度';

COMMENT ON COLUMN application.environment.record_time IS '记录时间';

CREATE TABLE application.gateway (
	id                   serial  NOT NULL ,
	name                 varchar(50)  NOT NULL ,
	sn                   varchar(20)  NOT NULL ,
	status               integer   ,
	updated_at           timestamp DEFAULT ('now'::text)::timestamp without time zone NOT NULL ,
	created_at           timestamp DEFAULT ('now'::text)::timestamp without time zone NOT NULL ,
	longitude            integer   ,
	latitude             integer   ,
	CONSTRAINT pk_gateway_id PRIMARY KEY ( id )
 );

COMMENT ON TABLE application.gateway IS '网关信息';

COMMENT ON COLUMN application.gateway.name IS '网关名称';

COMMENT ON COLUMN application.gateway.sn IS '网关序列号';

COMMENT ON COLUMN application.gateway.status IS '网关状态:离线0,在线1';

COMMENT ON COLUMN application.gateway.updated_at IS '更新时间';

COMMENT ON COLUMN application.gateway.created_at IS '创建时间';

COMMENT ON COLUMN application.gateway.longitude IS '网关位置_x';

COMMENT ON COLUMN application.gateway.latitude IS '网关位置_y';

CREATE TABLE application.manager (
	id                   serial  NOT NULL ,
	job_number           varchar(20)   ,
	post                 integer   ,
	phone                varchar(20)   ,
	created_at           timestamp DEFAULT ('now'::text)::timestamp without time zone NOT NULL ,
	updated_at           timestamp DEFAULT ('now'::text)::timestamp without time zone NOT NULL ,
	name                 varchar(100)   ,
	CONSTRAINT pk_keeper_id PRIMARY KEY ( id )
 );

COMMENT ON TABLE application.manager IS '负责人信息';

COMMENT ON COLUMN application.manager.job_number IS '工号';

COMMENT ON COLUMN application.manager.post IS '岗位';

COMMENT ON COLUMN application.manager.phone IS '手机号';

COMMENT ON COLUMN application.manager.created_at IS '创建时间';

COMMENT ON COLUMN application.manager.updated_at IS '更新时间';

COMMENT ON COLUMN application.manager.name IS '负责人名称';

CREATE TABLE application.node (
	id                   serial  NOT NULL ,
	sn                   varchar(20)  NOT NULL ,
	gateway_id           integer   ,
	gateway_name         varchar(100)   ,
	status               integer  NOT NULL ,
	created_at           timestamp DEFAULT ('now'::text)::timestamp without time zone NOT NULL ,
	updated_at           timestamp DEFAULT ('now'::text)::timestamp without time zone NOT NULL ,
	name                 varchar(50)   ,
	CONSTRAINT pk_node_id PRIMARY KEY ( id )
 );

COMMENT ON TABLE application.node IS '耳标（秒秒测）';

COMMENT ON COLUMN application.node.sn IS '秒秒测序列号';

COMMENT ON COLUMN application.node.gateway_id IS '网关id';

COMMENT ON COLUMN application.node.gateway_name IS '网关序列号';

COMMENT ON COLUMN application.node.status IS '节点状态: 0 离线, 1 在线';

COMMENT ON COLUMN application.node.created_at IS '创建时间';

COMMENT ON COLUMN application.node.updated_at IS '更新时间';

COMMENT ON COLUMN application.node.name IS '秒秒测名称';

CREATE TABLE application.npmap (
	id                   serial  NOT NULL ,
	earcard              varchar(20)   ,
	sn                   varchar(20)   ,
	created_at           date DEFAULT CURRENT_DATE  ,
	updated_at           date DEFAULT CURRENT_DATE  ,
	CONSTRAINT pk_npmap_id PRIMARY KEY ( id )
 );

COMMENT ON TABLE application.npmap IS '猪只耳号和mmc编号mapping关系';

COMMENT ON COLUMN application.npmap.earcard IS '猪只耳标号';

CREATE TABLE application.piggy (
	id                   serial  NOT NULL ,
	earcard              varchar   ,
	node_id              integer   ,
	alarm_status         integer DEFAULT 0 NOT NULL ,
	period_status        integer   ,
	imported_period_status char(20)   ,
	individual           varchar(20)   ,
	period_status_date   timestamp   ,
	pigsty_id            integer   ,
	created_at           timestamp DEFAULT ('now'::text)::timestamp without time zone NOT NULL ,
	updated_at           timestamp DEFAULT ('now'::text)::timestamp without time zone NOT NULL ,
	curr_temp            numeric  ,
	abs_temp             numeric   ,
	dod_temp             numeric  ,
	pop_temp             numeric  ,
	alarm_at             timestamp   ,
	disease_type         integer   ,
	entire               integer   ,
	CONSTRAINT pk_piggy_id PRIMARY KEY ( id )
 );

COMMENT ON TABLE application.piggy IS '猪只信息';

COMMENT ON COLUMN application.piggy.earcard IS '猪只耳标号, 从互牧系统导入';

COMMENT ON COLUMN application.piggy.node_id IS '秒秒测id';

COMMENT ON COLUMN application.piggy.alarm_status IS '猪只告警状态: 0正常, 1体温异常, 2报警, 3疾病';

COMMENT ON COLUMN application.piggy.period_status IS '猪只周期状态: 0后备期, 1妊娠期, 2分娩哺乳期, 3空怀期';

COMMENT ON COLUMN application.piggy.imported_period_status IS '猪只周期状态, 从互牧系统导入';

COMMENT ON COLUMN application.piggy.individual IS '个体号, 从互牧系统导入';

COMMENT ON COLUMN application.piggy.period_status_date IS '猪只当前周期开始时间, 从互牧系统导入';

COMMENT ON COLUMN application.piggy.pigsty_id IS '猪舍id';

COMMENT ON COLUMN application.piggy.created_at IS '创建时间';

COMMENT ON COLUMN application.piggy.updated_at IS '更新时间';

COMMENT ON COLUMN application.piggy.curr_temp IS '当前温度';

COMMENT ON COLUMN application.piggy.abs_temp IS '绝对温差值';

COMMENT ON COLUMN application.piggy.dod_temp IS '同比温差值';

COMMENT ON COLUMN application.piggy.pop_temp IS '环比温差值';

COMMENT ON COLUMN application.piggy.alarm_at IS '预警时间';

COMMENT ON COLUMN application.piggy.disease_type IS '疾病类型';

COMMENT ON COLUMN application.piggy.entire IS '全部';

CREATE TABLE application.pigsty (
	id                   serial  NOT NULL ,
	sn                   varchar(20)   ,
	name                 varchar(100)   ,
	created_at           timestamp DEFAULT ('now'::text)::timestamp without time zone NOT NULL ,
	updated_at           timestamp DEFAULT ('now'::text)::timestamp without time zone NOT NULL ,
	header_id            integer   ,
	width                integer   ,
	high                 integer   ,
	CONSTRAINT pk_pigsty_id PRIMARY KEY ( id )
 );

COMMENT ON TABLE application.pigsty IS '猪舍信息';

COMMENT ON COLUMN application.pigsty.sn IS '猪舍编号, 从互牧系统导入';

COMMENT ON COLUMN application.pigsty.name IS '猪舍名称';

COMMENT ON COLUMN application.pigsty.created_at IS '创建时间';

COMMENT ON COLUMN application.pigsty.updated_at IS '更新时间';

COMMENT ON COLUMN application.pigsty.header_id IS '负责人id';

COMMENT ON COLUMN application.pigsty.width IS '猪圈长度_x';

COMMENT ON COLUMN application.pigsty.high IS '猪圈坐标高_y';

CREATE TABLE application.settings (
	id                   serial  NOT NULL ,
	setting_code         varchar(50)   ,
	setting_value        varchar(100)   ,
	CONSTRAINT pk_system_settings_id PRIMARY KEY ( id )
 );

COMMENT ON TABLE application.settings IS '系统设置';

COMMENT ON COLUMN application.settings.setting_code IS '代码';

COMMENT ON COLUMN application.settings.setting_value IS '值';

CREATE VIEW application.node_piggy_view AS  SELECT node.sn AS node_sn,
    node.gateway_id,
	  node.gateway_name,
    node.status AS node_status,
    node.name AS node_name,
    piggy.id AS piggy_id,
    piggy.earcard,
    piggy.alarm_status,
    piggy.period_status,
    piggy.pigsty_id,
    piggy.curr_temp,
    piggy.abs_temp,
    piggy.dod_temp,
    piggy.pop_temp,
    piggy.entire,
    piggy.alarm_at,
    piggy.disease_type
   FROM application.node,
    application.piggy
  WHERE (node.id = piggy.node_id);

CREATE TABLE application.pigstymap
(
    id              serial  NOT NULL ,
    gateway_id      integer,
    point_x         integer,
    point_y         integer,
    pigsty_id       integer,
    CONSTRAINT pk_pigstymap_id PRIMARY KEY ( id )
);

INSERT INTO application."dictionary"( id, dic_cat, dic_code, dic_value ) VALUES ( 1, 100, 1, '消化道疾病' );
INSERT INTO application."dictionary"( id, dic_cat, dic_code, dic_value ) VALUES ( 2, 100, 2, '皮肤病' );
INSERT INTO application."dictionary"( id, dic_cat, dic_code, dic_value ) VALUES ( 3, 100, 3, '生殖系统疾病' );
INSERT INTO application."dictionary"( id, dic_cat, dic_code, dic_value ) VALUES ( 4, 100, 4, '不明发热' );
INSERT INTO application."dictionary"( id, dic_cat, dic_code, dic_value ) VALUES ( 5, 100, 5, '——' );
INSERT INTO application."dictionary"( id, dic_cat, dic_code, dic_value ) VALUES ( 6, 101, 0, '后备期' );
INSERT INTO application."dictionary"( id, dic_cat, dic_code, dic_value ) VALUES ( 7, 101, 1, '妊娠期' );
INSERT INTO application."dictionary"( id, dic_cat, dic_code, dic_value ) VALUES ( 8, 101, 2, '分娩哺乳期' );
INSERT INTO application."dictionary"( id, dic_cat, dic_code, dic_value ) VALUES ( 9, 101, 3, '空怀期' );
INSERT INTO application."dictionary"( id, dic_cat, dic_code, dic_value ) VALUES ( 10, 102, 1, '应激' );
INSERT INTO application."dictionary"( id, dic_cat, dic_code, dic_value ) VALUES ( 11, 102, 2, '打架' );

INSERT INTO application.settings( id, setting_code, setting_value ) VALUES ( 4, 'alarm_pop_low_temp_diff', '1.0' );
INSERT INTO application.settings( id, setting_code, setting_value ) VALUES ( 5, 'alarm_pop_high_temp_diff', '2' );
INSERT INTO application.settings( id, setting_code, setting_value ) VALUES ( 10, 'pigsty_boundary', 'sameGateway' );
INSERT INTO application.settings( id, setting_code, setting_value ) VALUES ( 9, 'report_interval', '15' );
INSERT INTO application.settings( id, setting_code, setting_value ) VALUES ( 0, 'alarm_abs_low_temp_diff', '0.5' );
INSERT INTO application.settings( id, setting_code, setting_value ) VALUES ( 1, 'alarm_abs_high_temp_diff', '1.5' );
INSERT INTO application.settings( id, setting_code, setting_value ) VALUES ( 3, 'alarm_dod_high_temp_diff', '1.5' );
INSERT INTO application.settings( id, setting_code, setting_value ) VALUES ( 2, 'alarm_dod_low_temp_diff', '1' );
INSERT INTO application.settings( id, setting_code, setting_value ) VALUES ( 7, 'alarm_warning_count', '2' );
INSERT INTO application.settings( id, setting_code, setting_value ) VALUES ( 8, 'alarm_error_count', '3' );
INSERT INTO application.settings( id, setting_code, setting_value ) VALUES ( 6, 'alarm_info_count', '9' );

ALTER TABLE application.piggy DROP COLUMN disease_type cascade;

ALTER TABLE application.piggy
    ADD COLUMN investigate character varying ;
COMMENT ON COLUMN application.piggy.investigate
    IS '排查诊断';

ALTER TABLE application.piggy
    ADD COLUMN measures character varying ;
COMMENT ON COLUMN application.piggy.measures
    IS '采取措施';

ALTER TABLE application.piggy
    ADD COLUMN disease_type character varying ;
COMMENT ON COLUMN application.piggy.disease_type
    IS '疾病类型';

ALTER TABLE application.piggy
    ADD COLUMN com_invest character varying ;
COMMENT ON COLUMN application.piggy.com_invest
    IS '描述-排查诊断';

ALTER TABLE application.piggy
    ADD COLUMN com_meas character varying ;
COMMENT ON COLUMN application.piggy.com_meas
    IS '描述-采取措施';

ALTER TABLE application.piggy
    ADD COLUMN com_disease character varying ;
COMMENT ON COLUMN application.piggy.com_disease
    IS '描述-疾病类型';

/*删除部分常量*/
delete from application.dictionary where dic_cat in (100,102);

CREATE OR REPLACE VIEW application.node_piggy_view AS
SELECT node.sn AS node_sn,
  node.gateway_id,
  node.gateway_name,
  node.status AS node_status,
  node.name AS node_name,
  piggy.id AS piggy_id,
  piggy.earcard,
  piggy.alarm_status,
  piggy.period_status,
  piggy.pigsty_id,
  piggy.curr_temp,
  piggy.abs_temp,
  piggy.dod_temp,
  piggy.pop_temp,
  piggy.entire,
  piggy.alarm_at,
  piggy.investigate,
  piggy.measures,
  piggy.disease_type,
  piggy.com_invest,
  piggy.com_meas,
  piggy.com_disease
 FROM application.node,
  application.piggy
WHERE node.id = piggy.node_id;
ALTER TABLE application.node_piggy_view
    OWNER TO postgres;

/*删除部分常量*/
delete from application.dictionary where dic_cat in (100,102)

/*删除多余表字段*/
ALTER TABLE application.gateway DROP COLUMN longitude;
ALTER TABLE application.gateway DROP COLUMN latitude;

ALTER TABLE application.piggy ADD detected_at date;
COMMENT ON COLUMN application.piggy.detected_at IS '温度检测时间'

