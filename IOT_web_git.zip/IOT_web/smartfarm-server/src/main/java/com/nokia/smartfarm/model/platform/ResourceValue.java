package com.nokia.smartfarm.model.platform;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class ResourceValue {
    private Logger logger = LoggerFactory.getLogger(ResourceValue.class);

    private String sv;
    private String v;

    public ResourceValue(String value) {
        if(value == null || value.isEmpty()) logger.warn("Resource value is null or empty -> ", value);
        this.sv = value;
//        JSONObject valueObject = new JSONObject(value);
//        JSONArray valueArray = valueObject.getJSONArray("e");
//        JSONObject vObject = valueArray.getJSONObject(0);
//        if(vObject.has("v")) {
//            this.v = vObject.get("v").toString();
//        } else {
//            this.sv = vObject.getString("sv");
//        }
    }

    public String getValue() {
        return this.sv;
    }

    @Override
    public String toString() {
        return "ResourceValue{" +
                "sv='" + getValue() + '\'' +
                '}';
    }
}
