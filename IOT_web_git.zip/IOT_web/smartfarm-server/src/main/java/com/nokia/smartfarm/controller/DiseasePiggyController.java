package com.nokia.smartfarm.controller;

import com.alibaba.druid.support.json.JSONUtils;
import com.alibaba.fastjson.JSON;
import com.nokia.smartfarm.pojo.Dictionary;
import com.nokia.smartfarm.pojo.Node;
import com.nokia.smartfarm.pojo.Piggy;
import com.nokia.smartfarm.pojo.Pigsty;
import com.nokia.smartfarm.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/diseasePiggy")
public class DiseasePiggyController {
    @Autowired
    private PiggyService piggyService;
    @Autowired
    private NodeService nodeService;
    @Autowired
    private PigstyService pigstyService;
    @Autowired
    private DictionaryService dictionaryService;
    @Autowired
    private PigstyMapService pigstyMapService;

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getQueryCondition")
    public Map<String, Object> getQueryCondition(){
        Map<String, Object> result = new HashMap<String, Object>();
        // 获取常量-生产周期常量
        List<Dictionary> periodStatusList = dictionaryService.getConstantByDicCat(101);
        result.put("periodStatusList", periodStatusList);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getTableData")
    public Map<String, Object> getTableData(String earcard, String periodStatus, @RequestParam Long pageNum,
                                            @RequestParam Long pageSize, String orderby, String sortDirection){
        Map<String, Object> result = new HashMap<String, Object>();
        //疾病猪只列表
        List diseasePiggyPage = piggyService.filterDiseasePiggy(null, earcard, periodStatus, pageNum, pageSize, orderby, sortDirection);
        Number filterCount = piggyService.filterDiseasePiggyCount(null, earcard, periodStatus);

        result.put("diseasePiggyPage", diseasePiggyPage);
        result.put("filterCount", filterCount);
        result.put("pageSize", pageSize);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/deletePiggyAlarmStatus", method = RequestMethod.POST)
    public Map<String, Object> deletePiggyAlarmStatus(@RequestParam("piggyIds") ArrayList<Long> piggyIds){
        Map<String, Object> result = new HashMap<String, Object>();
        boolean success = piggyService.deletePiggyAlarmStatus(piggyIds);
        result.put("success", success);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getUpdateCondition")
    public Map<String, Object> getUpdateCondition(){
        Map<String, Object> result = new HashMap<String, Object>();
        // 获取常量-生产周期常量
        List<Dictionary> periodStatusList = dictionaryService.getConstantByDicCat(101);
        List<Node> nodeList = nodeService.getAllNodes();
        List<Pigsty> pigstyList = pigstyService.getAllPigsty();
        List<Dictionary> entireList = dictionaryService.getConstantByDicCat(102);

        result.put("periodStatusList", periodStatusList);
        result.put("nodeList", nodeList);
        result.put("pigstyList", pigstyList);
        result.put("entireList", entireList);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/savePiggy", method = RequestMethod.POST)
    public Map<String, Object> saveOrUpdatePiggy(Piggy piggy){
        Map<String, Object> result = new HashMap<String, Object>();
        boolean b = piggyService.saveOrUpdatePiggy(piggy);
        result.put("success", b);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getPiggyInfo")
    public Map<String, Object> getPiggyInfo(Long piggyId){
        Map<String, Object> result = new HashMap<String, Object>();
        Piggy piggy = piggyService.getPiggyInfo(piggyId);
        result.put("piggy", JSON.toJSONString(piggy));
        return result;
    }

    //根据猪舍id获取网关地图数据
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getGatewayMapData")
    public List<Map<String, Object>> getGatewayMapData(Long pigstyId){
        return pigstyMapService.getGatewayMapDataByPigstyId(pigstyId);
    }
}
