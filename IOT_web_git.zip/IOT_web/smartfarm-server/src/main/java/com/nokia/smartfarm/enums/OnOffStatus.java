package com.nokia.smartfarm.enums;

public enum OnOffStatus {
    OFFLINE(0), ONLINE(1);

    private int code;

    OnOffStatus(int code) {

        this.code = code;

    }

    public int getCode() {
        return code;
    }
}
