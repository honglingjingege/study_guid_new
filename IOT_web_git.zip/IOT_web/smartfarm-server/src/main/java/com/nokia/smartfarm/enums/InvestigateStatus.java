package com.nokia.smartfarm.enums;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum InvestigateStatus {
    ZANWU("暂无症状", 0), BUMING("不明症状", 1), DAJIA("打架", 2)
    , YINGJI("应激", 3), DAYIMIAO("打疫苗", 4), SILIAO("饲料", 5)
    , WEIZHI("未知", 6);

    private int code;
    private String name;
    private static final List<Map<String, Object>> statusList;

    static {
        DiseaseStatus[] types = DiseaseStatus.values();
        statusList = new ArrayList<Map<String, Object>>();
        Map<String, Object> map = null;
        for (DiseaseStatus type : types) {
            map = new HashMap<String, Object>();
            map.put("name", type.getName());
            map.put("code", type.getCode());
            statusList.add(map);
        }
    }

    InvestigateStatus(String name, int code) {
        this.name = name;
        this.code = code;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public static List<Map<String, Object>> getStatusList() { return statusList; }

    public static String translate(int code) {
        switch(code) {
            case 0 : return InvestigateStatus.ZANWU.name;
            case 1 : return InvestigateStatus.BUMING.name;
            case 2 : return InvestigateStatus.DAJIA.name;
            case 3 : return InvestigateStatus.YINGJI.name;
            case 4 : return InvestigateStatus.DAYIMIAO.name;
            case 5 : return InvestigateStatus.SILIAO.name;
            default: return InvestigateStatus.WEIZHI.name;
        }
    }
}
