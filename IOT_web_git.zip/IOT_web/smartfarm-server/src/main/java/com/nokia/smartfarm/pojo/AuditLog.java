package com.nokia.smartfarm.pojo;

import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * 审计日志
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:24
 */
@Entity
@Data
@Table(name = "audit_log", schema = "application")
public class AuditLog {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer userId;   //操作用户id
    private String userName;   //操作用户名
    private Integer entityId;   //操作对象id
    private Integer entityType;   //操作对象类型
    private String entityName;   //操作对象名称
    private Integer actionType;   //操作类型
    private String actionData;   //操作数据
    private Integer actionStatus;   //操作结果
    private String actionFailureDetails;   //操作失败详情
    @Column(insertable = false)
    private Timestamp auditTime;   //时间
}
