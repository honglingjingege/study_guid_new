package com.nokia.smartfarm.config;

import com.nokia.smartfarm.model.platform.TokenModel;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Data
@Slf4j
public class SystemConfig {
    private static final String COLUMN_KEY = "setting_code";
    private static final String COLUMN_VALUE = "setting_value";
    private TokenModel tokenModel;

    private static SystemConfig config = null;

    private SystemConfig() {}

    public static SystemConfig getInstance() {
        if(config == null) config = new SystemConfig();
        return config;
    }
    private Map<String, Object> settings = new HashMap<>();

    public class Keys {
        public static final String ALARM_ABS_LOW_TEMP_DIFF = "alarm_abs_low_temp_diff";
        public static final String ALARM_ABS_HIGH_TEMP_DIFF = "alarm_abs_high_temp_diff";
        public static final String ALARM_DOD_LOW_TEMP_DIFF = "alarm_dod_low_temp_diff";
        public static final String ALARM_DOD_HIGH_TEMP_DIFF = "alarm_dod_high_temp_diff";
        public static final String ALARM_POP_LOW_TEMP_DIFF = "alarm_pop_low_temp_diff";
        public static final String ALARM_POP_HIGH_TEMP_DIFF = "alarm_pop_high_temp_diff";
        public static final String ALARM_INFO_COUNT = "alarm_info_count";
        public static final String ALARM_WARNING_COUNT = "alarm_warning_count";
        public static final String ALARM_ERROR_COUNT = "alarm_error_count";
        public static final String REPORT_INTERVAL = "report_interval";
        public static final String PIGSTY_BOUNDARY = "pigsty_boundary";
    }

    private interface PropertyParser<T> {

        T parseValue(String value);
    }

    public void load(List<Map<String, Object>> list) {
        Map<String, Object> settings = config.getSettings();
        for (int i = 0; i < list.size(); i++) {
            settings.put((String)list.get(i).get(COLUMN_KEY), list.get(i).get(COLUMN_VALUE));
        }
    }

    public String getString(final String key) {
        Object value = settings.get(key);
        return value != null ? String.valueOf(value) : null;
    }

    public int getInt(final String key) {
        return getInt(key, 0);
    }

    public int getInt(final String key, final int defaultValue) {
        return getNumberValue(new PropertyParser<Integer>() {
            @Override
            public Integer parseValue(String value) {
                return Integer.parseInt(value);
            }
        }, key, defaultValue);
    }

    public double getDouble(final String key) {
        return getDouble(key, 0.0D);
    }

    public double getDouble(final String key, final double defaultValue) {
        return getNumberValue(new PropertyParser<Double>() {

            @Override
            public Double parseValue(String value) {
                return Double.parseDouble(value);
            }
        }, key, defaultValue);
    }

    private <T> T getNumberValue(final PropertyParser<T> parser, final String key, final T defaultValue) {
        T result = defaultValue;
        Object value = settings.get(key);
        if (value != null) {
            try {
                result = parser.parseValue(String.valueOf(value));
            } catch (NumberFormatException e) {
                log.info("value for key [{0}] is not a {1}, returning default value",
                        new Object[] { key, defaultValue.getClass() });
            }
        } else {
            log.info("key [{0}] is undefined, returning default value", key);
        }
        return result;
    }
}
