package com.nokia.smartfarm.model.platform.raml;

public class Report {
    private String serialNumber;
    private String timestamp;
    private String subscriptionId;
    private String resourcePath;
    private String value;

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getSubscriptionId() {
        return subscriptionId;
    }

    public void setSubscriptionId(String subscriptionId) {
        this.subscriptionId = subscriptionId;
    }

    public String getResourcePath() {
        return resourcePath;
    }

    public void setResourcePath(String resourcePath) {
        this.resourcePath = resourcePath;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "Report{" +
                "serialNumber='" + serialNumber + '\'' +
                ", timestamp='" + timestamp + '\'' +
                ", subscriptionId='" + subscriptionId + '\'' +
                ", resourcePath='" + resourcePath + '\'' +
                ", value='" + value + '\'' +
                '}';
    }
}

