package com.nokia.smartfarm.controller;

import com.nokia.smartfarm.pojo.Dictionary;
import com.nokia.smartfarm.service.DictionaryService;
import com.nokia.smartfarm.service.PiggyService;
import com.nokia.smartfarm.service.PigstyMapService;
import com.nokia.smartfarm.service.PigstyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/warnPiggy")
public class WarnPiggyController {
    @Autowired
    private PiggyService piggyService;
    @Autowired
    private PigstyService pigstyService;
    @Autowired
    private PigstyMapService pigstyMapService;

    @Autowired
    private DictionaryService dictionaryService;

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getWarnPiggyNum")
    public Map<String, Object> getCardsContent(String earcard, String periodStatus, String alarmStart, String alarmEnd){
        Map<String, Object> result = new HashMap<String, Object>();
        //猪只
        Long piggyCount = piggyService.getPiggyCount();
        Number alarmPiggyCount = piggyService.filterAlarmPiggyCount(earcard, periodStatus, null, alarmStart, alarmEnd);
        // 获取常量-生产周期常量
        List<Dictionary> periodStatusList = dictionaryService.getConstantByDicCat(101);
        // 猪舍信息和其中报警猪只数量
        List<Map<String, Object>> pigstyWithAlarmPiggy = pigstyService.getPigstyWithAlarmPiggy(earcard, periodStatus, alarmStart, alarmEnd);

        result.put("piggyCount", piggyCount);
        result.put("alarmPiggyCount", alarmPiggyCount);
        result.put("periodStatusList", periodStatusList);
        result.put("pigstyWithAlarmPiggy", pigstyWithAlarmPiggy);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getTableData")
    public Map<String, Object> getTableData(String earcard, String periodStatus, String pigstyId, String alarmStart
            , String alarmEnd, @RequestParam Long pageNum, @RequestParam Long pageSize){
        Map<String, Object> result = new HashMap<String, Object>();
        //报警猪只列表
        List<Map<String, Object>> sickPiggyPage = piggyService.filterAlarmPiggy(earcard, periodStatus, pigstyId, alarmStart, alarmEnd, pageNum, pageSize
                ,null, null);
        Number filterCount = piggyService.filterAlarmPiggyCount(earcard, periodStatus, pigstyId, alarmStart, alarmEnd);

        result.put("sickPiggyPage", sickPiggyPage);
        result.put("filterCount", filterCount);
        result.put("pageSize", pageSize);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/updateAlarmStatus", method = RequestMethod.POST)
    public Map<String, Object> updateAlarmStatus(@RequestParam("piggyIds") ArrayList<Long> piggyIds, Long alarmStatus){
        Map<String, Object> result = new HashMap<String, Object>();
        boolean success = piggyService.updateAlarmStatus(piggyIds, alarmStatus);
        result.put("success", success);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getGatewayMapData")
    public List<Map<String, Object>> getGatewayMapData(Long pigstyId){
        return pigstyMapService.getGatewayMapDataByPigstyId(pigstyId);
    }
}
