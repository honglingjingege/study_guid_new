package com.nokia.smartfarm.pojo;


import com.nokia.smartfarm.pojo.audit.DateAudit;
import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@Table(name = "npmap", schema = "application")
public class NpMap extends DateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String earcard;
    private String sn;

}
