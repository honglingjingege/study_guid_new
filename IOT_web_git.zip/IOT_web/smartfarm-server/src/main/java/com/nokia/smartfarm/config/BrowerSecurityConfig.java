package com.nokia.smartfarm.config;

import com.alibaba.fastjson.JSON;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.access.AccessDeniedHandler;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.authentication.logout.LogoutSuccessHandler;
import org.springframework.stereotype.Component;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled=true)
@Slf4j
public class BrowerSecurityConfig extends WebSecurityConfigurerAdapter {

    private final static BCryptPasswordEncoder ENCODER = new BCryptPasswordEncoder();
    @Autowired
    private CustomAuthenticationSuccessHandler customAuthenticationSuccessHandler;
    @Autowired
    private CustomAuthenticationFailHandler customAuthenticationFailHandler;
    @Autowired
    private CustomLogoutSuccessHandler customLogoutSuccessHandler;
    @Autowired
    private CustomAccessDeniedHandler customAccessDeniedHandler;

    @Value("${brower-security-config.loginpage:''}")
    private String loginPage;

    @Value("${brower-security-config.invalidSessionUrl:''}")
    private String invalidSessionUrl;

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http.formLogin()
                .loginPage(loginPage)// 设置登录页面
                .loginProcessingUrl("/api/login")
                .successHandler(customAuthenticationSuccessHandler)//自定义的登录验证成功或失败后的去向
                .failureHandler(customAuthenticationFailHandler)
                .and()                          //********************
                .authorizeRequests()            // 定义哪些URL需要被保护、哪些不需要被保护
                .antMatchers("/api/turnToLogin").permitAll()
                .antMatchers("/api/platform/**").permitAll()
                .anyRequest().authenticated()   // 任何请求,登录后可以访问
                .and()
                .exceptionHandling().accessDeniedHandler(customAccessDeniedHandler)//自定义没有权限的处理类
                .and()                          //********************
                .csrf().disable();              // 关闭csrf防护;
        http.logout()
                .logoutUrl("/api/logout")           //触发注销操作的URL
                .logoutSuccessHandler(customLogoutSuccessHandler)//自定义登出成功后的处理类
                .invalidateHttpSession(true);   //指定是否在注销时让HttpSession无效
        http.sessionManagement().invalidSessionUrl(invalidSessionUrl);
    }

//    @Autowired
//    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
//        auth.userDetailsService(userDetailsService()).passwordEncoder(ENCODER);
//        auth.eraseCredentials(false);
//    }
//    @Bean
//    public UserDetailsService userDetailsService() {//用户登录实现
//        return new UserDetailsService() {
//            @Autowired
//            private UserRepository userRepository;
//
//            @Override
//            public UserDetails loadUserByUsername(String s) throws UsernameNotFoundException {
//                User user = userRepository.findByUsername(s);
//                if (null == user) throw new UsernameNotFoundException("Username " + s + " not found");
//                return new SecurityUser(user);
//            }
//        };
//    }

    @Autowired
    public void configureGlobal(AuthenticationManagerBuilder auth) throws Exception {
        auth.inMemoryAuthentication().passwordEncoder(ENCODER)
                .withUser("admin").password(ENCODER.encode("edge2020")).authorities("ADMIN")
                .and()
                .withUser("user").password(ENCODER.encode("edge2020")).authorities("USER");
    }

    @Component
    class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {
        @Override
        public void onAuthenticationSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
            UserDetails userDetails = (UserDetails) authentication.getPrincipal();
            log.info("{}登录成功", userDetails.getUsername());
            Map<String, String> map = new HashMap<>(3);
            map.put("status", "ok");
            map.put("code", "200");
            map.put("msg", "success");
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write(JSON.toJSONString(map));
        }
    }

    @Component
    class CustomAuthenticationFailHandler implements AuthenticationFailureHandler {
        @Override
        public void onAuthenticationFailure(HttpServletRequest request, HttpServletResponse response, AuthenticationException e) throws IOException, ServletException {
            log.info("登录验证失败");
            Map<String,String> map=new HashMap<>(4);
            map.put("type", request.getParameter("type"));
            map.put("status", "error");
            map.put("code", "10001");
            map.put("msg", e.getMessage());
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write(JSON.toJSONString(map));
        }
    }

    @Component
    class CustomLogoutSuccessHandler implements LogoutSuccessHandler {
        @Override
        public void onLogoutSuccess(HttpServletRequest request, HttpServletResponse response, Authentication authentication) throws IOException, ServletException {
            Map<String,String> map = new HashMap<>(3);
            map.put("status", "ok");
            map.put("code", "200");
            map.put("msg", "success");
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write(JSON.toJSONString(map));
        }
    }

    @Component
    class CustomAccessDeniedHandler implements AccessDeniedHandler{
        @Override
        public void handle(HttpServletRequest request, HttpServletResponse response, AccessDeniedException e) throws IOException, ServletException {
            log.info("请授权后访问");
            Map<String,String> map = new HashMap<>(3);
            map.put("status", "error");
            map.put("code", "403");
            map.put("msg", e.getMessage());
            response.setContentType("application/json;charset=UTF-8");
            response.getWriter().write(JSON.toJSONString(map));
        }
    }
}

