package com.nokia.smartfarm.controller;

import com.google.gson.Gson;
import com.nokia.smartfarm.config.SystemConfig;
import com.nokia.smartfarm.model.platform.DeviceModel;
import com.nokia.smartfarm.model.platform.DevicesModel;
import com.nokia.smartfarm.service.SettingsService;
import com.nokia.smartfarm.service.platform.PlatformIntService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;
import com.alibaba.fastjson.JSON;

@RestController
@RequestMapping("/api/settingParams")
@Slf4j
public class SettingsController {
    private static final String REPORT_INTERVAL = "report_interval";

    Gson gson = new Gson();

    @Autowired
    private SettingsService settingsService;

    @Autowired
    private PlatformIntService platformIntService;

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getSettingParams")
    public Map<String, Object> getSettingParams (){
        return SystemConfig.getInstance().getSettings();
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/updateSettingParams", method = RequestMethod.POST)
    public Map<String, Object> updateSettingParams(@RequestParam("settingParams") String settingParams){
        Map<String, Object> mapTypes = JSON.parseObject(settingParams);
        Map<String, Object> result = new HashMap<>();
        Boolean success = settingsService.updateSettingParams(mapTypes);
        result.put("success", success);
        if(success){
            for (Map.Entry<String, Object> entry : mapTypes.entrySet()) {
                SystemConfig.getInstance().getSettings().put(entry.getKey(),entry.getValue());
                if(entry.getKey().equals(REPORT_INTERVAL)) {
                    String devices = platformIntService.getDevicesByCustomer();
                    DevicesModel devicesModel = gson.fromJson(devices, DevicesModel.class);
                    for(DeviceModel deviceModel : devicesModel.getData()) {
                        platformIntService.write(deviceModel.getName(), entry.getValue());
                    }
                }
            }
        }
        return result;
    }
}
