package com.nokia.smartfarm.service;

import com.nokia.smartfarm.pojo.Environment;
import com.nokia.smartfarm.repository.EnvironmentRepository;
import org.apache.commons.lang.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/28 14:28
 */
@Service
public class EnvironmentService {

    @Autowired
    private EnvironmentRepository environmentRepository;

    /**
     * 获取最新温湿度
     * @return
     */
    public Map<String, Object> getLatestTempAndHumidity(){
        Map<String, Object> map = new HashMap<String, Object>();
        Environment env = environmentRepository.findTop1ByOrderByRecordTimeDesc();
        Integer envTemp = null;
        Integer envHumidity = null;
        if(null != env){
            envTemp = env.getEnvTemp();
            envHumidity = env.getEnvHumidity();
        }
        map.put("envTemp", envTemp);
        map.put("envHumidity", envHumidity);
        return map;
    }

    /**
     * 获取当前时间和温度值
     * @return
     */
    public Map<String, Object> getLatestTempAndTime(){
        Map<String, Object> map = new HashMap<String, Object>();
        Environment env = environmentRepository.findTop1ByOrderByRecordTimeDesc();
        Integer envTemp = null;
        String recordTime = null;
        if(null != env){
            envTemp = env.getEnvTemp();
            DateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            recordTime = env.getRecordTime()==null ? null : sdf.format(env.getRecordTime());
        }
        map.put("envTemp", envTemp);
        map.put("recordTime", recordTime);
        return map;
    }

    /**
     * 获取最近n天的温度范围
     * @return
     */
    public List<Map<String, Object>> getNewestNDaysTemp(int i) {
        Assert.notNull(i, "提前或推后时间不能为空！");
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) - i);
        String startTime = DateFormatUtils.formatUTC(calendar.getTime(),"yyyy-MM-dd HH:mm:ss");
        List<Map<String, Object>> newestNDaysTemp = environmentRepository.findNewestNDaysTemp(startTime);
        return newestNDaysTemp;
    }

    /**
     * 获取最近n小时的温度和湿度历史平均值信息
     * @return
     */
    public List<Map<String, Object>> getLatestNHourAveTempAndTime(int i) {
        Assert.notNull(i, "提前或推后时间不能为空！");
        Calendar calendar = Calendar.getInstance();
        calendar.set(Calendar.HOUR_OF_DAY, calendar.get(Calendar.HOUR_OF_DAY) - i);
        String startTime = DateFormatUtils.formatUTC(calendar.getTime(),"yyyy-MM-dd HH:mm:ss");
        List<Map<String, Object>> latestNHourAveTempAndTime = environmentRepository.findLatestNHourAveTempAndTime(startTime);
        return latestNHourAveTempAndTime;
    }

    //使用save()方法更新字段一定要通过Repository获取实体对象，在此对象上进行更新操作
//    public void test(){
//        Piggy piggy = piggyRepository.findById(1109).get();
//        piggy.setNodeId(444);
//        piggy.setAlarmStatus(2);
//        piggy = piggyRepository.save(piggy);
//        return;
//    }

//    public void test(){
//        Sort sort = new Sort(Sort.Direction.ASC, "id");
//        Pageable pageable = PageRequest.of(0, 1, sort);
//        Piggy piggy = new Piggy();
//        piggy.setId(1);
//        Example<Piggy> example = Example.of(piggy);
//        Page<Piggy> all = piggyRepository.findAll(example, pageable);
//        return;
//    }
}
