package com.nokia.smartfarm.schedule;

import com.nokia.smartfarm.config.SystemConfig;
import com.nokia.smartfarm.model.influx.GatewayAvgTempPoint;
import com.nokia.smartfarm.pojo.Piggy;
import com.nokia.smartfarm.service.PiggyService;
import com.nokia.smartfarm.service.PigstyService;
import lombok.extern.slf4j.Slf4j;
import org.influxdb.InfluxDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.math.BigDecimal;
import java.rmi.server.ExportException;
import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class GroupTemperatureCalTask {

    @Autowired
    PiggyService piggyService;

    @Autowired
    private JedisPool jedisPool;

    @Autowired
    private InfluxDB influxDB;

    private static final String COLUMN_KEY = "gateway_name";
    private static final String COLUMN_VALUE = "group_avg_temp";

    @Scheduled(cron = "0 0/15 * * * ?")
    private void cal() {
        SystemConfig config = SystemConfig.getInstance();
        int reportInterval = config.getInt(SystemConfig.Keys.REPORT_INTERVAL);
        int fullCount = 24 * 60 / reportInterval;
        Jedis jedis = jedisPool.getResource();
        try {
            List<Map<String, Object>> list = piggyService.findAvgTemperatureGroupByGateway();
            for (int i = 0; i < list.size(); i++) {
                String serialNumber = (String) list.get(i).get(COLUMN_KEY);
                String averageTemperature = list.get(i).get(COLUMN_VALUE).toString();
                double dAverageTemperature = new BigDecimal(Double.parseDouble(averageTemperature)).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
                String redisKey = "temperature" + serialNumber;
                jedis.lpush(redisKey, averageTemperature);
                jedis.ltrim(redisKey, 0, 24 * 6 - 1);

                GatewayAvgTempPoint gatewayAvgTempPoint = new GatewayAvgTempPoint(serialNumber, dAverageTemperature);
                influxDB.write(gatewayAvgTempPoint.getPoint());
                log.info("Influx gateway avg temperature -> {} ", gatewayAvgTempPoint.toString());
            }
        }catch (Exception e) {
            e.printStackTrace();
        }finally {
            try {
                jedis.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
