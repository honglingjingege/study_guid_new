package com.nokia.smartfarm.enums;

public enum PeriodStatus {
    HOUBEI("后备期", 0), RENSHEN("妊娠期", 1), BURU("分娩哺乳期", 2), KONGHUAI("空怀期", 3), WEIZHI("未知", 99);

    private int code;
    private String name;

    PeriodStatus(String name, int code) {
        this.name = name;
        this.code = code;

    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public static PeriodStatus getByImported(String importedStatus) {
        switch(importedStatus) {
            case "已配" : return PeriodStatus.RENSHEN;
            case "后备" : return PeriodStatus.HOUBEI;
            case "哺乳" : return PeriodStatus.BURU;
            case "断奶" : return PeriodStatus.KONGHUAI;
            case "返情" : return PeriodStatus.KONGHUAI;
            case "流产" : return PeriodStatus.KONGHUAI;
            default: return PeriodStatus.WEIZHI;
        }
    }
}
