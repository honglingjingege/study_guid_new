package com.nokia.smartfarm.controller.platform;

import com.nokia.smartfarm.model.platform.raml.RamlObject;
import com.nokia.smartfarm.service.platform.PlatformCallbackService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@Slf4j
@RequestMapping("/api/platform")
public class PlatformCallbackController {

    @Autowired
    PlatformCallbackService platformCallbackService;

    @PostMapping("/callback")
    public void callback(@RequestBody(required = false) RamlObject ramlObject) {
        log.info("Received callback data -> {}", ramlObject.toString());
        platformCallbackService.process(ramlObject);
    }
}
