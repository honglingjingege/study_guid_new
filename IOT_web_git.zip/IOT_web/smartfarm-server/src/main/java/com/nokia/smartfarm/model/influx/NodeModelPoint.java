package com.nokia.smartfarm.model.influx;

import com.nokia.smartfarm.model.TemperatureCalModel;
import com.nokia.smartfarm.model.platform.NodeModel;
import lombok.Data;
import org.influxdb.dto.Point;

import java.util.concurrent.TimeUnit;

@Data
public class NodeModelPoint{
    Point point;
    public NodeModelPoint(NodeModel nodeModel, TemperatureCalModel temperatureCalModel) {
        point = Point.measurement("sensor")
            .time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
            .tag("IMEI", nodeModel.getSerialNumber())
            .tag("MMC_MAC", nodeModel.getSensorId())
            .addField("mmc_temp", nodeModel.getSensorValue())
            .addField("mmc_pop_temp", temperatureCalModel.getPopTemperature())
            .addField("mmc_dod_temp", temperatureCalModel.getDodTemperature())
            .addField("mmc_group_curr_temp", temperatureCalModel.getGroupCurrentTemperature())
            .addField("mmc_group_pop_temp", temperatureCalModel.getGroupPopTemperature())
            .addField("mmc_group_dod_temp", temperatureCalModel.getGroupDodTemperature())
            .addField("mmc_abs_temp_diff", temperatureCalModel.getAbsDiff())
            .addField("mmc_pop_temp_diff", temperatureCalModel.getPopDiff())
            .addField("mmc_dod_temp_diff", temperatureCalModel.getDodDiff())
            .addField("mmc_rssi", nodeModel.getRssi())
            .addField("mmc_battery", nodeModel.getBattery())
            .build();
    }
}
