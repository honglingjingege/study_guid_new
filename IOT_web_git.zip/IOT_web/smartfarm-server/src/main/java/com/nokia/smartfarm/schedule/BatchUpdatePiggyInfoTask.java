package com.nokia.smartfarm.schedule;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.nokia.smartfarm.pojo.BasePiggyInfo;
import com.nokia.smartfarm.pojo.Pigsty;
import com.nokia.smartfarm.service.BasePiggyInfoService;
import com.nokia.smartfarm.service.PiggyService;
import com.nokia.smartfarm.service.PigstyService;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class BatchUpdatePiggyInfoTask {

    @Autowired
    BasePiggyInfoService basePiggyInfoService;
    @Autowired
    PiggyService piggyService;
    @Autowired
    PigstyService pigstyService;

    @Value("${huMuYunInterface.user:''}")
    private String user;
    @Value("${huMuYunInterface.password:''}")
    private String password;
    @Value("${huMuYunInterface.url:''}")
    private String url;

    @Scheduled(cron = "0 0 1 * * ?")
    private void cal() throws IOException {
        log.info("****从互牧系统同步piggy信息开始****");
        if(!this.updateBasePiggyInfo()) return;
        updatePiggyAndPigstyInfo();
        log.info("****从互牧系统同步piggy信息结束****");
    }

    /**
     * 同步base_piggy_info表信息
     * @return 同步是否成功
     * @throws IOException
     */
    private boolean updateBasePiggyInfo() throws IOException{
        List<NameValuePair> formparams = new ArrayList<NameValuePair>();
        formparams.add(new BasicNameValuePair("user", user));
        formparams.add(new BasicNameValuePair("password", password));
        HttpEntity reqEntity = new UrlEncodedFormEntity(formparams, "utf-8");
        RequestConfig requestConfig = RequestConfig.custom()
                .setConnectTimeout(5000)//连接超时connectionTimeout，连接一个url的连接等待时间
                .setSocketTimeout(60000)//读取数据超时SocketTimeout，连接上一个url，获取response的返回等待时间
                .setConnectionRequestTimeout(5000)//从连接池获取连接的timeout
                .build();
        HttpPost post = new HttpPost(url);
        post.setEntity(reqEntity);
        post.setConfig(requestConfig);

        HttpClient client = HttpClientBuilder.create().build();
        HttpResponse response = client.execute(post);
        if(response.getStatusLine().getStatusCode() != 200){
            log.info("请求piggy信息出现异常！");
            return false;
        }
        HttpEntity resEntity = response.getEntity();
        String message = EntityUtils.toString(resEntity, "utf-8");
        Map<String, Object> map = JSONObject.parseObject(message, Map.class);

        Object data = map.get("data");
        Object status = map.get("status");
        if(null == status || null == data || (Boolean) status != true){
            log.info("互牧系统piggy信息不存在！");
            return false;
        }
        List<BasePiggyInfo> list = JSONArray.parseArray(data.toString(), BasePiggyInfo.class);
        basePiggyInfoService.truncateTable();//先清空表
        basePiggyInfoService.saveAll(list);//再批量保存
        log.info("保存base_piggy_info信息成功！");
        return true;
    }

    /**
     * 更新猪只和猪舍表信息
     */
    private void updatePiggyAndPigstyInfo(){
        //1、更新piggy表信息
        piggyService.batchUpdateFromBasePiggyInfo();
        //2、更新pigsty表信息
        pigstyService.batchUpdateFromBasePiggyInfo();
        //3、如果猪只没有对应猪舍，则先新增猪舍，再更新猪舍id
        List<Map<String, Object>> plist = basePiggyInfoService.findNoPigstyPiggy();
        if(null == plist || plist.size() == 0) return;
        for(Map<String, Object> p : plist){
            Integer pigstyId = null;
            String sn = String.valueOf(p.get("piggery"));
            Pigsty validatePigsty = pigstyService.findPigstyBySn(sn);
            if(null != validatePigsty){//是否已经新建猪舍
                pigstyId = validatePigsty.getId();
            }else{
                String name = String.valueOf(p.get("piggeryname"));
                Pigsty sp = pigstyService.save(new Pigsty(sn, name));
                pigstyId = sp.getId();
                log.info("新建猪舍，id={}", pigstyId);
            }
            Integer id = Integer.parseInt(String.valueOf(p.get("id")));
            piggyService.updatePigstyIdOfPiggy(pigstyId, id);
        }
    }

}
