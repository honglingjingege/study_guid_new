package com.nokia.smartfarm.pojo;

import com.nokia.smartfarm.pojo.audit.DateAudit;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * 猪舍信息
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:24
 */
@Entity
@Data
@NoArgsConstructor
@Table(name = "pigsty", schema = "application")
public class Pigsty extends DateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String sn;   //猪舍编号, 从互牧系统导入
    private String name;   //猪舍名称
    private Integer headerId;    //负责人id
    private Integer width;  //宽
    private Integer high;  //高

    public Pigsty(String sn, String name){
        this.sn = sn;
        this.name = name;
    }
}
