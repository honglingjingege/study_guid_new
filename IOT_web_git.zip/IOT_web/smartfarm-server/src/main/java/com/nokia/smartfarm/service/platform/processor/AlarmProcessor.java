package com.nokia.smartfarm.service.platform.processor;

import com.nokia.smartfarm.config.SystemConfig;
import com.nokia.smartfarm.enums.AlarmStatus;
import com.nokia.smartfarm.model.AlarmCountModel;
import com.nokia.smartfarm.model.TemperatureCalModel;
import com.nokia.smartfarm.model.influx.NodeModelPoint;
import com.nokia.smartfarm.model.platform.BaseModel;
import com.nokia.smartfarm.model.platform.NodeModel;
import com.nokia.smartfarm.pojo.Gateway;
import com.nokia.smartfarm.pojo.Node;
import com.nokia.smartfarm.pojo.Piggy;
import com.nokia.smartfarm.service.GatewayService;
import com.nokia.smartfarm.service.InfluxHisDataService;
import com.nokia.smartfarm.service.NodeService;
import com.nokia.smartfarm.service.PiggyService;
import lombok.extern.slf4j.Slf4j;
import org.influxdb.InfluxDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

@Component
@Slf4j
public class AlarmProcessor implements Processor{
    private static final String LATEST_UPDATE_KEY_PRE = "latestUpdate_";
    private static final int COUNT = 3;
    @Autowired
    private JedisPool jedisPool;

    @Autowired
    PiggyService piggyService;

    @Autowired
    NodeService nodeService;


    @Autowired
    GatewayService gatewayService;

    @Autowired
    private InfluxDB influxDB;

    @Autowired
    InfluxHisDataService hisDataService;

    @Autowired
    TemperatureCalModel temperatureCalModel;

    @Override
    public void process(List<BaseModel> baseModels) {
        Jedis jedis = jedisPool.getResource();
        try {
            SystemConfig config = SystemConfig.getInstance();
            int normalCountSetting = config.getInt(SystemConfig.Keys.ALARM_INFO_COUNT),
                    seriousCountSetting = config.getInt(SystemConfig.Keys.ALARM_WARNING_COUNT),
                    dangerousCountSetting = config.getInt(SystemConfig.Keys.ALARM_ERROR_COUNT);
            int reportInterval = config.getInt(SystemConfig.Keys.REPORT_INTERVAL);
            for (BaseModel model : baseModels) {
                NodeModel nodeModel = (NodeModel) model;
                String serialNumber = nodeModel.getSerialNumber();
                String sensorId = nodeModel.getSensorId();
                Node node = nodeService.findNodeBySn(sensorId);
                if(node == null) continue;

                String thisKey = LATEST_UPDATE_KEY_PRE + sensorId + "_" + serialNumber;
                jedis.set(thisKey, String.valueOf(System.currentTimeMillis()));

                if(!node.getGatewayName().equals(serialNumber)) {
                    String binderKey = LATEST_UPDATE_KEY_PRE + sensorId + "_" + node.getGatewayName();
                    try {
                        if(jedis.get(binderKey) == null || System.currentTimeMillis() - Long.parseLong(jedis.get(binderKey)) > reportInterval * 60 * COUNT * 1000) {
                            log.info("Chang binding... {} from -> {}, to -> {}", sensorId, node.getGatewayName(), serialNumber);
                            Gateway gateway = gatewayService.findGatewayBySn(serialNumber);
                            node.setGatewayId(gateway.getId());
                            node.setGatewayName(gateway.getName());
                            nodeService.save(node);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    continue;
                }

                temperatureCalModel.init(sensorId, serialNumber, nodeModel.getSensorValue());
//                temperatureCalModel.store(jedis, sensorId, reportInterval);
                NodeModelPoint nodeModelPoint = new NodeModelPoint(nodeModel, temperatureCalModel);
                influxDB.write(nodeModelPoint.getPoint());
                log.info("Influx db -> {} ", nodeModelPoint.toString());

                int count = temperatureCalModel.calAlarmCount();
                Piggy piggy = piggyService.findPiggyByNode(node.getId());
                if(piggy == null) continue;
                temperatureCalModel.fulfill(piggy);
                piggy.setDetectedAt(new Date());

                if(piggy.getAlarmStatus() != AlarmStatus.DISEASE.getCode() && isInitReady(piggy)) {
                    AlarmCountModel alarmCountModel = new AlarmCountModel(jedis, sensorId);
                    if (count > 0) {
                        piggy.setAlarmStatus(AlarmStatus.ABNORMAL.getCode());
                        piggy.setAlarmAt(new Timestamp(new Date().getTime()));
                    }
                    if (count == 3) {
                        int dangerousCount = alarmCountModel.getDangerousCount() + 1;
                        if (dangerousCount >= dangerousCountSetting) piggy.setAlarmStatus(AlarmStatus.ALARM.getCode());
                        jedis.set("seriousCount" + sensorId, String.valueOf(dangerousCount));
                    } else if (count == 2) {
                        int seriousCount = alarmCountModel.getSeriousCount() + 1;
                        if (seriousCount >= seriousCountSetting) piggy.setAlarmStatus(AlarmStatus.ALARM.getCode());
                        jedis.set("seriousCount" + sensorId, String.valueOf(seriousCount));

                    } else if (count == 1) {
                        int normalCount = alarmCountModel.getNormalCount() + 1;
                        if (normalCount >= normalCountSetting) piggy.setAlarmStatus(AlarmStatus.ALARM.getCode());
                        jedis.set("normalCount" + sensorId, String.valueOf(normalCount));
                    } else if (count == 0) {
                        jedis.set("seriousCount" + sensorId, String.valueOf(0));
                        jedis.set("normalCount" + sensorId, String.valueOf(0));
                        piggy.setAlarmStatus(AlarmStatus.NORMAL.getCode());
                    }
                }
                piggyService.save(piggy);
            }
        }catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(jedis != null) {
                try {
                    jedis.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

    }
    private boolean isInitReady(Piggy piggy) {
        Date createdAt = piggy.getCreatedAt();
        return System.currentTimeMillis() - createdAt.getTime() > 24 * 60 * 60 * 1000;
    }
}
