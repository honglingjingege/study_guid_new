package com.nokia.smartfarm.service.platform;

import com.nokia.smartfarm.model.platform.raml.*;
import com.nokia.smartfarm.model.platform.BaseModel;
import com.nokia.smartfarm.util.RamlDataParser;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;

@Service
@Slf4j
public class PlatformCallbackService {

    @Autowired
    ProcessorService processorService;

    public void process(RamlObject ramlObject) {
        this.processReports(ramlObject.getReports());
        this.processOnlineEvent(ramlObject.getRegistrations());
        this.processOfflineEvent(ramlObject.getDeregistrations());
        this.processActiveEvent(ramlObject.getActivations());
    }

    private void processActiveEvent(List<OnOff> activations) {
        if (activations == null) return;
        processorService.processActiveEvent(activations);
    }

    private void processReports(List<Report> reports) {
        if(reports == null || reports.size() == 0) return;
        List<BaseModel> baseModels = RamlDataParser.parseReport(reports);
        processorService.processReports(baseModels);
    }

    public void processOnlineEvent(List<OnOff> registrations) {
        if (registrations == null || registrations.size() == 0) return;
        processorService.processOnlineEvent(registrations);
    }

    public void processOfflineEvent(List<OnOff> deregistrations) {
        if (deregistrations == null || deregistrations.size() == 0) return;
        processorService.processOfflineEvent(deregistrations);
    }
}
