package com.nokia.smartfarm.service;

import com.nokia.smartfarm.pojo.BasePiggyInfo;
import com.nokia.smartfarm.repository.BasePiggyInfoRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
public class BasePiggyInfoService {

    @Autowired
    BasePiggyInfoRepository basePiggyInfoRepository;

    public BasePiggyInfo findPiggyInfoByEarcard(String earcard) {
        List<BasePiggyInfo> basePiggyInfos = basePiggyInfoRepository.findBasePiggyInfoByEarcardEquals(earcard);
        if(basePiggyInfos != null && basePiggyInfos.size()>0) return basePiggyInfos.get(0);
        return null;
    }

    /**
     * 批量保存猪只
     * @param piggys
     */
    public void saveAll(List<BasePiggyInfo> piggys) {
        basePiggyInfoRepository.saveAll(piggys);
    }

    /**
     * 清空basePiggyInfo表
     */
    @Transactional
    public void truncateTable() {
        basePiggyInfoRepository.truncateTable();
    }

    /**
     * 查找需要新增的猪舍信息和关联的猪只id
     * @return
     */
    public List<Map<String, Object>> findNoPigstyPiggy() {
        return basePiggyInfoRepository.findNoPigstyPiggy();
    }
}
