package com.nokia.smartfarm.model.platform;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class ResourcePath {
    private Logger logger = LoggerFactory.getLogger(ResourcePath.class);
    private String objectId;
    private String objectName;
    private String instanceId;
    private String resourceId;
    private String path;
    private String resourceName;
    private boolean isList;


    public ResourcePath(String path) {
        String ss[] = path.split("/");
        if(ss.length !=3) {
            logger.warn("Resource path is incorrect in the report -> {}", path);
        }
        this.objectId = ss[0];
        this.instanceId = ss[1];
        this.resourceId = ss[2];
        this.path = path;
//        this.resourceName = ORMapping.getResourceName(objectId, instanceId, resourceId);
    }

    public String getObjectId() {
        return objectId;
    }

    public void setObjectId(String objectId) {
        this.objectId = objectId;
    }

    public String getInstanceId() {
        return instanceId;
    }

    public void setInstanceId(String instanceId) {
        this.instanceId = instanceId;
    }

    public String getResourceId() {
        return resourceId;
    }

    public void setResourceId(String resourceId) {
        this.resourceId = resourceId;
    }

    public String getPath() {
        return path;
    }

    public void setPath(String path) {
        this.path = path;
    }

    public String getResourceName() {
        return resourceName;
    }

    public void setResourceName(String resourceName) {
        this.resourceName = resourceName;
    }

    public boolean isList() {
        return isList;
    }

    public void setList(boolean list) {
        isList = list;
    }

    public String getObjectName() {
        return objectName;
    }

    public void setObjectName(String objectName) {
        this.objectName = objectName;
    }

    @Override
    public String toString() {
        return "ResourcePath{" +
                "objectId='" + objectId + '\'' +
                ", instanceId='" + instanceId + '\'' +
                ", resourceId='" + resourceId + '\'' +
                '}';
    }
}
