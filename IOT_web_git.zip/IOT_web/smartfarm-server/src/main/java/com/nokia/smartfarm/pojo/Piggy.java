package com.nokia.smartfarm.pojo;

import com.nokia.smartfarm.pojo.audit.DateAudit;
import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;
import java.util.Date;

/**
 * 猪只信息
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:24
 */
@Entity
@Data
@Table(name = "piggy", schema = "application")
public class Piggy extends DateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String earcard;   //猪只耳标号, 从互牧系统导入
    private Integer nodeId;    //秒秒测id
    private Integer alarmStatus;    //猪只告警状态: 0正常, 1体温异常, 2报警, 3疾病
    private Integer periodStatus;       //猪只周期状态: 0后备期, 1妊娠期, 2分娩哺乳期, 3空怀期
    private String importedPeriodStatus;   //猪只周期状态, 从互牧系统导入
    private String individual;        //个体号, 从互牧系统导入
    private Timestamp periodStatusDate;       //猪只当前周期开始时间, 从互牧系统导入
    private Integer pigstyId;     //猪舍id
    private Double currTemp;   //当前温度
    private Double absTemp;   //绝对温差值
    private Double dodTemp;   //同比温差值
    private Double popTemp;   //环比温差值
    private Timestamp alarmAt;   //预警时间
    private Integer entire;    //全部
    private String investigate;   //排查诊断
    private String measures;   //采取措施
    private String diseaseType;   //疾病类型
    private String comInvest;   //描述-排查诊断
    private String comMeas;   //描述-采取措施
    private String comDisease;   //描述-疾病类型
    private Date detectedAt;

}
