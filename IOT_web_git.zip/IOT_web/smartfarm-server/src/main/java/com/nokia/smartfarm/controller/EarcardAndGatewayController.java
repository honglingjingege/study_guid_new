package com.nokia.smartfarm.controller;

import com.nokia.smartfarm.service.GatewayService;
import com.nokia.smartfarm.service.PiggyService;
import com.nokia.smartfarm.service.PigstyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/earCardAndGateway")
public class EarcardAndGatewayController {
    @Autowired
    private PiggyService piggyService;
    @Autowired
    private GatewayService gatewayService;

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/getEarTagAndGateway")
    public Map<String, List<Map<String, Object>>> findEarTagAndGateway(){
        List<Map<String, Object>> earTagList = piggyService.findEarTagList();
        List<Map<String, Object>> gatewayList = gatewayService.findBindedGatewayList();
        Map earTagAndGateway = new HashMap();
        earTagAndGateway.put("earTagList", earTagList);
        earTagAndGateway.put("gatewayList", gatewayList);
        return earTagAndGateway;
    }
}
