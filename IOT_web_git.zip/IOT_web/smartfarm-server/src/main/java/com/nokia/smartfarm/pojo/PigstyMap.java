package com.nokia.smartfarm.pojo;

import lombok.Data;

import javax.persistence.*;

@Entity
@Data
@Table(name = "pigstymap", schema = "application")
public class PigstyMap {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer gatewayId;
    @Column(name = "point_x")
    private Integer pointX;
    @Column(name = "point_y")
    private Integer pointY;
    private Integer pigstyId;
}
