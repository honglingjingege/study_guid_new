package com.nokia.smartfarm.pojo;

import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

@Entity
@Data
@Table(name = "base_piggy_info", schema = "application")
public class BasePiggyInfo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String earcard;
    private String individual;
    private String status;
    private Timestamp statusdate;
    private String piggery;
    private String piggeryname;
}
