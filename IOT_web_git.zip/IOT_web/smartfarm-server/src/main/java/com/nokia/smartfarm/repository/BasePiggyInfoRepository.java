package com.nokia.smartfarm.repository;

import com.nokia.smartfarm.pojo.BasePiggyInfo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Map;

public interface BasePiggyInfoRepository extends JpaRepository<BasePiggyInfo, Long> {

    public List<BasePiggyInfo> findBasePiggyInfoByEarcardEquals(String earcard);

    @Modifying
    @Query(value = "truncate table application.base_piggy_info",nativeQuery = true)
    void truncateTable();

    @Query(value = "select a.id,a.piggery,a.piggeryname from " +
            "(select p.id,bp.piggery,bp.piggeryname from application.piggy p inner join application.base_piggy_info bp on p.earcard=bp.earcard) a " +
            "left join application.pigsty b on a.piggery=b.sn where b.sn is null",nativeQuery = true)
    List<Map<String, Object>> findNoPigstyPiggy();

}
