package com.nokia.smartfarm.util;

public interface AppConst {
    // warning - temperature
    double TEMPERATURE_MAX = 40;
    double TEMPERATURE_MIN = 0;
    double TEMPERATURE_AVERATE_MAX = 2;

    int VALUE_LENGTH = 20;

    String TEMPERATURE_ID = "10255";
    String DEVICE_ID = "3";
    String DEVICE_REBOOT_MESSAGE_ID = "33";
    String DEVICE_REBOOT_MESSAGE_RESOURCE_ID = "16";
    String DEVICE_BATTERY_ID = "9";
    String DEVICE_REBOOT_ID = "30";
    String DEVICE_ERROR_CODE_PATH = "3/0/11";
    String DEVICE_CLEAN_ERROR_CODE_PATH = "3/0/12";
    String CONNECTIVITY_ID = "4";

    /**返回结果状态码*/
    int RESULT_CODE_ERROE_BUSINESS = 1000;//业务逻辑异常
    int RESULT_CODE_ERROE_PARAMETER = 1001;//接口数据验证异常
    int RESULT_CODE_ERROE_UNKNOWN = 500;//未知异常
    int RESULT_CODE_ERROE_FORBIDDEN = 403;//禁止
    int RESULT_CODE_SUCCESS = 200;//成功

}
