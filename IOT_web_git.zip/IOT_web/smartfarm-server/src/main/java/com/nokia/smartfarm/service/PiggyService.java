package com.nokia.smartfarm.service;

import com.nokia.smartfarm.pojo.*;
import com.nokia.smartfarm.pojo.influx.Sensor;
import com.nokia.smartfarm.repository.DynamicSqlQuery;
import com.nokia.smartfarm.repository.GatewayRepository;
import com.nokia.smartfarm.repository.NodeRepository;
import com.nokia.smartfarm.repository.PiggyRepository;
import com.nokia.smartfarm.util.AppEnumUtil;
import org.apache.commons.lang.time.DateFormatUtils;
import org.influxdb.InfluxDB;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;
import org.influxdb.impl.InfluxDBResultMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.Assert;

import java.sql.Timestamp;
import java.util.*;

/**
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/28 14:28
 */
@Service
public class PiggyService {

    @Autowired
    private PiggyRepository piggyRepository;
    @Autowired
    private NodeRepository nodeRepository;
    @Autowired
    private GatewayRepository gatewayRepository;
    @Autowired
    private DynamicSqlQuery dynamicSqlQuery;
    @Autowired
    private InfluxDB influxDB;

    public Long getPiggyCount(){
        return piggyRepository.count();
    }

    public int getAlarmPiggyCount(){
        return piggyRepository.countByAlarmStatusEquals(2);
    }

    public int getSickPiggyCount(){
        return piggyRepository.countByAlarmStatusEquals(3);
    }

    /**
     * 疾病猪只管理-分页
     * @param nextPageNum
     * @param pageSize
     * @return
     */
    public Page<Piggy> findSickPiggyPage(int nextPageNum, int pageSize){
        Pageable pageable = PageRequest.of(nextPageNum - 1, pageSize);
        Page<Piggy> sickPiggy = piggyRepository.findByAlarmStatusEquals(3, pageable);
        return sickPiggy;
    }

    /**
     * 疾病猪只管理-不分页
     * @return
     */
    public List<Map<String, Object>> findAllSickPiggy() {
        List<Map<String, Object>> list = piggyRepository.findAllByAlarmStatusEquals(3);
        return AppEnumUtil.transDiseaseType(list, "dic_value");
    }

    public Piggy save(Piggy piggy) {
        return piggyRepository.save(piggy);
    }

    public Piggy findPiggyByNode(int nodeId) {
        List<Piggy> piggies = piggyRepository.findPiggyByNodeId(nodeId);
        if (piggies != null && piggies.size() > 0) return piggies.get(0);
        return null;
    }

    /**
     * 按条件查找报警猪只
     * @param earcard 耳标
     * @param periodStatus 周期类别
     * @param pigstyId 猪舍id
     * @param alarmStart 报警开始时间
     * @param alarmEnd 报警结束时间
     * @param pageNum 当前页数
     * @param pageSize 每页显示数量
     * @return
     */
    public List filterAlarmPiggy(String earcard, String periodStatus, String pigstyId, String alarmStart, String alarmEnd
            , Long pageNum, Long pageSize, String orderBy, String sortDirection){
        if(pageNum <= 0 || pageSize <= 0) return null;
        List<Map<String, Object>> list = dynamicSqlQuery.filterAlarmPiggy(earcard, periodStatus, pigstyId, alarmStart, alarmEnd, pageNum, pageSize
                , orderBy, sortDirection);
        return AppEnumUtil.transDiseaseType(list, "disease_type");
    }

    /**
     * 按条件查找报警猪只数量
     * @param earcard 耳标
     * @param periodStatus 周期类别
     * @param pigstyId 猪舍id
     * @param alarmStart 报警开始时间
     * @param alarmEnd 报警结束时间
     * @return
     */
    public Number filterAlarmPiggyCount(String earcard, String periodStatus, String pigstyId, String alarmStart, String alarmEnd){
        return dynamicSqlQuery.filterAlarmPiggyCount(earcard, periodStatus, pigstyId, alarmStart, alarmEnd);
    }

    /**
     * 更新猪只报警状态
     * @param piggyIds 批量更新的猪只id
     * @param alarmStatus 报警状态
     * @return
     */
    @Transactional
    public boolean updateAlarmStatus(ArrayList<Long> piggyIds, Long alarmStatus) {
        Assert.notNull(piggyIds, "批量更新的猪只id不能为空！");
        Assert.notNull(alarmStatus, "报警状态不能为空！");
        for(Long id : piggyIds){
            piggyRepository.updateAlarmStatusById(id, alarmStatus);
        }
        return true;
    }

    /**
     * 按条件查找所有猪只
     * @param earcard 耳标
     * @param periodStatus 周期类别
     * @param alarmStart 报警开始时间
     * @param alarmEnd 报警结束时间
     * @param pageNum 当前页数
     * @param pageSize 每页显示数量
     * @param orderby 排序字段
     * @param sortDirection 排序方向
     * @return
     */
    public List filterAllPiggy(String earcard, String periodStatus, String alarmStart, String alarmEnd,
                               Long pageNum, Long pageSize, String orderby, String sortDirection){
        if("ascend".equals(sortDirection)){
            sortDirection = "asc";
        }else if("descend".equals(sortDirection)){
            sortDirection = "desc";
        }else{
            sortDirection = null;
        }
        return dynamicSqlQuery.filterAllPiggy(earcard, periodStatus, alarmStart, alarmEnd, pageNum, pageSize, orderby, sortDirection);
    }

    /**
     * 按条件查找所有猪只数量
     * @param earcard 耳标
     * @param periodStatus 周期类别
     * @param alarmStart 报警开始时间
     * @param alarmEnd 报警结束时间
     * @author pam
     * @return
     */
    public Number filterAllPiggyCount(String earcard, String periodStatus, String alarmStart, String alarmEnd){
        return dynamicSqlQuery.filterAllPiggyCount(earcard, periodStatus, alarmStart, alarmEnd);
    }

    /**
     * 获取猪只温度数据
     * @param timeId 选中的时间周期类别，0：今日，1：本周，2：本月
     * @param piggyId 猪只id
     * @author pam
     * @return
     */
    public List<Sensor> getPiggyTempData(Long timeId, Long piggyId) {
        Assert.notNull(timeId, "时间周期类别不能为空！");
        Assert.notNull(piggyId, "猪只id不能为空！");
        List<Sensor> lists = new ArrayList<Sensor>();

        Piggy piggy = piggyRepository.findFirstByIdEquals(piggyId.intValue());
        if(null == piggy) return lists;
        Integer nodeId = piggy.getNodeId();
        Node node = nodeRepository.findFirstByIdEquals(nodeId);
        if(null == node) return lists;
        String nodeSn = node.getSn();
        Integer gatewayId = node.getGatewayId();
        Gateway gateway = gatewayRepository.findFirstByIdEquals(gatewayId);
        if(null == gateway) return lists;
        String gatewaySn = gateway.getSn();

        String timeSql = " 1=1 ";
        if(timeId == -1){//今日
            timeSql = getStartEndTimeSql(1);
        }else if(timeId == 0){
            timeSql = getStartEndTimeSql(7);
        }else if(timeId == 1){
            timeSql = getStartEndTimeSql(30);
        }
        //获取猪只温度数据
        String sql = new StringBuilder("select time,mmc_temp from sensor where MMC_MAC='")
                .append(nodeSn).append("' and IMEI='").append(gatewaySn).append("' and ").append(timeSql)
                .append(" order by time desc").toString();
        QueryResult qr = influxDB.query(new Query(sql));

		InfluxDBResultMapper mapper = new InfluxDBResultMapper();
        List<Sensor> sensors = mapper.toPOJO(qr, Sensor.class);

        return sensors;
    }

    /**
     * 获取时间sql语句
     * @param delay 时间提前的天数
     * @author pam
     * @return
     */
    private String getStartEndTimeSql(int delay){
        Assert.notNull(delay, "提前天数不能为空！");
        Calendar calendar = Calendar.getInstance();
        String endTime = DateFormatUtils.formatUTC(calendar.getTime(),"yyyy-MM-dd'T'HH:mm:ss'Z'");
        calendar.set(Calendar.DAY_OF_YEAR, calendar.get(Calendar.DAY_OF_YEAR) - delay);
        String startTime = DateFormatUtils.formatUTC(calendar.getTime(),"yyyy-MM-dd'T'HH:mm:ss'Z'");
        return " time > '"+startTime+"' and time < '"+endTime+"' ";
    }

    /**
     * 按条件查找疾病猪只
     * @param pigstyId 猪舍id
     * @param earcard 耳标号
     * @param periodStatus 猪只周期状态
     * @param pageNum 当前页数
     * @param pageSize 每页显示数量
     * @param orderBy 排序字段
     * @param sortDirection 排序方向
     * @author pam
     * @return
     */
    public List filterDiseasePiggy(Long pigstyId, String earcard, String periodStatus, Long pageNum, Long pageSize,
                                   String orderBy, String sortDirection){
        if("-1".equals(periodStatus)){//全部
            periodStatus = null;
        }
        if("ascend".equals(sortDirection)){
            sortDirection = "asc";
        }else if("descend".equals(sortDirection)){
            sortDirection = "desc";
        }else{
            sortDirection = null;
        }
        List<Map<String, Object>> list = dynamicSqlQuery.filterDiseasePiggy(pigstyId, earcard, periodStatus, pageNum, pageSize, orderBy, sortDirection);
        return AppEnumUtil.transDiseaseType(list, "diseasename");
    }

    /**
     * 按条件查找疾病猪只数量
     * @param pigstyId
     * @param earcard 耳标号
     * @param periodStatus 猪只周期状态
     * @return
     */
    public Number filterDiseasePiggyCount(Long pigstyId, String earcard, String periodStatus){
        if("-1".equals(periodStatus)){//全部
            periodStatus = null;
        }
        return dynamicSqlQuery.filterDiseasePiggyCount(pigstyId, earcard, periodStatus);
    }

    /**
     * 根据id删除猪只
     * @param piggyIds 要删除的猪只id集合
     * @author pam
     * @return
     */
    @Transactional
    public boolean deletePiggy(ArrayList<Long> piggyIds){
        Assert.notNull(piggyIds, "要删除的猪只id集合不能为空！");
        for(Long id : piggyIds){
            piggyRepository.deleteById(id.intValue());
        }
        return true;
    }

    /**
     * 根据id重置猪只报警状态
     * @param piggyIds 要重置状态的猪只id集合
     * @author pam
     * @return
     */
    @Transactional
    public boolean deletePiggyAlarmStatus(ArrayList<Long> piggyIds) {
        Assert.notNull(piggyIds, "要重置状态的猪只id集合不能为空！");
        for(Long id : piggyIds){
            piggyRepository.updateAlarmStatusById(id, 0L);
        }
        return true;
    }

    /**
     * 新增或更新猪只信息
     * @param piggy 猪只信息
     * @author pam
     * @return
     */
    @Transactional
    public boolean saveOrUpdatePiggy(Piggy piggy){
        Assert.notNull(piggy, "要保存的猪只不能为null！");
        Piggy pr = null;
        boolean result = true;
        if(null == piggy.getId()){//新增
            piggy.setAlarmStatus(0);
            pr = this.save(piggy);
        }else{//修改
            Optional<Piggy> optional = piggyRepository.findById(piggy.getId());
            if(!optional.isPresent()) return false;
            Piggy p = optional.get();
            p.setNodeId(piggy.getNodeId());
            p.setPeriodStatus(piggy.getPeriodStatus());
            p.setPigstyId(piggy.getPigstyId());
            p.setEntire(piggy.getEntire());
            pr = this.save(p);
        }
        if(null == pr || null == pr.getId()){
            result = false;
        }
        return result;
    }

    /**
     * 根据id获取猪只部分信息
     * @param piggyId 猪只id
     * @author pam
     * @return
     */
    public Map<String, Object> getPiggySomeInfo(Long piggyId) {
        Assert.notNull(piggyId, "piggyId不能为null！");
        return piggyRepository.getPiggySomeInfo(piggyId.intValue());
	}


    /**
     * 根据id获取猪只信息
     * @param piggyId 猪只id
     * @author pam
     * @return
     */
    public Piggy getPiggyInfo(Long piggyId) {
        Assert.notNull(piggyId, "piggyId不能为null！");
        Optional<Piggy> optional = piggyRepository.findById(piggyId.intValue());
        if(!optional.isPresent()) return null;
        return optional.get();
    }
	
	//获取耳标与网关绑定管理列表
    public List<Map<String, Object>> findAllEarBindGateway() {
        return piggyRepository.findAllEarBindGateway();
    }

    //根据条件查询耳标与网关绑定
    public List<Map<String, Object>> findAllEarBindGatewayByEarIdOrPeriod(Long id, Long period) {
        return piggyRepository.findAllEarBindGatewayByEarIdOrPeriod(id, period);
    }

    /**
     * 获取各生产周期报警猪只
     * @return
     */
    public List<Map<String, Object>> getPeriodAlarmPiggyRate() {
        return piggyRepository.findPeriodAlarmPiggyOrderbyNum();
    }


    /**
     * 批量同步更新piggy表信息
     */
    @Transactional
    public void batchUpdateFromBasePiggyInfo() {
        piggyRepository.batchUpdateFromBasePiggyInfo();
    }

    /**
     * 更新猪只的猪舍id
     * @param pigstyId
     * @param id
     */
    public void updatePigstyIdOfPiggy(Integer pigstyId, Integer id) {
        if (null == pigstyId || null == id) return;
        Optional<Piggy> optional = piggyRepository.findById(id);
        if(!optional.isPresent()) return;
        Piggy p = optional.get();
        p.setPigstyId(pigstyId);
        p.setUpdatedAt(new Timestamp(new Date().getTime()));
        piggyRepository.save(p);
    }

    public List<Map<String, Object>> findAvgTemperatureGroupByGateway() {
        return piggyRepository.findAvgTemperatureGroupByGateway();
    }

    public List<Piggy> findPiggyUpdatedInfo() {
        return piggyRepository.findPiggyUpdatedInfo();
    }

    /*获取猪舍与网关已绑定的猪只耳标列表*/
    public List<Map<String, Object>> findEarTagList(){return piggyRepository.findEarTagList();}
    /*获取猪舍与网关已绑定的猪只耳标列表——某猪舍*/
    public List<Map<String, Object>> findEarTagListByPigstyId(Long pigstyId){
        return piggyRepository.findEarTagListByPigstyId(pigstyId);
    }

    /**
     * 更新猪只排查判断，发热病因，采取措施
     * @return
     */
    public boolean updatePiggyAction(Long piggyId, String action, List<String> constIds, String comment){
        Optional<Piggy> optional = piggyRepository.findById(piggyId.intValue());
        if(!optional.isPresent()) return false;
        Piggy p = optional.get();
        String joinConstId = String.join(",", constIds);
        switch (action){
            case "investigate":
                p.setInvestigate(joinConstId);
                p.setComInvest(comment);
                break;
            case "disease_type":
                p.setDiseaseType(joinConstId);
                p.setComDisease(comment);
                break;
            case "measures":
                p.setMeasures(joinConstId);
                p.setComMeas(comment);
                break;
            default: return false;
        }
        this.save(p);
        return true;
    }


}
