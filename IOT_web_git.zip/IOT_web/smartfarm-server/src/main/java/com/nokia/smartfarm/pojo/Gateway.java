package com.nokia.smartfarm.pojo;

import com.nokia.smartfarm.pojo.audit.DateAudit;
import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * 网关信息
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:24
 */
@Entity
@Data
@Table(name = "gateway", schema = "application")
public class Gateway extends DateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String name;   //网关名称
    private String sn;    //网关序列号
    private Integer status;    //网关状态:离线0,在线1
}
