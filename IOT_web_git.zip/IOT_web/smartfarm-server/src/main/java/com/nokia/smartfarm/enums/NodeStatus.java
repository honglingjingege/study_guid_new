package com.nokia.smartfarm.enums;

public enum NodeStatus {
    OFFLINE(0), ONLINE(1);

    private int code;

    NodeStatus(int code) {

        this.code = code;

    }

    public int getCode() {
        return code;
    }
}
