package com.nokia.smartfarm.pojo;

import com.nokia.smartfarm.pojo.audit.DateAudit;
import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * 负责人信息
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:24
 */
@Entity
@Data
@Table(name = "manager", schema = "application")
public class Manager extends DateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String jobNumber;   //工号
    private Integer post;   //岗位
    private String phone;   //手机号
    private String name;   //负责人名称
}
