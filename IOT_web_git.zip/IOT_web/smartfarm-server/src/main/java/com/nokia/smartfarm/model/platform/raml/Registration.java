package com.nokia.smartfarm.model.platform.raml;

import lombok.Data;

public class Registration extends OnOff{
}
