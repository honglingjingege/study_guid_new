package com.nokia.smartfarm.repository;

import org.apache.commons.lang.StringUtils;
import org.hibernate.SQLQuery;
import org.hibernate.transform.Transformers;
import org.springframework.stereotype.Component;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import java.util.List;
import java.util.Map;

/**
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/9/11 13:16
 */
@Component
public class DynamicSqlQuery {

    @PersistenceContext //注入的是实体管理器,执行持久化操作
    EntityManager entityManager;

    //报警猪只-根据筛选条件查找符合的猪只
    public List<Map<String, Object>> filterAlarmPiggy(String earcard, String periodStatus, String pigstyId, String alarmStart, String alarmEnd, Long pageNum, Long pageSize
            , String orderBy, String sortDirection){
        StringBuilder sql = new StringBuilder("select pg.piggy_id as id,pg.earcard,ps.id pigstyid, ps.name as pigstyname, ps.width,ps.high,")
                .append("(select point_x from application.pigstymap pm where pm.gateway_id=pg.gateway_id and pm.pigsty_id = pg.pigsty_id),")
                .append("(select point_y from application.pigstymap pm where pm.gateway_id=pg.gateway_id and pm.pigsty_id = pg.pigsty_id),")
                .append("pg.curr_temp,pg.abs_temp,pg.dod_temp,pg.pop_temp,to_char(pg.alarm_at, 'yyyy-mm-dd hh24:mi:ss') as alarm_at,")
                .append("(select dic_value from application.dictionary d where d.dic_code=pg.period_status and d.dic_cat='101') as periodname,")
                .append("(select dic_value from application.dictionary d where d.dic_code=pg.entire and d.dic_cat='102') as entire,")
                .append("(select name from application.manager m where ps.header_id=m.id) as managername,pg.disease_type")
                .append(" from application.node_piggy_view pg left join application.pigsty ps on pg.pigsty_id=ps.id where pg.alarm_status='2' ");
        if(StringUtils.isNotBlank(earcard)){
            sql.append(" and CAST(pg.earcard AS text) like '%").append(earcard).append("%'");
        }
        if(StringUtils.isNotBlank(periodStatus)){
            sql.append(" and pg.period_status = '").append(periodStatus).append("'");
        }
        if(StringUtils.isNotBlank(pigstyId)  && !pigstyId.contains("-1")){
           if("-2".equals(pigstyId)){//只选了未分配
               sql.append(" and pg.pigsty_id is null ");
           }else if(pigstyId.contains("-2")){//选了未分配和其他猪舍
               sql.append(" and (pg.pigsty_id in (").append(pigstyId).append(") or pg.pigsty_id is null)");
           }else{//只选了其他猪舍
               sql.append(" and pg.pigsty_id in (").append(pigstyId).append(")");
           }
        }
        if(StringUtils.isNotBlank(alarmStart)){
            sql.append(" and pg.alarm_at >= CAST('").append(alarmStart).append("' AS timestamp)");
        }
        if(StringUtils.isNotBlank(alarmEnd)){
            sql.append(" and pg.alarm_at <= CAST('").append(alarmEnd).append("' AS timestamp)");
        }
        if(StringUtils.isNotBlank(orderBy)){
            sql.append(" order by ").append(orderBy);
        }
        if(StringUtils.isNotBlank(orderBy) && StringUtils.isNotBlank(sortDirection)){
            sql.append(" ").append(sortDirection);
        }
        sql.append(" limit ").append(pageSize).append(" offset ").append(pageSize*(pageNum-1));
        //转map对象
        return entityManager.createNativeQuery(sql.toString()).unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP).getResultList();
    }

    //报警猪只-根据筛选条件查找符合的猪只总数
    public Number filterAlarmPiggyCount(String earcard, String periodStatus, String pigstyId, String alarmStart, String alarmEnd){
        StringBuilder sql = new StringBuilder("select count(1) as count from application.node_piggy_view where alarm_status='2' ");
        if(StringUtils.isNotBlank(earcard)){
            sql.append(" and CAST(earcard AS text) like '%").append(earcard).append("%'");
        }
        if(StringUtils.isNotBlank(periodStatus)){
            sql.append(" and period_status = '").append(periodStatus).append("'");
        }
        if(StringUtils.isNotBlank(pigstyId)  && !pigstyId.contains("-1")){
            if("-2".equals(pigstyId)){//只选了未分配
                sql.append(" and pigsty_id is null ");
            }else if(pigstyId.contains("-2")){//选了未分配和其他猪舍
                sql.append(" and (pigsty_id in (").append(pigstyId).append(") or pigsty_id is null)");
            }else{//只选了其他猪舍
                sql.append(" and pigsty_id in (").append(pigstyId).append(")");
            }
        }
        if(StringUtils.isNotBlank(alarmStart)){
            sql.append(" and alarm_at >= CAST('").append(alarmStart).append("' AS timestamp)");
        }
        if(StringUtils.isNotBlank(alarmEnd)){
            sql.append(" and alarm_at <= CAST('").append(alarmEnd).append("' AS timestamp)");
        }
        return (Number)entityManager.createNativeQuery(sql.toString()).getResultList().get(0);
    }

    //所有猪只-根据筛选条件查找符合的猪只
    public List<Map<String, Object>> filterAllPiggy(String earcard, String periodStatus, String alarmStart, String alarmEnd,
                               Long pageNum, Long pageSize, String orderby, String sortDirection){
        StringBuilder sql = new StringBuilder("select pg.piggy_id,pg.earcard,ps.id pigstyid,ps.name as pigstyname,ps.width,ps.high,")
                .append("(select point_x from application.pigstymap pm where pm.gateway_id=pg.gateway_id and pm.pigsty_id = pg.pigsty_id),")
                .append("(select point_y from application.pigstymap pm where pm.gateway_id=pg.gateway_id and pm.pigsty_id = pg.pigsty_id),")
                .append("pg.curr_temp,pg.abs_temp,pg.dod_temp,pg.pop_temp,to_char(pg.alarm_at, 'yyyy-mm-dd hh24:mi:ss') as alarm_at,")
                .append("(select dic_value from application.dictionary d where d.dic_code=pg.period_status and d.dic_cat='101') as periodname,")
                .append("(select name from application.manager m where ps.header_id=m.id) as managername")
                .append(" from application.node_piggy_view pg left join application.pigsty ps on pg.pigsty_id=ps.id where 1=1 ");
        if(StringUtils.isNotBlank(earcard)){
            sql.append(" and CAST(pg.earcard AS text) like '%").append(earcard).append("%'");
        }
        if(StringUtils.isNotBlank(periodStatus)){
            sql.append(" and pg.period_status = '").append(periodStatus).append("'");
        }
        if(StringUtils.isNotBlank(alarmStart)){
            sql.append(" and pg.alarm_at >= CAST('").append(alarmStart).append("' AS timestamp)");
        }
        if(StringUtils.isNotBlank(alarmEnd)){
            sql.append(" and pg.alarm_at <= CAST('").append(alarmEnd).append("' AS timestamp)");
        }
        if(StringUtils.isNotBlank(orderby)){
            sql.append(" order by ").append(orderby);
        }
        if(StringUtils.isNotBlank(orderby) && StringUtils.isNotBlank(sortDirection)){
            sql.append(" ").append(sortDirection);
        }
        sql.append(" limit ").append(pageSize).append(" offset ").append(pageSize*(pageNum-1));
        return entityManager.createNativeQuery(sql.toString()).unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP).getResultList();
    }

    //所有猪只-根据筛选条件查找符合的猪只总数
    public Number filterAllPiggyCount(String earcard, String periodStatus, String alarmStart, String alarmEnd){
        StringBuilder sql = new StringBuilder("select count(1) as count from application.node_piggy_view where 1=1 ");
        if(StringUtils.isNotBlank(earcard)){
            sql.append(" and CAST(earcard AS text) like '%").append(earcard).append("%'");
        }
        if(StringUtils.isNotBlank(periodStatus)){
            sql.append(" and period_status = '").append(periodStatus).append("'");
        }
        if(StringUtils.isNotBlank(alarmStart)){
            sql.append(" and alarm_at >= CAST('").append(alarmStart).append("' AS timestamp)");
        }
        if(StringUtils.isNotBlank(alarmEnd)){
            sql.append(" and alarm_at <= CAST('").append(alarmEnd).append("' AS timestamp)");
        }
        return (Number)entityManager.createNativeQuery(sql.toString()).getResultList().get(0);
    }

    //疾病猪只-根据筛选条件查找符合的猪只
    public List<Map<String, Object>> filterDiseasePiggy(Long pigstyId, String earcard, String periodStatus, Long pageNum, Long pageSize, String orderBy, String sortDirection){
        StringBuilder sql = new StringBuilder("select pg.piggy_id,pg.earcard,ps.id pigstyid,ps.width,ps.high,ps.name as pigstyname,")
                .append("(select point_x from application.pigstymap pm where pm.gateway_id=pg.gateway_id and pm.pigsty_id = pg.pigsty_id),")
                .append("(select point_y from application.pigstymap pm where pm.gateway_id=pg.gateway_id and pm.pigsty_id = pg.pigsty_id),")
                .append("pg.curr_temp,pg.abs_temp,pg.dod_temp,pg.pop_temp,")
                .append("(select dic_value from application.dictionary d where d.dic_code=pg.period_status and d.dic_cat='101') as periodname,")
                .append("disease_type as diseasename")
                .append(" from application.node_piggy_view pg left join application.pigsty ps on pg.pigsty_id=ps.id where alarm_status='3' ");
        if(null != pigstyId){
            sql.append(" and pg.pigsty_id='").append(pigstyId).append("'");
        }
        if(StringUtils.isNotBlank(earcard)){
            sql.append(" and CAST(pg.earcard AS text) like '%").append(earcard).append("%'");
        }
        if(StringUtils.isNotBlank(periodStatus)){
            sql.append(" and pg.period_status = '").append(periodStatus).append("'");
        }
        if(StringUtils.isNotBlank(orderBy)){
            sql.append(" order by ").append(orderBy);
        }
        if(StringUtils.isNotBlank(orderBy) && StringUtils.isNotBlank(sortDirection)){
            sql.append(" ").append(sortDirection);
        }
        sql.append(" limit ").append(pageSize).append(" offset ").append(pageSize*(pageNum-1));
        return entityManager.createNativeQuery(sql.toString()).unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP).getResultList();
    }

    //疾病猪只-根据筛选条件查找符合的猪只总数
    public Number filterDiseasePiggyCount(Long pigstyId, String earcard, String periodStatus){
        StringBuilder sql = new StringBuilder("select count(1) as count from application.node_piggy_view where alarm_status='3' ");
        if(null != pigstyId){
            sql.append(" and pigsty_id='").append(pigstyId).append("'");
        }
        if(StringUtils.isNotBlank(earcard)){
            sql.append(" and CAST(earcard AS text) like '%").append(earcard).append("%'");
        }
        if(StringUtils.isNotBlank(periodStatus)){
            sql.append(" and period_status = '").append(periodStatus).append("'");
        }
        return (Number)entityManager.createNativeQuery(sql.toString()).getResultList().get(0);
    }



    /**
     * 查找猪舍名称和猪舍中报警猪只数量
     * @return
     */
    public List<Map<String, Object>> findNameAndPiggySize(String earcard, String periodStatus, String alarmStart, String alarmEnd){
        StringBuilder sql = new StringBuilder("select c.id,a.count,c.name from(select b.pigsty_id,count(b.id) as count from application.piggy b")
                .append(" where b.alarm_status = '2' ");
        if(StringUtils.isNotBlank(earcard)){
            sql.append(" and CAST(b.earcard AS text) like '%").append(earcard).append("%'");
        }
        if(StringUtils.isNotBlank(periodStatus)){
            sql.append(" and b.period_status = '").append(periodStatus).append("'");
        }
        if(StringUtils.isNotBlank(alarmStart)){
            sql.append(" and b.alarm_at >= CAST('").append(alarmStart).append("' AS timestamp)");
        }
        if(StringUtils.isNotBlank(alarmEnd)){
            sql.append(" and b.alarm_at <= CAST('").append(alarmEnd).append("' AS timestamp)");
        }
        sql.append(" group by b.pigsty_id) a right join application.pigsty c on c.id = a.pigsty_id ");
        return entityManager.createNativeQuery(sql.toString()).unwrap(SQLQuery.class).setResultTransformer(Transformers.ALIAS_TO_ENTITY_MAP).getResultList();
    }


}
