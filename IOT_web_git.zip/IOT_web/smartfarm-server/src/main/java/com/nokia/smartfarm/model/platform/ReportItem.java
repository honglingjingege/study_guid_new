package com.nokia.smartfarm.model.platform;

import com.nokia.smartfarm.model.platform.raml.Report;

public class ReportItem {
    private String serialNumber;
    private String timeStamp;
    private String objectId;
    private String instanceId;
    private ResourcePath resourcePath;
    private ResourceValue resourceValue;

    public ReportItem() {}

    public ReportItem(Report report) {
        ResourcePath resourcePath = new ResourcePath(report.getResourcePath());
        ResourceValue resourceValue = new ResourceValue(report.getValue());
        this.serialNumber = report.getSerialNumber();
        this.timeStamp = report.getTimestamp();
        this.resourcePath = resourcePath;
        this.resourceValue = resourceValue;
    }

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getTimeStamp() {
        return timeStamp;
    }

    public void setTimeStamp(String timeStamp) {
        this.timeStamp = timeStamp;
    }

    public ResourcePath getResourcePath() {
        return resourcePath;
    }

    public void setResourcePath(ResourcePath resourcePath) {
        this.resourcePath = resourcePath;
    }

    public ResourceValue getResourceValue() {
        return resourceValue;
    }

    public void setResourceValue(ResourceValue resourceValue) {
        this.resourceValue = resourceValue;
    }

    public String getObjectId() {
        return this.resourcePath.getObjectId();
    }

    public String getInstanceId() {
        return this.resourcePath.getInstanceId();
    }

    @Override
    public String toString() {
        return "ReportItem{" +
                "serialNumber='" + serialNumber + '\'' +
                ", timeStamp='" + timeStamp + '\'' +
                ", resourcePath=" + resourcePath.toString() +
                ", resourceValue=" + resourceValue.toString() +
                '}';
    }
}
