package com.nokia.smartfarm.model.platform;

public class Resource {
    private String resourcePath;
    private String value;

    public String getResourcePath() {
        return resourcePath;
    }

    public void setResourcePath(String resourcePath) {
        this.resourcePath = resourcePath;
    }

    public String getValue() {
        return value;
    }

    public void setValue(String value) {
        this.value = value;
    }

    @Override
    public String toString() {
        return "Resource{" +
                "resourcePath='" + resourcePath + '\'' +
                ", value='" + value + '\'' +
                '}';
    }
}
