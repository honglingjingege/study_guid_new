package com.nokia.smartfarm.model.platform.raml;

public class Update {
}
