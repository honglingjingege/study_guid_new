package com.nokia.smartfarm.model.platform;

import lombok.Data;

import java.util.List;

@Data
public class DevicesModel {
    private List<DeviceModel> data;
}
