package com.nokia.smartfarm.service.platform.processor;

import com.nokia.smartfarm.model.influx.NodeModelPoint;
import com.nokia.smartfarm.model.platform.BaseModel;
import com.nokia.smartfarm.model.platform.NodeModel;
import lombok.extern.slf4j.Slf4j;
import org.influxdb.InfluxDB;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class StorageProcessor implements Processor {

    @Autowired
    private InfluxDB influxDB;

    @Override
    public void process(List<BaseModel> baseModels) {
//        for (BaseModel model : baseModels) {
//            NodeModel nodeModel = (NodeModel) model;
//            NodeModelPoint nodeModelPoint = new NodeModelPoint(nodeModel);
//            influxDB.write(nodeModelPoint.getPoint());
//            log.info("Influx db -> {} ", nodeModelPoint.toString());
//        }
    }
}
