package com.nokia.smartfarm.model.influx;

import com.nokia.smartfarm.model.TemperatureCalModel;
import com.nokia.smartfarm.model.platform.NodeModel;
import lombok.Data;
import org.influxdb.dto.Point;

import java.util.concurrent.TimeUnit;

@Data
public class GatewayAvgTempPoint {
    Point point;

    public GatewayAvgTempPoint(String serialNumber, double averageTemperature) {
        point = Point.measurement("gateway")
                .time(System.currentTimeMillis(), TimeUnit.MILLISECONDS)
                .tag("sn", serialNumber)
                .addField("avg_temperature", averageTemperature)
                .build();
    }
}
