package com.nokia.smartfarm.service;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.nokia.smartfarm.pojo.PigstyMap;
import com.nokia.smartfarm.repository.GatewayRepository;
import com.nokia.smartfarm.repository.PigstyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.nokia.smartfarm.repository.PigstyMapRepository;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Service
public class PigstyMapService {
    @Autowired
    private PigstyMapRepository pigstyMapRepository;
    @Autowired
    private GatewayRepository gatewayRepository;
    @Autowired
    private PigstyRepository pigstyRepository;
    public List<Map<String, Object>> findAllPigyMapParams() {return pigstyMapRepository.findAllPigyMapParams();}

    @Transactional
    public boolean insertPigstyMap(Long pigstyId, Map<String, Integer> pigstyScale, List<Map<String, Integer>> gatewayList){
        boolean insertResult = true;
        int updatePigstySizeResult = pigstyMapRepository.updatePigstySize(pigstyId, pigstyScale.get("x"), pigstyScale.get("y"));
        if( updatePigstySizeResult != 1){
            return false;
        }
        if (!gatewayList.isEmpty()) {
            for(Map<String, Integer> gateway : gatewayList){
                int updateGatewayLocationResult;
                List list = pigstyMapRepository.findRowByGatewayId(Long.valueOf( gateway.get("gatewayId")));
                if(0 == list.size()){
                    if (-1 == gateway.get("x") && -1 == gateway.get("y")){
                        continue;
                    }else {
                        updateGatewayLocationResult = pigstyMapRepository.insertGatewayAndPigsty(pigstyId, Long.valueOf(gateway.get("gatewayId")), gateway.get("x"), gateway.get("y"));
                    }
                }else{
                    if (-1 == gateway.get("x") && -1 == gateway.get("y")){
                        updateGatewayLocationResult = pigstyMapRepository.ubindGatewayAndPigsty(Long.valueOf( gateway.get("gatewayId")));
                    }else{
                        updateGatewayLocationResult = pigstyMapRepository.updateGatewayLocation(Long.valueOf( gateway.get("gatewayId")), gateway.get("x"), gateway.get("y"));
                    }
                }
                if(updateGatewayLocationResult != 1 ){
                    return false;
                }
            }
        }
        return insertResult;
    }

    //public List<Map<String, Object>> getGatewayListByPigstyId() {return pigstyMapRepository.getGatewayListByPigstyId();}
    /*获取网关列表*/
    public List<Map<String, Object>> getGatewayList() {return gatewayRepository.findGatewayList();}
    /*获取猪只列表*/
    public List<Map<String, Object>> getPigstyList() {return pigstyRepository.findPigstyList();}
    /*获取猪舍网关地图列表*/
    public List<Map<String, Object>> getPigstyGatewayMapList() {return pigstyMapRepository.findPigstyGatewayMapList();}
    /*根据猪舍id获取猪舍网关地图列表*/
    public List<Map<String, Object>> getGatewayMapDataByPigstyId(Long pigstyId) {
        return pigstyMapRepository.getGatewayMapDataByPigstyId(pigstyId);
    }

    //查找猪舍下所有网关位置
    public List<PigstyMap> getGatewayLocationByPigstyId(Integer PigstyId){
        return pigstyMapRepository.findByPigstyIdEquals(PigstyId);
    }

}
