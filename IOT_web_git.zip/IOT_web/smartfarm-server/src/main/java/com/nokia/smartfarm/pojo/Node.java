package com.nokia.smartfarm.pojo;

import com.nokia.smartfarm.pojo.audit.DateAudit;
import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * 耳标（秒秒测）
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:24
 */
@Entity
@Data
@Table(name = "node", schema = "application")
public class Node extends DateAudit {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String sn;    //秒秒测序列号
    private Integer gatewayId;  //网关id
    private String gatewayName;  //网关序列号
    private Integer status;    //节点状态: 0 离线, 1 在线
    private String name;   //秒秒测名称
}
