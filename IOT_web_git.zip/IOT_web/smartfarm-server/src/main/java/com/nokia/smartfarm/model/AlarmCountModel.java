package com.nokia.smartfarm.model;

import lombok.Data;
import redis.clients.jedis.Jedis;

@Data
public class AlarmCountModel {
    int dangerousCount;
    int seriousCount;
    int normalCount;

    public AlarmCountModel(Jedis jedis, String sensorId) {
        this.dangerousCount = calAlarmCount(jedis, "dangerousCount" + sensorId);
        this.seriousCount = calAlarmCount(jedis, "seriousCount" + sensorId);
        this.normalCount = calAlarmCount(jedis, "normalCount" + sensorId);
    }

    public int calAlarmCount(Jedis jedis, String key) {
        try{
            String value = jedis.get(key);
            return Integer.parseInt(value);
        }catch (Exception e) {
//            e.printStackTrace();
            return 0;
        }
    }
}
