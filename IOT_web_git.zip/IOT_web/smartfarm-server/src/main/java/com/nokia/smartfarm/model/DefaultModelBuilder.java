package com.nokia.smartfarm.model;

import com.nokia.smartfarm.enums.AlarmStatus;
import com.nokia.smartfarm.enums.OnOffStatus;
import com.nokia.smartfarm.enums.NodeStatus;
import com.nokia.smartfarm.enums.PeriodStatus;
import com.nokia.smartfarm.pojo.*;
import org.springframework.stereotype.Component;

@Component
public class DefaultModelBuilder {
    public Gateway buildGateway(String serialNumber) {
        return this.buildGateway(serialNumber, OnOffStatus.ONLINE);
    }

    public Gateway buildGateway(String serialNumber, OnOffStatus onOffStatus) {
        Gateway gateway = new Gateway();
        gateway.setName(serialNumber);
        gateway.setSn(serialNumber);
        gateway.setStatus(onOffStatus.getCode());
        return gateway;
    }

    public Node buildNode(String sensorId, Gateway gateway) {
        Node node = new Node();
        node.setName(sensorId);
        node.setSn(sensorId);
        node.setGatewayId(gateway.getId());
        node.setGatewayName(gateway.getName());
        node.setStatus(NodeStatus.ONLINE.getCode());
        return node;
    }

    public Piggy buildPiggy(Node node) {
        Piggy piggy = new Piggy();
        piggy.setNodeId(node.getId());
        piggy.setAlarmStatus(AlarmStatus.NORMAL.getCode());
        return piggy;
    }

    public Pigsty buildPigsty(String pigstyName, String pigstySn) {
        Pigsty pigsty = new Pigsty();
        pigsty.setName(pigstyName);
        pigsty.setSn(pigstySn);
        return pigsty;
    }

    public Piggy buildWithBaseInfo(Piggy piggy, Pigsty pigsty, BasePiggyInfo basePiggyInfo) {
        piggy.setPigstyId(pigsty.getId());
        piggy.setEarcard(basePiggyInfo.getEarcard());
        piggy.setPeriodStatus(PeriodStatus.getByImported(basePiggyInfo.getStatus()).getCode());
        piggy.setImportedPeriodStatus(basePiggyInfo.getStatus());
        piggy.setIndividual(basePiggyInfo.getIndividual());
        piggy.setPeriodStatusDate(basePiggyInfo.getStatusdate());
        return piggy;
    }
}
