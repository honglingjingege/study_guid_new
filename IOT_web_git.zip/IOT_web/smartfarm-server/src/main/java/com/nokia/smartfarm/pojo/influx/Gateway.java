package com.nokia.smartfarm.pojo.influx;

import lombok.Data;
import org.influxdb.annotation.Column;
import org.influxdb.annotation.Measurement;

import java.time.Instant;

@Measurement(name = "gateway")
@Data
public class Gateway {
    @Column(name = "time")
    private Instant t;
    @Column(name = "avg_temperature")
    private double avgTemperature;
}
