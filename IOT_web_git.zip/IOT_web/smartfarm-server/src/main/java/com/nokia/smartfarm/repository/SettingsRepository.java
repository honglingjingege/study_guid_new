package com.nokia.smartfarm.repository;

import com.nokia.smartfarm.pojo.Settings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Map;

/**
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:32
 */
public interface SettingsRepository extends JpaRepository<Settings, Integer> {
    /**
     * 获取setting所有设置参数
     * @return
     */
    @Query(value = "select * from application.settings" ,nativeQuery = true)
    List<Map<String, Object>> findAllSettingParam();

    @Modifying
    @Query(value = "update application.settings set setting_value = ?2 where setting_code = ?1", nativeQuery = true)
    int updateSettingParams(String code , Object value);
}