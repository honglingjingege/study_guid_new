package com.nokia.smartfarm.pojo;

import lombok.Data;

import javax.persistence.*;

/**
 * 数据字典
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:24
 */
@Entity
@Data
@Table(name = "dictionary", schema = "application")
public class Dictionary {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer dicCat;   //分类
    private Integer dicCode;   //编号
    private String dicValue;   //值
}
