package com.nokia.smartfarm.enums;

public enum ImportedPeriodStatus {
    YIPEI("已配", 0), RENSHEN("哺乳", 1), BURU("断奶", 2), KONGHUAI("返情", 3), LIUCHAN("流产", 4), WEIZHI("未知", 99);

    private int code;
    private String name;

    ImportedPeriodStatus(String name, int code) {
        this.name = name;
        this.code = code;

    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public static String getName(int index) {
        for (ImportedPeriodStatus c : ImportedPeriodStatus.values()) {
            if (c.getCode() == index) {
                return c.getName();
            }
        }
        return ImportedPeriodStatus.WEIZHI.getName();
    }

    public static int getCode(String name) {
        for (ImportedPeriodStatus c : ImportedPeriodStatus.values()) {
            if (c.getName() == name) {
                return c.getCode();
            }
        }
        return ImportedPeriodStatus.WEIZHI.getCode();
    }
}
