package com.nokia.smartfarm.repository;

import com.nokia.smartfarm.pojo.Pigsty;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Map;

/**
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:32
 */
public interface PigstyRepository extends JpaRepository<Pigsty, Integer> {
    /**
     * 猪舍报警状态猪只汇总排行-按数量降序
     * @param alarmStatus 报警状态
     * @return
     */
    @Query(value = "select b.psid,b.name,COALESCE(a.num, 0) as num, b.sum, case when b.sum=0 then 0 else round(cast(a.num as numeric)/cast(b.sum as numeric),4) end as rate from" +
            " (select ps.id as psid, count(pg.id) as num from application.pigsty ps inner join application.piggy pg on pg.pigsty_id = ps.id where pg.alarm_status=2 group by psid) a" +
            " right join" +
            " (select ps.id as psid, ps.name, count(pg.id) as sum from application.pigsty ps left join application.piggy pg on pg.pigsty_id = ps.id group by psid) b" +
            " on a.psid = b.psid order by num desc", nativeQuery = true)
    List<Map<String, Object>> findPigstyWithAlarmPiggyOrderbyNum(Long alarmStatus);

	 /**
     * 猪舍报警状态猪只汇总排行-按占比降序
     * @param alarmStatus 报警状态
     * @return
     */
     @Query(value = "select b.psid,b.name,COALESCE(a.num, 0) as num, b.sum, case when b.sum=0 then 0 else round(cast(a.num as numeric)/cast(b.sum as numeric),4) end as rate from" +
             " (select ps.id as psid, count(pg.id) as num from application.pigsty ps inner join application.piggy pg on pg.pigsty_id = ps.id where pg.alarm_status=2 group by psid) a" +
             " right join" +
             " (select ps.id as psid, ps.name, count(pg.id) as sum from application.pigsty ps left join application.piggy pg on pg.pigsty_id = ps.id group by psid) b" +
             " on a.psid = b.psid order by rate desc", nativeQuery = true)
    List<Map<String, Object>> findPigstyWithAlarmPiggyOrderbyRate(Long alarmStatus);

    /**
     * 猪舍报警状态猪只汇总排行-按猪舍名称排序（默认）
     * @param alarmStatus 报警状态
     * @return
     */
    @Query(value = "select b.psid,b.name,COALESCE(a.num, 0) as num, b.sum, case when b.sum=0 then 0 else round(cast(a.num as numeric)/cast(b.sum as numeric),4) end as rate from" +
            " (select ps.id as psid, count(pg.id) as num from application.pigsty ps inner join application.piggy pg on pg.pigsty_id = ps.id where pg.alarm_status=2 group by psid) a" +
            " right join" +
            " (select ps.id as psid, ps.name, count(pg.id) as sum from application.pigsty ps left join application.piggy pg on pg.pigsty_id = ps.id group by psid) b" +
            " on a.psid = b.psid order by b.name desc", nativeQuery = true)
    List<Map<String, Object>> findPigstyWithAlarmPiggyOrderbyName(Long alarmStatus);

    /**
     * 各生产周期报警猪只汇总
     * @return
     */
    @Query(value = "select a.status,a.num,b.sum,round(cast(a.num as numeric)/cast(b.sum as numeric),4) rate from(select p.period_status as status, count(p.id) as num from application.piggy p where p.alarm_status = '2' group by p.period_status) a" +
            " inner join (select p.period_status as status, count(p.id) as sum from application.piggy p group by p.period_status) b" +
            " on a.status = b.status order by num desc", nativeQuery = true)
    List<Map<String, Object>> findLeadtimeWithAlarmPiggy();

    List<Pigsty> findPigstyBySnEquals(String sn);

    /**
     * 获取猪舍列表
     */
    @Query(value = "SELECT * FROM application.pigsty order by id",nativeQuery = true)
    List<Map<String, Object>> findPigstyList();

    /**
     * 获取猪舍(id和名称)列表
     */
    @Query(value = "SELECT id,name FROM application.pigsty order by name",nativeQuery = true)
    List<Map<String, Object>> findPigstyIdAndNameList();

    /**
     * 批量同步更新pigsty表信息
     */
    @Modifying
    @Query(value = "update application.pigsty ps set name=b.piggeryname,updated_at=timestamp without time zone 'now()' " +
            "from (select bp.piggeryname,bp.piggery from application.piggy p inner join application.base_piggy_info bp on p.earcard=bp.earcard) as b " +
            "where ps.sn=b.piggery",nativeQuery = true)
    void batchUpdateFromBasePiggyInfo();

    Pigsty findFirstByIdEquals(Integer pigstyId);

}