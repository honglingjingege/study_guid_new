package com.nokia.smartfarm.util;

public class BinaryUtil {
	public static String getOpposit(String binary) {
		char[] binArray = binary.toCharArray();
		StringBuffer sb = new StringBuffer();
		for (int i = 0; i < binary.length(); i++) {
			if (binArray[i] == '0') {
				sb.append(1);
			} else {
				sb.append(0);
			}
		}
		return sb.toString();
	}

	public static String getNativeNumber(String binaryString) {
		String opposit = getMinusNum(binaryString.length());
		String calutor = binaryAdd(binaryString, getMinusNum(binaryString.length()), false);
		String oppo = getOpposit(calutor);
		char[] num = oppo.toCharArray();
		StringBuffer sb = new StringBuffer();
		for (int i = 1; i < num.length; i++) {
			sb.append(num[i]);
		}
		int result = Integer.parseInt(sb.toString(), 2);
		return "-" + result;
	}

	private static String getMinusNum(int binaryLength) {
		String minNum = "0";
		for (int i = 0; i < binaryLength - 1; i++) {
			minNum = minNum + "1";
		}
		return minNum;
	}

	private static String binaryAdd(String bnum1, String bnum2, boolean overflow) {
		boolean flag = false;
		char[] bb1 = bnum1.toCharArray();
		char[] bb2 = bnum2.toCharArray();
		int maxLength = (bb1.length >= bb2.length ? bb1.length : bb2.length);
		StringBuffer result = new StringBuffer();
		for (int i = 0; i < maxLength; i++) {
			if (flag) {
				int temp1 = Integer.parseInt(bb1[bb1.length - i - 1] + "");
				int temp2 = Integer.parseInt(bb2[bb2.length - i - 1] + "");
				flag = (temp1 + temp2 + 1 > 1 ? true : false);

				if (flag) {
					result.append(temp1 + temp2 + 1 == 2 ? '0' : '1');
				} else {
					result.append('1');
				}

			} else {
				int temp1 = Integer.parseInt(bb1[bb1.length - i - 1] + "");
				int temp2 = Integer.parseInt(bb2[bb2.length - i - 1] + "");
				flag = (temp1 + temp2 > 1 ? true : false);
				if (flag) {
					result.append('0');
				} else {
					int temp3 = (temp1 + temp2);
					result.append(temp3 == 0 ? '0' : '1');
				}
			}

		}
		if (overflow && flag && bb1.length == bb2.length) {
			result.append('1');
		}
		return result.reverse().toString();
	}
}