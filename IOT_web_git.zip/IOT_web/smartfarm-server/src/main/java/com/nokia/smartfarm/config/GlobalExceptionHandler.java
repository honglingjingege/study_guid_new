package com.nokia.smartfarm.config;

import com.nokia.smartfarm.model.BusinessException;
import com.nokia.smartfarm.model.ParameterException;
import com.nokia.smartfarm.model.Result;
import com.nokia.smartfarm.util.AppConst;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;

@ControllerAdvice
@Slf4j
public class GlobalExceptionHandler {

    /**
     * 处理所有接口数据验证异常
     * @param e
     * @return
     */
    @ExceptionHandler(ParameterException.class)
    @ResponseBody
    Result handleMethodArgumentNotValidException(ParameterException e){
        return Result.error(e.getMessage(), AppConst.RESULT_CODE_ERROE_PARAMETER);
    }

    /**
     * 处理所有业务异常
     * @param e
     * @return
     */
    @ExceptionHandler(BusinessException.class)
    @ResponseBody
    Result handleBusinessException(BusinessException e){
        return Result.error(e.getMessage(), AppConst.RESULT_CODE_ERROE_BUSINESS);
    }

    /**
     * 处理所有不可知的异常
     * @param e
     * @return
     */
    @ExceptionHandler(Exception.class)
    @ResponseBody
    Result handleException(Exception e){
        log.error(e.getMessage(), e);
        return Result.error("响应错误", AppConst.RESULT_CODE_ERROE_UNKNOWN);
    }

}