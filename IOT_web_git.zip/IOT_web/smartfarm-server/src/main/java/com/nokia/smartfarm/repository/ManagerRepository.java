package com.nokia.smartfarm.repository;

import com.nokia.smartfarm.pojo.Manager;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:32
 */
public interface ManagerRepository extends JpaRepository<Manager, Integer> {

}