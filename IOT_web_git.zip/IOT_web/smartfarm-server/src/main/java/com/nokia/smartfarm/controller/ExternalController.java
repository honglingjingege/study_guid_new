package com.nokia.smartfarm.controller;

import com.nokia.smartfarm.enums.DiseaseStatus;
import com.nokia.smartfarm.enums.InvestigateStatus;
import com.nokia.smartfarm.enums.MeasuresStatus;
import com.nokia.smartfarm.model.ParameterException;
import com.nokia.smartfarm.pojo.Pigsty;
import com.nokia.smartfarm.pojo.PigstyMap;
import com.nokia.smartfarm.service.*;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.*;

@RestController
@RequestMapping("/ext")
public class ExternalController {
    @Autowired
    private PiggyService piggyService;
    @Autowired
    private PigstyService pigstyService;
    @Autowired
    private PigstyMapService pigstyMapService;
    @Autowired
    private GatewayService gatewayService;
    @Autowired
    private NodeService nodeService;
    @Autowired
    private NpMapService npMapService;

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/getHomeCardsInfo", method = RequestMethod.GET)
    public Map<String, Object> getHomeCardsInfo() {
        Map<String, Object> result = new HashMap<String, Object>();
        //报警猪只数量，疾病猪只数量，猪只总数
        int alarmPiggyCount = piggyService.getAlarmPiggyCount();
        int diseasePiggyCount = piggyService.getSickPiggyCount();
        Long piggyCount = piggyService.getPiggyCount();
        //环境温度，环境湿度(暂不提供)
//        Map<String, Object> latestTempAndHumidity = environmentService.getLatestTempAndHumidity();
        //异常网关数量，异常耳标数量
        int errorGatewayCount = gatewayService.getErrorGatewayCount();
        int errorNodeCount = nodeService.getErrorNodeCount();

        result.put("alarmPiggyCount", alarmPiggyCount);
        result.put("diseasePiggyCount", diseasePiggyCount);
        result.put("piggyCount", piggyCount);
//        result.putAll(latestTempAndHumidity);
        result.put("errorGatewayCount", errorGatewayCount);
        result.put("errorNodeCount", errorNodeCount);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/getPigstyWithAlarmPiggy", method = RequestMethod.GET)
    public Map<String, Object> getPigstyWithAlarmPiggy(String orderBy) {
        Map<String, Object> result = new HashMap<String, Object>();
        //各猪舍报警猪只数量和所占百分比（按报警数量降序和按报警占比降序）
        List<Map<String, Object>> pigstyWithAlarmPiggy = pigstyService.findPigstyWithAlarmPiggy(orderBy);
        result.put("result", pigstyWithAlarmPiggy);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN')")
    @RequestMapping(value = "/getPigstyWithDiseasePiggy", method = RequestMethod.GET)
    public Map<String, Object> getPigstyWithDiseasePiggy(String orderBy) {
        Map<String, Object> result = new HashMap<String, Object>();
        //各猪舍疾病猪只数量和所占百分比（按疾病数量降序和按疾病占比降序）
        List<Map<String, Object>> pigstyWithAlarmPiggy = pigstyService.findPigstyWithDiseasePiggy(orderBy);
        result.put("result", pigstyWithAlarmPiggy);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/getPiggyInfo", method = RequestMethod.GET)
    public Map<String, Object> getPiggyInfo(@RequestParam Long piggyId) {
        //猪只耳号，猪舍号，网关位置，当前温度，绝对温差，同比温差，环比温差
        //排查判断常量，发热病因常量，采取措施常量，和各个已选中的值
        Map<String, Object> result = new HashMap<String, Object>();
        Map<String, Object> temp = piggyService.getPiggySomeInfo(piggyId);
        result.put("piggyInfo", temp);
        result.put("diseaseStatus", DiseaseStatus.getStatusList());
        result.put("investigateStatus", InvestigateStatus.getStatusList());
        result.put("measuresStatus", MeasuresStatus.getStatusList());
        return result;
    }


    @PreAuthorize("hasAnyAuthority('ADMIN')")
    @RequestMapping(value = "/getAlarmPiggyList", method = RequestMethod.POST)
    public Map<String, Object> getAlarmPiggyList(Long pigstyId, @RequestParam Long pageNum, @RequestParam Long pageSize, String orderBy, String sortDirection) {
        Map<String, Object> result = new HashMap<String, Object>();
        String[] orderBys = {"curr_temp","abs_temp","dod_temp","pop_temp"};
        if(null != orderBy && !Arrays.asList(orderBys).contains(orderBy)){orderBy = null;}
        String[] sortDirections = {"asc","desc"};
        if(null != sortDirection && !Arrays.asList(sortDirections).contains(sortDirection)){sortDirection = null;}
        String pidStr = null == pigstyId ? null : String.valueOf(pigstyId);

        //报警猪只列表
        List<Map<String, Object>> alarmPiggyList = piggyService.filterAlarmPiggy(null, null, pidStr, null
                , null, pageNum, pageSize, orderBy, sortDirection);
        Number filterCount = piggyService.filterAlarmPiggyCount(null, null, pidStr, null, null);

        result.put("alarmPiggyList", alarmPiggyList);
        result.put("alarmPiggyCount", filterCount);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/getPigstyLocation", method = RequestMethod.GET)
    public Map<String, Object> getPigstyLocation(@RequestParam String sn) throws Exception {
        if(StringUtils.isBlank(sn)) throw new ParameterException("猪舍编号不能为空！");

        //猪舍长宽，猪舍所有gateway位置x，y集合
        Map<String, Object> result = new HashMap<String, Object>();
        Pigsty pigsty = pigstyService.findPigstyBySn(sn);
        if (null == pigsty) return result;
        List<PigstyMap> temp = pigstyMapService.getGatewayLocationByPigstyId(pigsty.getId());
        result.put("gatewayList", temp);
        result.put("width", pigsty.getWidth());
        result.put("high", pigsty.getHigh());
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/saveActionToPiggy", method = RequestMethod.POST)
    public Map<String, Object> saveActionToPiggy(@RequestParam Long piggyId, @RequestParam String action
            , @RequestParam("constIds") List<String> constIds, String comment) {
        //保存排查判断，保存发热病因，保存采取措施
        Map<String, Object> result = new HashMap<String, Object>();
        boolean flag = piggyService.updatePiggyAction(piggyId, action, constIds, comment);
        result.put("success", flag);
        return result;
    }


    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/getDiseasePiggyList", method = RequestMethod.GET)
    public Map<String, Object> getDiseasePiggyList(Long pigstyId, @RequestParam Long pageNum, @RequestParam Long pageSize
            , String orderBy, String sortDirection) {
        //疾病猪只总数，列表
        Map<String, Object> result = new HashMap<String, Object>();
        String[] orderBys = {"curr_temp","abs_temp","dod_temp","pop_temp"};
        if(null != orderBy && !Arrays.asList(orderBys).contains(orderBy)){orderBy = null;}

        List diseasePiggyPage = piggyService.filterDiseasePiggy(pigstyId, null, null
                , pageNum, pageSize, orderBy, sortDirection);
        Number diseasePiggyCount = piggyService.filterDiseasePiggyCount(pigstyId, null, null);
        result.put("diseasePiggyList", diseasePiggyPage);
        result.put("diseasePiggyCount", diseasePiggyCount);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/getAllPigstyInfo", method = RequestMethod.GET)
    public Map<String, Object> getAllPigstyInfo() {
        //全部猪舍名称和id
        Map<String, Object> result = new HashMap<String, Object>();
        List<Map<String, Object>> allPigstyInfo = pigstyService.findPigstyIdAndNameList();
        result.put("allPigstyInfo", allPigstyInfo);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/saveBinding", method = RequestMethod.POST)
    public Map<String, Object> saveBinding(@RequestParam String earcard, @RequestParam String sn) {
        if(StringUtils.isBlank(earcard) || StringUtils.isBlank(sn)) throw new ParameterException("猪只id或耳标号不能为空！");
        //绑定猪只id和耳标
        Map<String, Object> result = new HashMap<String, Object>();
        boolean flag = npMapService.bindingEarcardAndSn(earcard, sn);
        result.put("success", flag);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/getErrorGWList", method = RequestMethod.GET)
    public Map<String, Object> getErrorGWList(Long pigstyId) {
        //异常网关数量，网关列表
        Map<String, Object> result = new HashMap<String, Object>();
        List<Map<String, Object>> list = null;
        if(null == pigstyId){
            list = gatewayService.findBindedGatewayList();
        }else{
            list = gatewayService.findBindedGatewayListByPigstyId(pigstyId);
        }
        result.put("errorGWList", list);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/getErrorTagList", method = RequestMethod.GET)
    public Map<String, Object> getErrorTagList(Long pigstyId) {
        //异常耳标数量，耳标列表
        Map<String, Object> result = new HashMap<String, Object>();
        List<Map<String, Object>> list = null;
        if(null == pigstyId){
            list = piggyService.findEarTagList();
        }else{
            list = piggyService.findEarTagListByPigstyId(pigstyId);
        }
        result.put("errorTagList", list);
        return result;
    }
}

//    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
//    @RequestMapping(value = "/getTempAndHumidityInfo", method = RequestMethod.GET)
//    public Map<String, Object> getTempAndHumidityInfo(){
//        Map<String, Object> result = new HashMap<String, Object>();
//        //当前温度和时间
//        Map<String, Object> latestTempAndTime = environmentService.getLatestTempAndTime();
//        //过去5天温度区间
//        List<Map<String, Object>> newestNDaysTemp = environmentService.getNewestNDaysTemp(5);
//        //过去24小时整点平均温度和湿度值
//        List<Map<String, Object>> latestNHourAveTempAndTime = environmentService.getLatestNHourAveTempAndTime(24);
//
//        result.put("latestTempAndTime", latestTempAndTime);
//        result.put("newestNDaysTemp", newestNDaysTemp);
//        result.put("latestNHourAveTempAndTime", latestNHourAveTempAndTime);
//        return result;
//    }

//    @PreAuthorize("hasAnyAuthority('ADMIN')")
//    @RequestMapping(value = "/getPigstyWithDiseasePiggyOrderbyRate", method = RequestMethod.GET)
//    public List<Map<String, Object>> getPigstyWithDiseasePiggy(@RequestParam String orderBy){
//        //当前温度和时间
//        return pigstyService.findPigstyWithDiseasePiggy(orderBy);
//    }

