package com.nokia.smartfarm.pojo.influx;

import org.influxdb.annotation.Column;
import org.influxdb.annotation.Measurement;

import java.time.Instant;

@Measurement(name = "sensor")
public class Sensor{
    @Column(name = "time")
    private Instant t;
    @Column(name = "mmc_temp")
    private String mmcTemp;

    public Instant getT() { return t; }
    public void setT(Instant t) {
        this.t = t;
    }
    public String getMmcTemp() {
        return mmcTemp;
    }
    public void setMmcTemp(String mmcTemp) {
        this.mmcTemp = mmcTemp;
    }
}
