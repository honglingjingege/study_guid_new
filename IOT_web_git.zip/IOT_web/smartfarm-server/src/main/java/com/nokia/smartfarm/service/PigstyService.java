package com.nokia.smartfarm.service;

import com.nokia.smartfarm.pojo.Pigsty;
import com.nokia.smartfarm.repository.DynamicSqlQuery;
import com.nokia.smartfarm.repository.PigstyRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/28 14:28
 */
@Service
public class PigstyService {

    //猪舍报警猪只汇总排行图表数据条数限制
    private final Long alarmLimit = 7L;
    //猪舍疾病猪只汇总排行图表数据条数限制
    private final Long diseaseLimit = 8L;

    @Autowired
    private PigstyRepository pigstyRepository;
    @Autowired
    private DynamicSqlQuery dynamicSqlQuery;

    /**
     * 猪舍报警猪只汇总排行-降序
     * @return
     */
    public List<Map<String, Object>> findPigstyWithAlarmPiggy(String orderBy) {
        List<Map<String, Object>> list = null;
        if("num".equals(orderBy)){
            list = pigstyRepository.findPigstyWithAlarmPiggyOrderbyNum(2L);
        } else if("rate".equals(orderBy)){
            list = pigstyRepository.findPigstyWithAlarmPiggyOrderbyRate(2L);
        } else {
            list = pigstyRepository.findPigstyWithAlarmPiggyOrderbyRate(2L);
        }
        return list;
    }


    /**
     * 猪舍疾病猪只汇总排行-降序
     * @return
     */
    public List<Map<String, Object>> findPigstyWithDiseasePiggy(String orderBy){
        List<Map<String, Object>> list = null;
        if("rate".equals(orderBy)){
            list = pigstyRepository.findPigstyWithAlarmPiggyOrderbyRate(3L);
        }else if("num".equals(orderBy)){
            list = pigstyRepository.findPigstyWithAlarmPiggyOrderbyNum(3L);
        }else{
            list = pigstyRepository.findPigstyWithAlarmPiggyOrderbyName(3L);
        }
        return list;
    }

    public Pigsty save(Pigsty pigsty) {
       return pigstyRepository.save(pigsty);
    }


    public Pigsty findPigstyBySn(String sn) {
        List<Pigsty> pigsties = pigstyRepository.findPigstyBySnEquals(sn);
        if(pigsties != null && pigsties.size()>0) return pigsties.get(0);
        return null;
    }

    /**
     * 报警猪只列表-猪舍附带其中报警猪只数量
     * @return
     */
    public List<Map<String, Object>> getPigstyWithAlarmPiggy(String earcard, String periodStatus, String alarmStart, String alarmEnd){
        return dynamicSqlQuery.findNameAndPiggySize(earcard, periodStatus, alarmStart, alarmEnd);
    }

    /**
     * 查找所有猪舍
     * @return
     */
    public List<Pigsty> getAllPigsty(){
        return pigstyRepository.findAll();
    }

    public List<Map<String, Object>> findPigstyList(){
        return  pigstyRepository.findPigstyList();
    }
    /**
     * 批量同步更新pigsty表信息
     */
    @Transactional
    public void batchUpdateFromBasePiggyInfo() {
        pigstyRepository.batchUpdateFromBasePiggyInfo();
    }

    /**
     * 根据猪舍id查找猪舍
     * @param pigstyId
     * @return
     */
    public Pigsty findFirstByIdEquals(Integer pigstyId){
        Pigsty pigsty = pigstyRepository.findFirstByIdEquals(pigstyId);
        if(null == pigsty) return new Pigsty();
        return pigsty;
    }

    /**
     * 查找所有猪舍的id和name
     * @return
     */
    public List<Map<String, Object>> findPigstyIdAndNameList(){
        return pigstyRepository.findPigstyIdAndNameList();
    }
}
