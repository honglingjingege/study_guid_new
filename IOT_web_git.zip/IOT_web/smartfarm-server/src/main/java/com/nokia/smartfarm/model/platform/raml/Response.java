package com.nokia.smartfarm.model.platform.raml;

import com.nokia.smartfarm.model.platform.Resource;
import com.nokia.smartfarm.model.platform.Result;

import java.util.List;

public class Response {
    private String serialNumber;
    private String timestamp;
    private String requestId;
    private String creationDate;
    private List<Resource> resources;
    private Result result;

    public String getSerialNumber() {
        return serialNumber;
    }

    public void setSerialNumber(String serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    public List<Resource> getResources() {
        return resources;
    }

    public void setResources(List<Resource> resources) {
        this.resources = resources;
    }

    public Result getResult() {
        return result;
    }

    public void setResult(Result result) {
        this.result = result;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getCreationDate() {
        return creationDate;
    }

    public void setCreationDate(String creationDate) {
        this.creationDate = creationDate;
    }

    @Override
    public String toString() {
        return "Response{" +
                "serialNumber='" + serialNumber + '\'' +
                ", timestamp='" + timestamp + '\'' +
                ", requestId='" + requestId + '\'' +
                ", creationDate='" + creationDate + '\'' +
                ", resources=" + resources +
                ", result=" + result.toString() +
                '}';
    }
}
