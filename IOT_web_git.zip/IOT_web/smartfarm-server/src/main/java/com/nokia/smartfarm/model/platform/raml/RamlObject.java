package com.nokia.smartfarm.model.platform.raml;

import lombok.Data;

import java.util.List;

@Data
public class RamlObject {
    private List<Report> reports;
    private List<OnOff> registrations;
    private List<OnOff> deregistrations;
    private List<Update> updates;
    private List<Expiration> expirations;
    private List<Response> responses;
    private List<OnOff> activations;

    @Override
    public String toString() {
        return "RamlObject{" +
                "reports=" + reports +
                ", registrations=" + registrations +
                ", deregistrations=" + deregistrations +
                ", updates=" + updates +
                ", expirations=" + expirations +
                ", responses=" + responses +
                ", activations=" + activations +
                '}';
    }
}
