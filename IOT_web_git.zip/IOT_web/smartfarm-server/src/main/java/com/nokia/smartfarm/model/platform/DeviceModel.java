package com.nokia.smartfarm.model.platform;

import lombok.Data;

@Data
public class DeviceModel {
    private String name;
    private String type;
}
