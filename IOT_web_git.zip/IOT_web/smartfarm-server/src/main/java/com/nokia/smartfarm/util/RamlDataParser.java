package com.nokia.smartfarm.util;

import com.nokia.smartfarm.model.platform.raml.Report;
import com.nokia.smartfarm.model.platform.ReportItem;
import com.nokia.smartfarm.model.platform.BaseModel;
import com.nokia.smartfarm.model.platform.NodeModel;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.List;

@Slf4j
public class RamlDataParser {
    public static List<BaseModel> parseReport(List reports) {
        List<BaseModel> nodeModels = parseItems2Models(reports);
        return nodeModels;
    }

    private static List<BaseModel> parseItems2Models(List<Report> reports) {
        log.info("**********  Start parsing report to models   **********");
        List<BaseModel> result = new ArrayList<>();
        reports.forEach(report -> {
            List<BaseModel> nodeModels = parseItem2Model(report);
            result.addAll(nodeModels);
        });
        log.info("***********       End parsing to model       **********");
        return result;
    }

    private static List<BaseModel> parseItem2Model(Report report){
        ReportItem reportItem = new ReportItem(report);
        String resourceValue = reportItem.getResourceValue().getValue();
        if(resourceValue == null) {
            log.warn("value is null");
            return new ArrayList<>();
        }
        if(resourceValue.length() % AppConst.VALUE_LENGTH != 0 ){
            log.warn("value's length is incorrect, length is -> {}", resourceValue.length());
            return new ArrayList<>();
        }

        List<BaseModel> nodeModels = new ArrayList<>();
        for(int i = 0; i + AppConst.VALUE_LENGTH <= resourceValue.length(); i += AppConst.VALUE_LENGTH ){
            String nodeValue = resourceValue.substring(i, i + AppConst.VALUE_LENGTH);
            BaseModel nodeModel = new NodeModel(reportItem, nodeValue);
            log.info(nodeModel.toString());
            nodeModels.add(nodeModel);
        }
        Debug.debug4Summary(nodeModels);
        return nodeModels;
    }
}
