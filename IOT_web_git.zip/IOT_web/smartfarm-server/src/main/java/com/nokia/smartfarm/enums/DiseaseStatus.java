package com.nokia.smartfarm.enums;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public enum DiseaseStatus {
    XIAOHUADAOJIBING("消化道疾病", 0), PIFUBING("皮肤病", 1), SHENGZHIXITONGJIBING("生殖系统疾病", 2)
    , BUMINGFARE("不明发热", 3), HUXIDAOJIBING("呼吸道疾病", 4), WEIZHI("未知", 99);

    private int code;
    private String name;
    private static final List<Map<String, Object>> statusList;

    static {
        DiseaseStatus[] types = DiseaseStatus.values();
        statusList = new ArrayList<Map<String, Object>>();
        Map<String, Object> map = null;
        for (DiseaseStatus type : types) {
            map = new HashMap<String, Object>();
            map.put("name", type.getName());
            map.put("code", type.getCode());
            statusList.add(map);
        }
    }

    DiseaseStatus(String name, int code) {
        this.name = name;
        this.code = code;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public static List<Map<String, Object>> getStatusList() { return statusList; }

    public static String translate(int code) {
        switch(code) {
            case 0 : return DiseaseStatus.XIAOHUADAOJIBING.name;
            case 1 : return DiseaseStatus.PIFUBING.name;
            case 2 : return DiseaseStatus.SHENGZHIXITONGJIBING.name;
            case 3 : return DiseaseStatus.BUMINGFARE.name;
            case 4 : return DiseaseStatus.HUXIDAOJIBING.name;
            default: return DiseaseStatus.WEIZHI.name;
        }
    }

    public static List<Map<String, Object>> toMapList(){




        return null;
    }
}
