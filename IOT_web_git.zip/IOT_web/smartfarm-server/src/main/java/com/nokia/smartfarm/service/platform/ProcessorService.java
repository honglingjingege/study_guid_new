package com.nokia.smartfarm.service.platform;


import com.nokia.smartfarm.config.SystemConfig;
import com.nokia.smartfarm.enums.OnOffStatus;
import com.nokia.smartfarm.model.DefaultModelBuilder;
import com.nokia.smartfarm.model.platform.BaseModel;
import com.nokia.smartfarm.model.platform.raml.Activation;
import com.nokia.smartfarm.model.platform.raml.OnOff;
import com.nokia.smartfarm.pojo.Gateway;
import com.nokia.smartfarm.service.GatewayService;
import com.nokia.smartfarm.service.platform.processor.AlarmProcessor;
import com.nokia.smartfarm.service.platform.processor.AutoCreationProcessor;
import com.nokia.smartfarm.service.platform.processor.BindingProcessor;
import com.nokia.smartfarm.service.platform.processor.StorageProcessor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class ProcessorService {

    @Autowired
    StorageProcessor storageProcessor;

    @Autowired
    AutoCreationProcessor autoCreationProcessor;

    @Autowired
    AlarmProcessor alarmProcessor;

    @Autowired
    BindingProcessor bindingProcessor;

    @Autowired
    GatewayService gatewayService;

    @Autowired
    PlatformIntService platformIntService;

    @Autowired
    DefaultModelBuilder defaultModelBuilder;

    public void processReports(List<BaseModel> baseModels) {
//        storageProcessor.process(baseModels);
        autoCreationProcessor.process(baseModels);
        alarmProcessor.process(baseModels);
        bindingProcessor.process(baseModels);

    }

    public void processOnlineEvent(List<OnOff> registrations) {
//        this.processOnOff(registrations, OnOffStatus.ONLINE);
        SystemConfig config = SystemConfig.getInstance();
        int reportInterval = config.getInt(SystemConfig.Keys.REPORT_INTERVAL);
        try {
            Thread.sleep(5000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        for(OnOff onOff : registrations) {
            String sn = onOff.getDeviceName();
            platformIntService.write(sn, reportInterval * 60);
        }
    }

    public void processOfflineEvent(List<OnOff> deregistrations) {
        this.processOnOff(deregistrations, OnOffStatus.OFFLINE);
    }

    private void processOnOff(List<OnOff> onOffs, OnOffStatus gatewayStatus) {
        for(OnOff onOff : onOffs) {
            String sn = onOff.getDeviceName();
            Gateway gateway = gatewayService.findGatewayBySn(sn);
            if(gateway != null){
                gateway.setStatus(gatewayStatus.getCode());
                gatewayService.save(gateway);
            }else {
                gateway = defaultModelBuilder.buildGateway(sn, gatewayStatus);
                gatewayService.save(gateway);
            }
        }
    }

    public void processActiveEvent(List<OnOff> activations) {
        this.processOnOff(activations, OnOffStatus.ONLINE);
    }
}
