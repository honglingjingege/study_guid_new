package com.nokia.smartfarm.model;

import com.nokia.smartfarm.config.SystemConfig;
import com.nokia.smartfarm.model.influx.GatewayCalModel;
import com.nokia.smartfarm.pojo.Piggy;
import com.nokia.smartfarm.pojo.influx.Gateway;
import com.nokia.smartfarm.pojo.influx.Sensor;
import com.nokia.smartfarm.service.HisDataService;
import com.nokia.smartfarm.service.InfluxHisDataService;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import redis.clients.jedis.Jedis;

import java.math.BigDecimal;

@Data
@Slf4j
@Component
public class TemperatureCalModel {
    double currentTemperature;
    double popTemperature;
    double dodTemperature;
    double groupCurrentTemperature;
    double groupPopTemperature;
    double groupDodTemperature;

    double absDiff;
    double popDiff;
    double dodDiff;

    @Autowired
    InfluxHisDataService hisDataService;

    public void init(String nodeSn, String gatewaySn, double currentTemperature) {
        this.currentTemperature = currentTemperature;
        Sensor sensorDoD = hisDataService.findNodeDoD(gatewaySn, nodeSn);
        Sensor sensorPoP = hisDataService.findNodePoP(gatewaySn, nodeSn);
        Gateway gatewayDoD = hisDataService.findGatewayDoD(gatewaySn);
        GatewayCalModel gatewayCalModel = hisDataService.findGatewayCalModel(gatewaySn);
        this.popTemperature = getSensorValue(sensorPoP);
        this.dodTemperature = getSensorValue(sensorDoD);
        this.groupCurrentTemperature =  new BigDecimal(gatewayCalModel.getCurrent()).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
        this.groupPopTemperature = new BigDecimal(gatewayCalModel.getPop()).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
        this.groupDodTemperature = new BigDecimal(gatewayDoD.getAvgTemperature()).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();

        this.absDiff = new BigDecimal(currentTemperature - groupCurrentTemperature).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
        this.popDiff = new BigDecimal((currentTemperature - popTemperature) - (groupCurrentTemperature - groupPopTemperature)).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
        this.dodDiff = new BigDecimal((currentTemperature - dodTemperature) - (groupCurrentTemperature - groupDodTemperature)).setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
        log.info("{} , {} , Calculate temperature -> {}",gatewaySn, nodeSn, this.toString());
    }

    private double getSensorValue(Sensor sensor) {
        if(sensor == null) return this.currentTemperature;
        else {
            try {
                return Double.parseDouble(sensor.getMmcTemp());
            }catch (Exception e) {
                e.printStackTrace();
                return this.currentTemperature;
            }

        }
    }

    public double calTemperature(Jedis jedis, String key, long start, long stop) {
        try {
            log.info("key -> {},start -> {}, stop -> {}", key, start, stop);
            log.info("value -> {}", jedis.lrange(key, start, stop));
            return Double.parseDouble(jedis.lrange(key, start, stop).get(0));
        } catch (Exception e) {
//            e.printStackTrace();
            return this.currentTemperature;
        }
    }

    public int calAlarmCount() {
        SystemConfig config = SystemConfig.getInstance();
        double alarmAbsLowTempDiff = config.getDouble(SystemConfig.Keys.ALARM_ABS_LOW_TEMP_DIFF),
                alarmAbsHighTempDiff = config.getDouble(SystemConfig.Keys.ALARM_ABS_HIGH_TEMP_DIFF),
                alarmDoDHighTempDiff = config.getDouble(SystemConfig.Keys.ALARM_DOD_HIGH_TEMP_DIFF),
                alarmDoDLowTempDiff = config.getDouble(SystemConfig.Keys.ALARM_DOD_LOW_TEMP_DIFF),
                alarmPoPHighTempDiff = config.getDouble(SystemConfig.Keys.ALARM_POP_HIGH_TEMP_DIFF),
                alarmPoPLowTempDiff = config.getDouble(SystemConfig.Keys.ALARM_POP_LOW_TEMP_DIFF);
        log.info("alarmAbsLowTempDiff -> {}", alarmAbsLowTempDiff);
        int count = 0;
        if (compareByAbs(this.getAbsDiff(), alarmAbsLowTempDiff ) || compareByAbs(this.getAbsDiff(), alarmAbsHighTempDiff )) count = count + 1;
        if (compareByAbs(this.getDodDiff(), alarmDoDLowTempDiff ) || compareByAbs(this.getDodDiff(), alarmDoDHighTempDiff )) count = count + 1;
        if (compareByAbs(this.getPopDiff(), alarmPoPLowTempDiff ) || compareByAbs(this.getPopDiff(), alarmPoPHighTempDiff )) count = count + 1;
        log.info("count  -> {}", count);
        return count;
    }

    public boolean compareByAbs(double a, double b) {
        return Math.abs(a) - Math.abs(b) > 0;
    }

    public void store(Jedis jedis, String sensorId, int reportInterval) {
        String singleTempKey = "temperature" + sensorId;
        jedis.lpush(singleTempKey, String.valueOf(this.getCurrentTemperature()));
        int fullCount = 24 * 60 / reportInterval;
        jedis.ltrim("temperature" + sensorId, 0, fullCount - 1);
    }

    public void fulfill(Piggy piggy) {
        piggy.setCurrTemp(this.getCurrentTemperature());
        piggy.setAbsTemp(this.getAbsDiff());
        piggy.setDodTemp(this.getDodDiff());
        piggy.setPopTemp(this.getPopDiff());
    }

    @Override
    public String toString() {
        return "TemperatureCalModel{" +
                "currentTemperature=" + currentTemperature +
                ", popTemperature=" + popTemperature +
                ", dodTemperature=" + dodTemperature +
                ", groupCurrentTemperature=" + groupCurrentTemperature +
                ", groupPopTemperature=" + groupPopTemperature +
                ", groupDodTemperature=" + groupDodTemperature +
                ", absDiff=" + absDiff +
                ", popDiff=" + popDiff +
                ", dodDiff=" + dodDiff +
                ", hisDataService=" + hisDataService +
                '}';
    }
}
