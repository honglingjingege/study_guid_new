package com.nokia.smartfarm.repository;

import com.nokia.smartfarm.pojo.Dictionary;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:32
 */
public interface DictionaryRepository extends JpaRepository<Dictionary, Integer> {

    List<Dictionary> findByDicCatEquals(int dicCat);

}