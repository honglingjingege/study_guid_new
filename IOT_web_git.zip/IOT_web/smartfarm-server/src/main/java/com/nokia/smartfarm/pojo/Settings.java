package com.nokia.smartfarm.pojo;

import lombok.Data;

import javax.persistence.*;

/**
 * 系统设置
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:24
 */
@Entity
@Data
@Table(name = "settings", schema = "application")
public class Settings {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String settingCode;   //代码
    private String settingValue;   //值
}
