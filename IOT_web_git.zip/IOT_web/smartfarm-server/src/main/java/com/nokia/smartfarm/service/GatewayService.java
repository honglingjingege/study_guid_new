package com.nokia.smartfarm.service;

import com.nokia.smartfarm.pojo.Gateway;
import com.nokia.smartfarm.repository.GatewayRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/28 14:28
 */
@Service
public class GatewayService {

    @Autowired
    private GatewayRepository gatewayRepository;

    /**
     * 获取所有网关数量
     * @author pam
     * @return
     */
    public Long getGatewayCount(){
        return gatewayRepository.count();
    }

    /**
     * 获取错误网关数量
     * @author pam
     * @return
     */
    public int getErrorGatewayCount(){
        return gatewayRepository.countByStatusEquals(0);
    }

    public boolean checkIfGatewayExist(String sn) {
        return gatewayRepository.existsBySnEquals(sn);
    }

    public Gateway save(Gateway gateway) {
        return gatewayRepository.save(gateway);
    }

    public Gateway findGatewayBySn(String sn) {
        List<Gateway> gateways = gatewayRepository.findGatewayBySn(sn);
        if(gateways != null && gateways.size()>0) return gateways.get(0);
        return null;
    }

    /*获取网关列表*/
    public List findGatewayList(){return gatewayRepository.findGatewayList();}
    /*获取绑定的网关列表*/
    public List findBindedGatewayList(){return gatewayRepository.findBindedGatewayList();}
    /*获取绑定的网关列表——某猪舍*/
    public List findBindedGatewayListByPigstyId(Long pigstyId){
        return gatewayRepository.findBindedGatewayListByPigstyId(pigstyId);
    }

}
