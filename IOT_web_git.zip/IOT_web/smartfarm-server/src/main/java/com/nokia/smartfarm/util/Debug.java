package com.nokia.smartfarm.util;

import com.nokia.smartfarm.model.platform.raml.Report;
import com.nokia.smartfarm.model.platform.BaseModel;
import com.nokia.smartfarm.model.platform.NodeModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.stream.Collectors;

public class Debug {
    private static Logger logger = LoggerFactory.getLogger(Debug.class);

    static void debug4SN(List<Report> reports) {
        Set<String> serialNumbers = new HashSet<>();
        reports.forEach(report -> serialNumbers.add(report.getSerialNumber()));
        logger.info("Report contains {} serial numbers -> {}", serialNumbers.size(), serialNumbers.toString());
    }

    static void debug4Summary(List<BaseModel
            > nodeModels) {
        Map<String, List<BaseModel>> group = nodeModels.stream().collect(Collectors.groupingBy(BaseModel::getSerialNumber));
        for(Map.Entry<String, List<BaseModel>> entry: group.entrySet()) {
            String serialNumber = entry.getKey();
            List<BaseModel> groupNodes = entry.getValue();
            logger.info("SerialNumber {} contains {} sensors -> {} ", serialNumber, groupNodes.size(), groupNodes.stream().map(groupNode -> ((NodeModel)groupNode).getSensorId()).collect(Collectors.toList()).toString());
        }
    }
}
