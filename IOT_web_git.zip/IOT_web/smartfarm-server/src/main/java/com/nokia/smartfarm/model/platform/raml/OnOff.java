package com.nokia.smartfarm.model.platform.raml;

import lombok.Data;

@Data
public class OnOff {
    private String deviceName;
}
