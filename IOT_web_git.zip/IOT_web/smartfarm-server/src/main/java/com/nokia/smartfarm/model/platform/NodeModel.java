package com.nokia.smartfarm.model.platform;


import com.nokia.smartfarm.util.StringUtil;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class NodeModel extends BaseModel {
    private double battery;
    private int interval;
    private int rssi;

    private String sensorId;
    private double sensorValue;
    private List<Record> recordList;

    public NodeModel() {}

    public NodeModel(ReportItem reportItem, String resourceValue) {
        if (resourceValue == null) resourceValue = reportItem.getResourceValue().getValue();
        super.setSerialNumber(reportItem.getSerialNumber());
        super.setReportTimestamp(new Date(Long.parseLong(reportItem.getTimeStamp())));
        this.battery = StringUtil.getBattery(resourceValue);
        this.rssi = StringUtil.getRssi(resourceValue);
        this.sensorId = StringUtil.getSensorId(resourceValue);
        this.sensorValue = StringUtil.getSensorValue(resourceValue);

    }

    public double getBattery() {
        return battery;
    }

    public void setBattery(double battery) {
        this.battery = battery;
    }

    public int getInterval() {
        return interval;
    }

    public void setInterval(int interval) {
        this.interval = interval;
    }

    public int getRssi() {
        return rssi;
    }

    public void setRssi(int rssi) {
        this.rssi = rssi;
    }

    public String getSensorId() {
        return sensorId;
    }

    public void setSensorId(String sensorId) {
        this.sensorId = sensorId;
    }

    public double getSensorValue() {
        return sensorValue;
    }

    public void setSensorValue(double sensorValue) {
        this.sensorValue = sensorValue;
    }

    public List<Record> getRecordList() {
        return recordList;
    }

    public void setRecordList(List<Record> recordList) {
        this.recordList = recordList;
    }

    public void addRecord(NodeModel unit) {
        Record record = new Record();
        Connectivity connectivity = new Connectivity();
        connectivity.setRssi(unit.getRssi());
        connectivity.setSerialNumber(unit.getSerialNumber());
        record.setTemperature(unit.getSensorValue());
        record.setConnectivity(connectivity);
        record.setTime(unit.getReportTimestamp());
        record.setSerialNumber(unit.getSerialNumber());
        record.setBattery(unit.getBattery());
        if(this.getRecordList() == null) {
            this.setRecordList(new ArrayList<>());
        }
        this.getRecordList().add(record);
    }

    @Override
    public String toString() {
        return "NodeObject{" +
                "battery=" + battery +
                ", rssi=" + rssi +
                ", serialNumber='" + super.getSerialNumber() + '\'' +
                ", sensorId='" + sensorId + '\'' +
                ", sensorValue=" + sensorValue +
                ", reportTimestamp=" + super.getReportTimestamp() +
                '}';
    }
}
