package com.nokia.smartfarm.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.nokia.smartfarm.service.PigstyMapService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/pigstyMap")
@Slf4j
public class PigsyMapController {
    @Autowired
    private PigstyMapService pigstyMapService;

    /*获取猪舍网关地图数据*/
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getPigstyMap")
    public Map<String, Object> getPigstyMap (){
        List<Map<String, Object>>  pigstyGatewayList =  pigstyMapService.getPigstyGatewayMapList();
        List<Map<String, Object>>  pigstyList =  pigstyMapService.getPigstyList();
        List<Map<String, Object>>  gatewayList =  pigstyMapService.getGatewayList();
        Map pigstyMap = new HashMap();
        pigstyMap.put("pigstyGatewayList", pigstyGatewayList);
        pigstyMap.put("pigstyList", pigstyList);
        pigstyMap.put("gatewayList", gatewayList);
        return pigstyMap;
    }

    /*获取猪舍网关列表*/
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getPigstyMapList")
    public List<Map<String, Object>> pigstyGatewayList (){ return pigstyMapService.getPigstyGatewayMapList();}

    /*获取猪舍列表*/
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getPigstyList")
    public List<Map<String, Object>> getPigstyList (){ return pigstyMapService.getPigstyList();}

    /*获取网关列表*/
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getGatewayList")
    public List<Map<String, Object>> getGatewayList (){ return pigstyMapService.getGatewayList();}




    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/insertPigstyMap", method = RequestMethod.POST)
    public Map<String, Object>insertPigstyMap(Long pigstyId, String pigstyScale, String gateWayList){
        Map pigstyScaleMap = JSON.parseObject(pigstyScale);
        List gateWayListMap = JSON.parseArray(gateWayList);

        Boolean success = pigstyMapService.insertPigstyMap(pigstyId, pigstyScaleMap, gateWayListMap);
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("success", success);
        return result;
    }
}
