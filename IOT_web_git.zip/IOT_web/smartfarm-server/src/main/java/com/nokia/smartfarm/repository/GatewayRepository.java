package com.nokia.smartfarm.repository;

import com.nokia.smartfarm.pojo.Gateway;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Map;

/**
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:32
 */
public interface GatewayRepository extends JpaRepository<Gateway, Integer> {

    //统计某种状态的网关数量
    int countByStatusEquals(Integer status);
    boolean existsBySnEquals(String sn);
    List<Gateway> findGatewayBySn(String sn);
    //获取gateway详细信息
    Gateway findFirstByIdEquals(Integer id);

    /*获取网关列表*/
    @Query(value = "select * from application.gateway order by id",nativeQuery = true)
    List<Map<String, Object>> findGatewayList();

    /*获取与猪舍绑定的网关列表*/
    @Query(value = "select e.*,f.name manager_name\t\n" +
            "from(select c.*,d.name pigsty_name,d.width,d.high,d.header_id\n" +
            "\tfrom(select a.* ,b.pigsty_id,b.point_x,b.point_y\n" +
            "\t\tfrom (select id gateway_id, name gateway_name ,updated_at from application.gateway where status = 0)a\n" +
            "\t\tleft join application.pigstymap b on a.gateway_id = b.gateway_id)c\n" +
            "\tleft join application.pigsty d on c.pigsty_id = d.id) e\t\n" +
            "left join application.manager f on e.header_id = f.id ",nativeQuery = true)
    List<Map<String, Object>> findBindedGatewayList();
    /*获取与猪舍绑定的网关列表——某猪舍*/
    @Query(value = "select c.*, d.name manager_name,e.name gateway_name,e.updated_at\n" +
            "from (select a.* ,b.header_id,b.name pigstyname,b.width,b.high\n" +
            "\t  from application.pigstymap a \n" +
            "\t  left join application.pigsty b on a.pigsty_id = b.id) c\n" +
            "left join application.manager d on c.header_id = d.id \n" +
            "left join application.gateway e on c.gateway_id = e.id\n" +
            "where e.status = 0 and c.pigsty_id=?1",nativeQuery = true)
    List<Map<String, Object>> findBindedGatewayListByPigstyId(Long pigstyId);
}