package com.nokia.smartfarm.service;

import com.nokia.smartfarm.model.influx.GatewayCalModel;
import com.nokia.smartfarm.pojo.influx.Gateway;
import com.nokia.smartfarm.pojo.influx.Sensor;
import lombok.extern.slf4j.Slf4j;
import org.influxdb.InfluxDB;
import org.influxdb.dto.Query;
import org.influxdb.dto.QueryResult;
import org.influxdb.impl.InfluxDBResultMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
@Slf4j
public class InfluxHisDataService implements HisDataService{
    @Autowired
    private InfluxDB influxDB;

    private static final String CAL_TIME_SQL = " time > now() - 1d and time < now() ";
    private static final String ORDERBY_SQL = " order by time desc ";
    private static final String LIMIT_SQL = " limit 2 ";

    public Sensor findNodeDoD(String gatewaySn, String nodeSn) {
        String sql = new StringBuilder("select first(mmc_temp) as mmc_temp from sensor where MMC_MAC='")
                .append(nodeSn).append("' and IMEI='").append(gatewaySn).append("' and ").append(CAL_TIME_SQL).toString();
        QueryResult qr = influxDB.query(new Query(sql));

        InfluxDBResultMapper mapper = new InfluxDBResultMapper();
        List<Sensor> sensors = mapper.toPOJO(qr, Sensor.class);
        if(sensors != null && sensors.size()>0) {
            for(Sensor s: sensors) {
                log.info("findNodeDoD ->{}, {}, {}, {}", gatewaySn, nodeSn, s.getT(),s.getMmcTemp());
            }
            return sensors.get(0);
        }
        return null;
    }

    public Sensor findNodePoP(String gatewaySn, String nodeSn) {
        String sql = new StringBuilder("select last(mmc_temp) as mmc_temp from sensor where MMC_MAC='")
                .append(nodeSn).append("' and IMEI='").append(gatewaySn).append("' and ").append(CAL_TIME_SQL).toString();
        QueryResult qr = influxDB.query(new Query(sql));

        InfluxDBResultMapper mapper = new InfluxDBResultMapper();
        List<Sensor> sensors = mapper.toPOJO(qr, Sensor.class);
        if(sensors != null && sensors.size()>0) {
            for(Sensor s: sensors) {
                log.info("findNodePoP ->{}, {}, {}, {}", gatewaySn, nodeSn, s.getT(),s.getMmcTemp());
            }
            return sensors.get(0);
        }
        return null;
    }

    public GatewayCalModel findGatewayCalModel(String gatewaySn) {

        String sql = new StringBuilder("select avg_temperature as avg_temperature from gateway where sn='")
               .append(gatewaySn).append("' and ").append(CAL_TIME_SQL).append(ORDERBY_SQL).append(LIMIT_SQL).toString();
        QueryResult qr = influxDB.query(new Query(sql));

        InfluxDBResultMapper mapper = new InfluxDBResultMapper();
        List<Gateway> gateways = mapper.toPOJO(qr, Gateway.class);
        GatewayCalModel gatewayCalModel = null;
        if(gateways !=null && gateways.size() ==2) {
            gatewayCalModel = new GatewayCalModel(gateways.get(0).getAvgTemperature(), gateways.get(1).getAvgTemperature());
            return gatewayCalModel;
        }
        return gatewayCalModel;
    }

    public Gateway findGatewayDoD(String gatewaySn) {
        String sql = new StringBuilder("select first(avg_temperature) as avg_temperature from gateway where sn='")
                .append(gatewaySn).append("' and ").append(CAL_TIME_SQL).toString();
        QueryResult qr = influxDB.query(new Query(sql));

        InfluxDBResultMapper mapper = new InfluxDBResultMapper();
        List<Gateway> gateways = mapper.toPOJO(qr, Gateway.class);
        if(gateways != null && gateways.size()>0) {
            for(Gateway gw: gateways) {
                log.info("findGatewayDoD {}, {}, {}", gatewaySn, gw.getT(),gw.getAvgTemperature());
            }
            return gateways.get(0);
        }
        return null;
    }

}
