package com.nokia.smartfarm.schedule;

import com.nokia.smartfarm.config.SystemConfig;
import com.nokia.smartfarm.pojo.Gateway;
import com.nokia.smartfarm.pojo.Node;
import com.nokia.smartfarm.service.GatewayService;
import com.nokia.smartfarm.service.NodeService;
import com.nokia.smartfarm.service.PiggyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class AutoBindingTask {

    @Autowired
    PiggyService piggyService;

    @Autowired
    NodeService nodeService;

    @Autowired
    GatewayService gatewayService;

    @Autowired
    private JedisPool jedisPool;

    @Scheduled(cron = "0 0 1 * * ?")
    private void binding() {
        log.info("start binding ...");
        Jedis jedis = jedisPool.getResource();
        List<Node> nodes = nodeService.getAllNodes();
        try {
            for(Node node : nodes) {
                String sn = node.getSn();
                String gatewaySn = node.getGatewayName();
                String bindingKey = "binding" + sn;
                Map map = jedis.hgetAll(bindingKey);
                List<Map.Entry<String,String>> list = new ArrayList(map.entrySet());
                Collections.sort(list, (o1, o2) -> (Integer.parseInt(o1.getValue()) - Integer.parseInt(o2.getValue())));
                if(list !=null && list.size() >0) {
                    String toGwSn = list.get(list.size() - 1).getKey();
                    if(!gatewaySn.equals(toGwSn)) {
                        log.info("Chang binding... {} from -> {}, to -> {}", sn, gatewaySn, toGwSn);
                        Gateway gateway = gatewayService.findGatewayBySn(toGwSn);
                        node.setGatewayName(gateway.getName());
                        node.setGatewayId(gateway.getId());
                        nodeService.save(node);
                    }
                }
            }
        }catch (Exception e) {
            e.printStackTrace();
        }finally {
            try {
                jedis.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

    }
}
