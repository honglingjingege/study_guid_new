package com.nokia.smartfarm.service;

import com.nokia.smartfarm.model.influx.GatewayCalModel;
import com.nokia.smartfarm.pojo.influx.Gateway;
import com.nokia.smartfarm.pojo.influx.Sensor;
import org.springframework.stereotype.Service;

public interface HisDataService {
    public Sensor findNodeDoD(String gatewaySn, String nodeSn);
    public Sensor findNodePoP(String gatewaySn, String nodeSn);
    public GatewayCalModel findGatewayCalModel(String gatewaySn);
    public Gateway findGatewayDoD(String gatewaySn);

}
