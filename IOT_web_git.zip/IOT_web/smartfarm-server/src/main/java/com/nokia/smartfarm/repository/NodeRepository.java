package com.nokia.smartfarm.repository;

import com.nokia.smartfarm.pojo.Node;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

/**
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:32
 */
public interface NodeRepository extends JpaRepository<Node, Integer> {

    //统计某种状态的耳标数量
    int countByStatusEquals(Integer status);

    boolean existsBySnEquals(String sn);

    List<Node> findNodeBySn(String sn);

    //获取node详细信息
    Node findFirstByIdEquals(Integer id);
}