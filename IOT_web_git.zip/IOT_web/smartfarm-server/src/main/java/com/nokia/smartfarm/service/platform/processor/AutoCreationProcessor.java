package com.nokia.smartfarm.service.platform.processor;

import com.nokia.smartfarm.enums.OnOffStatus;
import com.nokia.smartfarm.model.DefaultModelBuilder;
import com.nokia.smartfarm.model.platform.BaseModel;
import com.nokia.smartfarm.model.platform.NodeModel;
import com.nokia.smartfarm.pojo.*;
import com.nokia.smartfarm.service.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@Slf4j
public class AutoCreationProcessor implements Processor{
    @Autowired
    GatewayService gatewayService;

    @Autowired
    NodeService nodeService;

    @Autowired
    NpMapService npMapService;

    @Autowired
    PigstyService pigstyService;

    @Autowired
    PiggyService piggyService;

    @Autowired
    BasePiggyInfoService basePiggyInfoService;

    @Autowired
    DefaultModelBuilder defaultModelBuilder;

    @Override
    public void process(List<BaseModel> baseModels) {
        for (BaseModel model : baseModels) {
            NodeModel nodeModel = (NodeModel) model;
            String serialNumber = nodeModel.getSerialNumber();
            String sensorId = nodeModel.getSensorId();
            Gateway gateway = gatewayService.findGatewayBySn(serialNumber);
            if (gateway == null) {
                log.info("gateway is null,  sn is -> {}",  serialNumber);
                gateway = autoCreateGateway(serialNumber);
            }
            Node node = nodeService.findNodeBySn(sensorId);
            if (node == null) {
                log.info("node is null, sn is -> {}", sensorId);
                node = autoCreateNode(gateway, sensorId);
            } else {
                node.setStatus(OnOffStatus.ONLINE.getCode());
                nodeService.save(node);
            }
            NpMap npMap = npMapService.findNpMapByNodeSn(sensorId);
            if(npMap != null) {
                BasePiggyInfo basePiggyInfo = basePiggyInfoService.findPiggyInfoByEarcard(npMap.getEarcard());
                if(basePiggyInfo != null) {
                    Pigsty pigsty = pigstyService.findPigstyBySn(basePiggyInfo.getPiggery());
                    if (pigsty == null) {
                        log.info("pigsty is null for pigstySn -> {}", basePiggyInfo.toString());
                        pigsty = autoCreatePigsty(basePiggyInfo);
                    }
                    Piggy piggy = piggyService.findPiggyByNode(node.getId());
                    if(piggy == null) {
                        piggy = autoCreatePiggy(node, pigsty, basePiggyInfo);
                        piggyService.save(piggy);
                    }
                }else {
                    log.warn("basePiggyInfo is null, can't find base information for -> {}, {}", npMap.toString());
                }
            } else {
                log.warn("npMap is null for sensorId -> {}", sensorId);
            }
        }
    }

    private Gateway autoCreateGateway(String gatewaySn) {
        Gateway gateway = defaultModelBuilder.buildGateway(gatewaySn);
        gateway = gatewayService.save(gateway);
        return gateway;
    }

    private Node autoCreateNode(Gateway gateway, String nodeSn) {
        Node node = defaultModelBuilder.buildNode(nodeSn, gateway);
        node = nodeService.save(node);
        return node;
    }

    private Piggy autoCreatePiggy(Node node, Pigsty pigsty, BasePiggyInfo basePiggyInfo) {
        Piggy piggy = defaultModelBuilder.buildPiggy(node);
        piggy = defaultModelBuilder.buildWithBaseInfo(piggy, pigsty, basePiggyInfo);
        return piggy;
    }

    private Pigsty autoCreatePigsty(BasePiggyInfo basePiggyInfo) {
        Pigsty pigsty = defaultModelBuilder.buildPigsty(basePiggyInfo.getPiggeryname(), basePiggyInfo.getPiggery());
        pigsty = pigstyService.save(pigsty);
        return pigsty;
    }

}
