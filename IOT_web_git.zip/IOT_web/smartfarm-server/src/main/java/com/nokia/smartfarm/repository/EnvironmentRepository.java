package com.nokia.smartfarm.repository;

import com.nokia.smartfarm.pojo.Environment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Map;

/**
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:32
 */
public interface EnvironmentRepository extends JpaRepository<Environment, Integer> {

    //查找最近环境状态值
    Environment findTop1ByOrderByRecordTimeDesc();

    @Query(value = "select max(env_temp),min(env_temp),substr(cast(record_time as text),1,10) tp from application.environment" +
            " where record_time>=cast(?1 as timestamp without time zone) group by tp order by tp", nativeQuery = true)
    List<Map<String, Object>> findNewestNDaysTemp(String startTime);

    @Query(value = "select round(sum(env_temp)/count(1),2) avetemp,round(sum(env_humidity)/count(1),2) avehumidity" +
            ",substr(cast(record_time as text),12,2) hours,substr(cast(record_time as text),1,13) tp from application.environment " +
            " where record_time>=cast(?1 as timestamp without time zone) group by tp,hours order by tp", nativeQuery = true)
    List<Map<String, Object>> findLatestNHourAveTempAndTime(String startTime);
}