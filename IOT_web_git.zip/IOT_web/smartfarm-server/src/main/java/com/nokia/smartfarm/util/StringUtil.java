package com.nokia.smartfarm.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class StringUtil {
    private static Logger logger = LoggerFactory.getLogger(StringUtil.class);
    public static String toLowerCaseFirstOne(String s){
        if(Character.isLowerCase(s.charAt(0)))
            return s;
        else
            return (new StringBuilder()).append(Character.toLowerCase(s.charAt(0))).append(s.substring(1)).toString();
    }
    public static String toUpperCaseFirstOne(String s){
        if(Character.isUpperCase(s.charAt(0)))
            return s;
        else
            return (new StringBuilder()).append(Character.toUpperCase(s.charAt(0))).append(s.substring(1)).toString();
    }

    public static String getSensorId(String s) {
        return s.substring(0, 12);
    }

    public static int getBattery(String s) {
        return Integer.parseInt(s.substring(12, 14),16);
    }

    public static double getSensorValue(String s) {
        int i = Integer.parseInt(s.substring(14, 18),16);
        Double d = new Double(i)/100;
        return d;
    }
    public static int getRssi(String s) {
        String binaryString = Integer.toBinaryString(Integer.parseInt(s.substring(18, 20), 16));
        String result = BinaryUtil.getNativeNumber(binaryString);
        return Integer.parseInt(result);
    }
}
