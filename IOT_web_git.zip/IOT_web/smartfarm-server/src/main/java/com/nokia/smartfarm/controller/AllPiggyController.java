package com.nokia.smartfarm.controller;

import com.nokia.smartfarm.pojo.Dictionary;
import com.nokia.smartfarm.pojo.influx.Sensor;
import com.nokia.smartfarm.service.DictionaryService;
import com.nokia.smartfarm.service.PiggyService;
import com.nokia.smartfarm.service.PigstyMapService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/allPiggy")
public class AllPiggyController {
    @Autowired
    private PiggyService piggyService;
	
    @Autowired
    private DictionaryService dictionaryService;

    @Autowired
    private PigstyMapService pigstyMapService;

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getQueryCondition")
    public Map<String, Object> getCardsContent(){
        Map<String, Object> result = new HashMap<String, Object>();
        // 获取常量-生产周期常量
        List<Dictionary> periodStatusList = dictionaryService.getConstantByDicCat(101);
        result.put("periodStatusList", periodStatusList);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getTableData")
    public Map<String, Object> getTableData(String earcard, String periodStatus, String alarmStart
            , String alarmEnd, Long pageNum, Long pageSize, String orderby, String sortDirection){
        Map<String, Object> result = new HashMap<String, Object>();
        //所有猪只列表
        List sickPiggyPage = piggyService.filterAllPiggy(earcard, periodStatus, alarmStart, alarmEnd, pageNum, pageSize, orderby, sortDirection);
        Number filterCount = piggyService.filterAllPiggyCount(earcard, periodStatus, alarmStart, alarmEnd);

        result.put("sickPiggyPage", sickPiggyPage);
        result.put("filterCount", filterCount);
        result.put("pageSize", pageSize);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/fetchTempData")
    public Map<String, Object> fetchTempData(Long timeId, Long piggyId) throws ParseException {
        Map<String, Object> result = new HashMap<String, Object>();
        List<Sensor> lists = piggyService.getPiggyTempData(timeId, piggyId);
        result.put("tempData", lists);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getPiggyBindGetway")
    public List<Map<String, Object>> findAllEarBindGateway(){
        List<Map<String, Object>> lists = piggyService.findAllEarBindGateway();
        return lists;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping(value = "/getPiggyBindGetwayByEarIdOrPeriod", method = RequestMethod.POST)
    public List<Map<String, Object>> findAllEarBindGatewayByEarIdOrPeriod(Long id, Long period){
        List<Map<String, Object>> lists = piggyService.findAllEarBindGatewayByEarIdOrPeriod(id, period);
        return lists;
    }

    //根据猪舍id获取网关地图数据
    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getGatewayMapData")
    public List<Map<String, Object>> getGatewayMapData(Long pigstyId){
        return pigstyMapService.getGatewayMapDataByPigstyId(pigstyId);
    }
}
