package com.nokia.smartfarm.model.platform.raml;

import lombok.Data;

@Data
public class Deregistration extends OnOff{
}
