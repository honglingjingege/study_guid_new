package com.nokia.smartfarm.controller;

import com.nokia.smartfarm.listener.ApplicationStartedEventListener;
import com.nokia.smartfarm.service.GatewayService;
import com.nokia.smartfarm.service.PigstyService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/allPigsty")
public class AllPigstyController {

}
