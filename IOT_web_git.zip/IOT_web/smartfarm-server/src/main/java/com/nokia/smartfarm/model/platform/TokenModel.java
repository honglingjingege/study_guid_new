package com.nokia.smartfarm.model.platform;

import lombok.Data;

@Data
public class TokenModel {

    private String token;
    private String refreshToken;

}
