package com.nokia.smartfarm.repository;

import com.nokia.smartfarm.pojo.AuditLog;
import com.nokia.smartfarm.pojo.Environment;
import org.springframework.data.jpa.repository.JpaRepository;

/**
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:32
 */
public interface AuditLogRepository extends JpaRepository<AuditLog, Integer> {

}