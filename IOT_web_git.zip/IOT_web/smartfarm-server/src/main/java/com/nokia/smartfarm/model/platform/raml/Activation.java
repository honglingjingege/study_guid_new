package com.nokia.smartfarm.model.platform.raml;

public class Activation extends OnOff{
}
