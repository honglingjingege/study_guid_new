package com.nokia.smartfarm.util;

import com.nokia.smartfarm.enums.DiseaseStatus;
import org.apache.commons.lang.StringUtils;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 枚举工具类
 */
public class AppEnumUtil {

	/**
	 * 翻译疾病类型字段
	 * @param list 待翻译的集合
	 * @param columnName 集合中疾病类型字段名
	 * @return
	 */
	public static List<Map<String, Object>> transDiseaseType(List<Map<String, Object>> list, String columnName) {
		List<Map<String, Object>> newList = new ArrayList<Map<String, Object>>();
		HashMap<String, Object> newOne = null;
		StringBuilder transStr = null;
		for(Map<String, Object> t : list){
			Object diseaseType = t.get(columnName);//疾病类型
			String value = null;
			if(null != diseaseType) {
				String[] dts = String.valueOf(diseaseType).split(",");
				transStr = new StringBuilder();
				for(String dt : dts){
					transStr.append(DiseaseStatus.translate(Integer.parseInt(dt))).append("，");
				}
				value = transStr.toString();
				if(StringUtils.isNotBlank(value)){
					value = value.substring(0, value.length() - 1);
				}
			}
			newOne = new HashMap<>();//防止list无法更新内含的map
			newOne.putAll(t);
			newOne.put(columnName, value);
			newList.add(newOne);
		}
		return newList;
	}

}