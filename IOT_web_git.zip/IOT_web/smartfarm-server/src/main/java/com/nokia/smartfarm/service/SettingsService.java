package com.nokia.smartfarm.service;

import com.nokia.smartfarm.repository.SettingsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

/**
 * @author cyf
 * @version 1.0
 * @description
 * @date 2019/8/28 14:28
 */
@Service
public class SettingsService {
    @Autowired
    private SettingsRepository settingsRepository;
    public List<Map<String, Object>> getAllSettingsParams(){
        return settingsRepository.findAllSettingParam();
    }
    @Transactional
    public boolean updateSettingParams(Map<String, Object> settingParams){
        boolean updateResult = true;
        for (Map.Entry<String, Object> entry : settingParams.entrySet()) {
            int result = settingsRepository.updateSettingParams(entry.getKey(), entry.getValue());
            if (result != 1){
                updateResult = false;
                break;
            }
        }
        return updateResult;
    }
}
