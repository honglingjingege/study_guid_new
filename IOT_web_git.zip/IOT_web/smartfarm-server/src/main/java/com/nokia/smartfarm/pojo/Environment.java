package com.nokia.smartfarm.pojo;

import lombok.Data;

import javax.persistence.*;
import java.sql.Timestamp;

/**
 * 环境信息
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:24
 */
@Entity
@Data
@Table(name = "environment", schema = "application")
public class Environment {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private Integer envTemp;   //环境温度
    private Integer envHumidity;   //环境湿度
    @Column(insertable = false)
    private Timestamp recordTime;   //记录时间
}
