package com.nokia.smartfarm.enums;

public enum AlarmStatus {
    NORMAL(0), ABNORMAL(1), ALARM(2), DISEASE(3);

    private int code;

    AlarmStatus(int code) {

        this.code = code;

    }

    public int getCode() {
        return code;
    }
}
