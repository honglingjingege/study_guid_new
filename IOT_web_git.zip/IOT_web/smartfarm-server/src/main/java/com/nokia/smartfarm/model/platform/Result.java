package com.nokia.smartfarm.model.platform;

public class Result {
    private String code;
    private String subCode;
    private String reason;

    public Result(){}

    public Result(String code, String subCode, String reason) {
        this.code = code;
        this.subCode = subCode;
        this.reason = reason;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getSubCode() {
        return subCode;
    }

    public void setSubCode(String subCode) {
        this.subCode = subCode;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    @Override
    public String toString() {
        return "Result{" +
                "code='" + code + '\'' +
                ", subCode='" + subCode + '\'' +
                ", reason='" + reason + '\'' +
                '}';
    }
}
