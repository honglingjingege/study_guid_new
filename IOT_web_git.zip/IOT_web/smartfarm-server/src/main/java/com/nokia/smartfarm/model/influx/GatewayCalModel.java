package com.nokia.smartfarm.model.influx;

import lombok.Data;

@Data
public class GatewayCalModel {
    private double current;
    private double pop;

    public GatewayCalModel(double current, double pop) {
        this.current = current;
        this.pop = pop;
    }
}
