package com.nokia.smartfarm.service.platform.processor;

import com.nokia.smartfarm.model.platform.BaseModel;

import java.util.List;

public interface Processor {

    public void process(List<BaseModel> baseModels);
}
