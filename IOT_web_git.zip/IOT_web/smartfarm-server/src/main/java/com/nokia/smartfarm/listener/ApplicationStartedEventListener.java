package com.nokia.smartfarm.listener;

import com.google.gson.Gson;
import com.nokia.smartfarm.config.SystemConfig;
import com.nokia.smartfarm.model.platform.DevicesModel;
import com.nokia.smartfarm.model.platform.TokenModel;
import com.nokia.smartfarm.service.SettingsService;
import com.nokia.smartfarm.service.platform.PlatformIntService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Map;

@Slf4j
@Component
public class ApplicationStartedEventListener implements ApplicationListener<ApplicationReadyEvent> {

    @Autowired
    private SettingsService settingsService;

    @Autowired
    private PlatformIntService platformIntService;

    Gson gson = new Gson();

    @Override
    public void onApplicationEvent(ApplicationReadyEvent applicationReadyEvent) {
        log.info("############################## Start Init System config settings ##############");
        List<Map<String, Object>> list = settingsService.getAllSettingsParams();
        SystemConfig config = SystemConfig.getInstance();
        config.load(list);

        log.info("############################## Start Init Edge+board token ##############");
        String tokenResponse = platformIntService.getToken();
        log.info("token is -> {}", tokenResponse);
        TokenModel tokenModel = gson.fromJson(tokenResponse, TokenModel.class);
        config.setTokenModel(tokenModel);
    }
}
