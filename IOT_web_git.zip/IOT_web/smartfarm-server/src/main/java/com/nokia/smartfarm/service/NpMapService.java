package com.nokia.smartfarm.service;

import com.nokia.smartfarm.pojo.NpMap;
import com.nokia.smartfarm.repository.NpMapRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class NpMapService {

    @Autowired
    private NpMapRepository npMapRepository;

    public NpMap findNpMapByNodeSn(String sn) {
        List<NpMap> maps = npMapRepository.findNpMapBySnEquals(sn);
        if(maps != null && maps.size()>0) return maps.get(0);
        return null;
    }

    /**
     * 绑定耳标和序列号
     * @param earcard
     * @param sn
     * @return
     */
    public boolean bindingEarcardAndSn(String earcard, String sn){
        NpMap npMap = new NpMap();
        npMap.setEarcard(earcard);
        npMap.setSn(sn);
        NpMap r = npMapRepository.save(npMap);
        if(null == r || r.getId() == null) return false;
        return true;
    }


}
