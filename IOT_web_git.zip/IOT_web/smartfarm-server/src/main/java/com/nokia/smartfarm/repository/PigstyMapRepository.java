package com.nokia.smartfarm.repository;

import com.nokia.smartfarm.pojo.Pigsty;
import com.nokia.smartfarm.pojo.PigstyMap;
import com.nokia.smartfarm.pojo.Settings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Map;

public interface PigstyMapRepository extends JpaRepository<PigstyMap, Integer> {
    @Query(value = "select g.pigsty_id,g.width,g.high,g.gateway_id,g.longitude,g.latitude from(select d.*,e.name resperson,f.name gatewayName,f.sn,f.longitude,f.latitude\n" +
            "                        from (select a.id,a.earcard,a.node_id,a.pigsty_id,a.updated_at,b.header_id,b.width,b.high,c.gateway_id\n" +
            "                        from application.piggy a left join application.pigsty b on a.pigsty_id = b.id left join application.node c on a.node_id = c.id where a.pigsty_id is not null) d\n" +
            "                left join application.manager e on d.header_id = e.id\n" +
            "                left join application.gateway f on cast(d.gateway_id as integer) = f.id) g",nativeQuery = true)
    List<Map<String, Object>> findAllPigyMapParams();


    @Modifying
    @Query(value = "update application.pigsty set width = ?2 ,high = ?3 where id =?1" ,nativeQuery = true)
    int updatePigstySize(Long pigstyId, Integer width, Integer high);

    @Modifying
    @Query(value = "update application.pigstyMap set point_x = ?2 ,point_y = ?3 where gateway_id=?1" ,nativeQuery = true)
    int updateGatewayLocation(Long gatewayId, Integer longitude, Integer latitude);

    @Modifying
    @Query(value = "delete from application.pigstyMap where gateway_id = ?1",nativeQuery = true)
    int ubindGatewayAndPigsty(Long gatewayId);
    /*
    * 获取猪舍网关地图列表*/
    @Query(value = "select a.*, b.width, b.high,b.name pigstyname, c.name gateway_name " +
            "           from application.pigstymap a " +
            "           left join application.pigsty b on a.pigsty_id = b.id" +
            "           left join application.gateway c on a.gateway_id = c.id",nativeQuery = true)
    List<Map<String, Object>> findPigstyGatewayMapList();
    /*根据gatewayId查找判断存不存在记录*/
    @Query(value = "select * from application.pigstymap where gateway_id = ?1",nativeQuery = true)
    List<Map<String, Object>> findRowByGatewayId(Long gatewayId);

    /*向猪舍网关地图表插入数据*/
    @Modifying
    @Query(value ="INSERT INTO application.pigstymap (gateway_id, point_x, point_y, pigsty_id) VALUES (?2, ?3, ?4, ?1)", nativeQuery = true)
    int insertGatewayAndPigsty(Long pigstyId, Long gatewayId, Integer point_x, Integer point_y);


    /*根据猪舍Id获取猪舍网关地图数据*/
    @Modifying
    @Query(value ="select c.*, d.name pigsty_name \n" +
            "from(select a.*,b.name gatewayname\n" +
            "\tfrom application.pigstyMap a \n" +
            "\tleft join application.gateway b on a.gateway_id = b.id\n" +
            "\twhere a.pigsty_id =?1) c\n" +
            "left join application.pigsty d on c.pigsty_id = d.id", nativeQuery = true)
    List<Map<String, Object>> getGatewayMapDataByPigstyId(Long pigstyId);

    List<PigstyMap> findByPigstyIdEquals(Integer pigstyId);

}