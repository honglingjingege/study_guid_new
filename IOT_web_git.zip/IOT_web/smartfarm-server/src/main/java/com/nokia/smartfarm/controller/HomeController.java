package com.nokia.smartfarm.controller;

import com.nokia.smartfarm.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/home")
public class HomeController {
    @Autowired
    private GatewayService gatewayService;
    @Autowired
    private NodeService nodeService;
    @Autowired
    private PiggyService piggyService;
    @Autowired
    private PigstyService pigstyService;
    @Autowired
    private EnvironmentService environmentService;

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getCardsContent")
    public Map<String, Object> getCardsContent(String orderBy){
        Map<String, Object> result = new HashMap<String, Object>();
        //网关
        Long gatewayCount = gatewayService.getGatewayCount();
        int errorGatewayCount = gatewayService.getErrorGatewayCount();
        //耳标
        Long nodeCount = nodeService.getNodeCount();
        int errorNodeCount = nodeService.getErrorNodeCount();
        //猪只
        Long piggyCount = piggyService.getPiggyCount();
        int alarmPiggyCount = piggyService.getAlarmPiggyCount();
        //温湿度
        Map<String, Object> latestTempAndHumidity = environmentService.getLatestTempAndHumidity();
        //猪舍报警猪只汇总排行
        List<Map<String, Object>> pigstyWithAlarmPiggy = pigstyService.findPigstyWithAlarmPiggy(orderBy);
        //疾病猪只管理
//        Page<Piggy> sickPiggyPage = piggyService.findSickPiggyPage(1, null);
        List<Map<String, Object>> sickPiggyPage = piggyService.findAllSickPiggy();
        //疾病猪只管理-全部疾病猪只数量
        int sickPiggyCount = piggyService.getSickPiggyCount();

        result.putAll(latestTempAndHumidity);
        result.put("nodeCount", nodeCount);
        result.put("errorNodeCount", errorNodeCount);
        result.put("gatewayCount", gatewayCount);
        result.put("errorGatewayCount", errorGatewayCount);
        result.put("piggyCount", piggyCount);
        result.put("alarmPiggyCount", alarmPiggyCount);
        result.put("pigstyWithAlarmPiggy", pigstyWithAlarmPiggy);
        result.put("sickPiggyPage", sickPiggyPage);
        result.put("sickPiggyCount", sickPiggyCount);
        return result;
    }

    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
    @RequestMapping("/getHomeChart")
    public Map<String, Object> getHomeChart(String orderBy){
        Map<String, Object> result = new HashMap<String, Object>();
        //猪舍报警猪只汇总排行
        List<Map<String, Object>> pigstyWithAlarmPiggy = pigstyService.findPigstyWithAlarmPiggy(orderBy);
        result.put("pigstyWithAlarmPiggy", pigstyWithAlarmPiggy);
        return result;
    }

//    @PreAuthorize("hasAnyAuthority('ADMIN','USER')")
//    @RequestMapping("/getSickPiggyPage")
//    public Page<Piggy> getSickPiggyPage(int nextPageNum){
//        Page<Piggy> sickPiggyPage = piggyService.findSickPiggyPage(nextPageNum, 10);
//        return sickPiggyPage;
//    }

}
