package com.nokia.smartfarm.repository;

import com.nokia.smartfarm.pojo.Piggy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;

import java.util.List;
import java.util.Map;

/**
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/27 11:32
 */
public interface PiggyRepository extends JpaRepository<Piggy, Integer> {

    //统计某种报警状态的猪只数量
    int countByAlarmStatusEquals(Integer alarmStatus);

    //查询某种报警状态的所有猪只-分页
    Page<Piggy> findByAlarmStatusEquals(Integer alarmStatus, Pageable pageable);

    //查询某种报警状态的所有猪只-不分页
    @Query(value = "select p.*,disease_type as dic_value from application.piggy p where p.alarm_status=?1", nativeQuery = true)
    List<Map<String, Object>> findAllByAlarmStatusEquals(Integer alarmStatus);

    //更新猪只报警状态
    @Modifying //通知Spring Data 这是一个DELETE或UPDATE操作
    @Query(value = "update application.piggy set alarm_status = ?2 where id = ?1", nativeQuery = true)
    int updateAlarmStatusById(Long id, Long alarmStatus);

    List<Piggy> findPiggyByNodeId(int nodeId);

    //获取猪只信息
    Piggy findFirstByIdEquals(Integer id);


    //耳标与网关绑定管理
    @Query(value = "select b.*, m.name from (select earcard,pigsty_id,p.header_id, node_id  from application.piggy a left join application.pigsty p on a.pigsty_id = p.id) b left join application.manager m on b.header_id = m.id", nativeQuery = true)
    List<Map<String, Object>> findAllEarBindGateway();

    //根据条件查询耳标与网关绑定
    @Query(value = "select b.*, m.name from (select earcard,pigsty_id,p.header_id, node_id  from application.piggy a left join application.pigsty p on a.pigsty_id = p.id where (a.id=?1 or ?1=-1) and (a.period_status=?2 or ?2=-1)) b left join application.manager m on b.header_id = m.id", nativeQuery = true)
    List<Map<String, Object>> findAllEarBindGatewayByEarIdOrPeriod(Long id, Long period);

    /**
     * 各周期报警猪只汇总排行-按数量降序
     * @return
     */
    @Query(value = "select a.peid,a.pename,a.num,b.sum,round(cast(a.num as numeric)/cast(b.sum as numeric),4) rate from" +
            "(select pg.period_status as peid, (select dic_value from application.dictionary where dic_cat='101' and dic_code=pg.period_status) as pename, count(pg.id) as num from application.piggy pg where pg.alarm_status = '2' group by peid) a" +
            " inner join " +
            "(select pg.period_status as peid, count(pg.id) as sum from application.piggy pg group by peid) b" +
            " on a.peid = b.peid order by num desc", nativeQuery = true)
    List<Map<String, Object>> findPeriodAlarmPiggyOrderbyNum();

    /**
     * 获取猪只部分信息
     * @return
     */
    @Query(value = "select earcard,(select ps.sn from application.pigsty ps where ps.id=pg.pigsty_id)," +
            "point_x,point_y,curr_temp,abs_temp,dod_temp,pop_temp,investigate,measures,disease_type,com_invest,com_meas,com_disease " +
            "from application.node_piggy_view pg left join application.pigstymap pm on pm.gateway_id=pg.gateway_id where pg.piggy_id=?1", nativeQuery = true)
    Map<String, Object> getPiggySomeInfo(int piggyId);

    /**
     * 批量同步更新piggy表信息
     */
    @Modifying
    @Query(value = "update application.piggy p set imported_period_status=b.status,period_status_date=b.statusdate,individual=b.individual," +
            "period_status=(case when(b.status in('后备')) then 0 when (b.status in('已配')) then 1 when (b.status in('哺乳')) then 2 when(b.status in('断奶','流产')) then 3 else 99 end)," +
            "updated_at=timestamp without time zone 'now()' " +
            "from (select status, statusdate, individual, earcard from application.base_piggy_info) as b where p.earcard=b.earcard",nativeQuery = true)
    void batchUpdateFromBasePiggyInfo();

    @Query(value = "select gateway_name, avg(curr_temp) as group_avg_temp from application.node_piggy_view where node_status = 1 group by gateway_name", nativeQuery = true)
    List<Map<String, Object>> findAvgTemperatureGroupByGateway();

    @Query(value = "select * from application.piggy", nativeQuery = true)
    List<Piggy> findPiggyUpdatedInfo();

    /*获取已关联猪舍与网关的猪舍猪只耳标列表*/
    @Query(value = "select d.*,e.name managername,f.point_x,f.point_y from \t\t\n" +
            "\t\t(select a.id,a.earcard,a.node_id,a.pigsty_id,a.updated_at,b.name pigstyname,b.width,b.high,b.header_id,c.name nodename,c.sn nodesn,c.gateway_id,c.gateway_name \n" +
            "\t\tfrom application.piggy\ta\n" +
            "\t\tleft join application.pigsty b on a.pigsty_id = b.id\n" +
            "\t\tleft join application.node c on a.node_id = c.id\n" +
            "\t\twhere c.status =0)d\n" +
            "\tleft join application.manager e on d.header_id = e.id\n" +
            "\tleft join application.pigstymap f on d.gateway_id = f.gateway_id and d.pigsty_id = f.pigsty_id", nativeQuery = true)
    List<Map<String,Object>> findEarTagList();
    /*获取已关联猪舍与网关的猪舍猪只耳标列表——某猪舍*/
    @Query(value = "select g.*,h.name nodename,h.sn nodesn from\n" +
            "\t\t(select c.*,d.name,e.id piggyId,e.earcard,e.node_id,e.detected_at updated_at, f.name gateway_name\n" +
            "\t\t from (select a.*,b.header_id,b.width,b.high,b.name pigstyname\n" +
            "\t\t\tfrom application.pigstymap a\n" +
            "\t\t\tleft join application.pigsty b on a.pigsty_id = b.id)c\n" +
            "\t\tleft join application.manager d on c.header_id = d.id\n" +
            "\t\tleft join application.piggy e on c.pigsty_id = e.pigsty_id\n" +
            "\t\tleft join application.gateway f on c.gateway_id = f.id) g\n" +
            "    left join application.node h on g.node_id = h.id \t\n" +
            "\twhere h.status = 0 and g.pigsty_id=?1", nativeQuery = true)
    List<Map<String,Object>> findEarTagListByPigstyId(Long pigstyId);
}