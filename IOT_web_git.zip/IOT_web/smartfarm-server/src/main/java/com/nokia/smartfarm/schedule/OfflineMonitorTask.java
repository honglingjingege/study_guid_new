package com.nokia.smartfarm.schedule;

import com.nokia.smartfarm.config.SystemConfig;
import com.nokia.smartfarm.enums.OnOffStatus;
import com.nokia.smartfarm.pojo.Node;
import com.nokia.smartfarm.pojo.Piggy;
import com.nokia.smartfarm.service.NodeService;
import com.nokia.smartfarm.service.PiggyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Component
@Slf4j
public class OfflineMonitorTask {
    private static final int OFFLINE_COUNT = 3;

    @Autowired
    NodeService nodeService;

    @Autowired
    PiggyService piggyService;

    @Scheduled(fixedRate = 1000 * 60 * 10, initialDelay = 6000)
    public void checkOfflineStatus() {
        List<Piggy> piggyUpdatedInfos = piggyService.findPiggyUpdatedInfo();
        for(Piggy info : piggyUpdatedInfos) {
            boolean result = checkOffline(info.getUpdatedAt());
            if(result) {
                Optional<Node> optionalNode = nodeService.getNodeById(info.getNodeId());
                if (optionalNode.isPresent()) {
                    Node node = optionalNode.get();
                    log.warn("Node -> {} is offline", node.getName());
                    node.setStatus(OnOffStatus.OFFLINE.getCode());
                    nodeService.save(node);
                }
            }
        }
    }

    private boolean checkOffline(Date updatedAt) {
        return System.currentTimeMillis() - updatedAt.getTime() > SystemConfig.getInstance().getInt(SystemConfig.Keys.REPORT_INTERVAL) * 60 * OFFLINE_COUNT * 1000;
    }
}
