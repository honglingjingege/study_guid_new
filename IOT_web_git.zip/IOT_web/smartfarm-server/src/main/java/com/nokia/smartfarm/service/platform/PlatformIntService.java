package com.nokia.smartfarm.service.platform;

import com.nokia.smartfarm.config.SystemConfig;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.httpclient.DefaultHttpMethodRetryHandler;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.HttpStatus;
import org.apache.commons.httpclient.NameValuePair;
import org.apache.commons.httpclient.methods.GetMethod;
import org.apache.commons.httpclient.methods.PostMethod;
import org.apache.commons.httpclient.methods.PutMethod;
import org.apache.commons.httpclient.methods.StringRequestEntity;
import org.apache.commons.httpclient.params.HttpMethodParams;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class PlatformIntService {

    @Value("${edgeboard.url:''}")
    private String url;

    @Value("${edgeboard.username:''}")
    private String username;

    @Value("${edgeboard.password:''}")
    private String password;

    @Value("${edgeboard.customerId:''}")
    private String customerId;


    public String getToken() {
        String resStr = null;
        log.info("Start get token ...");
        String getTokenUrl = url + "/api/auth/login";
        log.info("get token url is -> {}", getTokenUrl);

        HttpClient httpClient = new HttpClient();
        PostMethod postMethod = new PostMethod(getTokenUrl);
        postMethod.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "UTF-8");
        postMethod.getParams().setParameter(HttpMethodParams.SO_TIMEOUT, 5000);
        postMethod.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, new DefaultHttpMethodRetryHandler());
        postMethod.addRequestHeader( "Content-Type","application/json" );
        postMethod.addRequestHeader( "Accept", "application/json");
        String body = "{\"username\":\""+ username + "\", \"password\":\""+password+"\"}";
        log.info("Get token request body -> {}", body);
        try {
            postMethod.setRequestEntity( new StringRequestEntity( body, null, null ) );
            int statusCode = httpClient.executeMethod(postMethod);
            log.info("Get token response statusCode -> {}", statusCode);
            if (statusCode != HttpStatus.SC_ACCEPTED && statusCode != HttpStatus.SC_OK) {
                log.info("Get token failed -> {}", postMethod.getStatusLine());
                return null;
            }
            byte[] responseBody = postMethod.getResponseBody();
            resStr = new String(responseBody, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            postMethod.releaseConnection();
        }
        log.info("Get token response message -> {}",resStr);
        postMethod.releaseConnection();

        return resStr;
    }

    public String getDevicesByCustomer() {
        SystemConfig config = SystemConfig.getInstance();
        log.info("Start get devices by customerId -> {}", customerId);
        String resStr = null;
        String getUrl = url + "/api/customer/"+ customerId+"/devices?limit=1000";
        log.info("get url is -> {}", getUrl);

        HttpClient htpClient = new HttpClient();
        GetMethod getMethod = new GetMethod(getUrl);
        getMethod.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "UTF-8");
        getMethod.getParams().setParameter(HttpMethodParams.SO_TIMEOUT, 5000);
        getMethod.getParams().setParameter(HttpMethodParams.RETRY_HANDLER, new DefaultHttpMethodRetryHandler());
        getMethod.addRequestHeader( "Content-Type","application/json" );
        getMethod.addRequestHeader( "Accept", "application/json");
        getMethod.addRequestHeader( "X-Authorization", "Bearer "+ config.getTokenModel().getToken());

        try {
            int statusCode = htpClient.executeMethod(getMethod);
            log.info("Get devices by customerId response statusCode -> {}", statusCode);
            if (statusCode != HttpStatus.SC_ACCEPTED && statusCode != HttpStatus.SC_OK) {
                log.info("Get devices by customerId failed -> {}", getMethod.getStatusLine());
                return null;
            }
            byte[] responseBody = getMethod.getResponseBody();
            resStr = new String(responseBody, "UTF-8");
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            getMethod.releaseConnection();
        }
        log.info("Get devices by customerId response message -> {}",resStr);
        getMethod.releaseConnection();

        return resStr;
    }

    public String write(String endpoint, Object value) {
        SystemConfig config = SystemConfig.getInstance();
        log.info("Start write resource ...");
        String resStr = null;
        String writeUrl = url + "/api/plugin/" + endpoint + "/33/0/2";
        log.info("Write url is -> {}", writeUrl);

        HttpClient httpClient = new HttpClient();
        PutMethod putMethod = new PutMethod(writeUrl);
        putMethod.addRequestHeader("Content-Type", "application/json");
        putMethod.addRequestHeader("Accept", "application/json");
        putMethod.addRequestHeader( "X-Authorization", "Bearer "+ config.getTokenModel().getToken());

        putMethod.getParams().setParameter(HttpMethodParams.SO_TIMEOUT, 5000);
        String body = "{\"id\":"+ 2 + ", \"value\":"+Integer.parseInt(value.toString()) +"}";
        log.info("Write body is -> {}", body);
        try {
            putMethod.setRequestBody(body);
            int statusCode = httpClient.executeMethod(putMethod);
            log.info("Write response statusCode is -> {}", statusCode);
            resStr = putMethod.getResponseBodyAsString();
            log.info("Write response body is -> {}", resStr);
            if (statusCode == HttpStatus.SC_OK || statusCode == HttpStatus.SC_ACCEPTED) {
                log.info("Write success, status line is -> {}", putMethod.getStatusLine());
                return resStr;
            }
        } catch (Exception e) {
            log.error("Write failed -> {}", e.getMessage());
            e.printStackTrace();
        } finally {
            putMethod.releaseConnection();
        }
        log.error("Write failed, status line is -> {}", putMethod.getStatusLine());
        return null;
    }
}
