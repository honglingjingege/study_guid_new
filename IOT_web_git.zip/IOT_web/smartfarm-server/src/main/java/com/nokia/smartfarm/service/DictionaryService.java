package com.nokia.smartfarm.service;

import com.nokia.smartfarm.pojo.Dictionary;
import com.nokia.smartfarm.repository.DictionaryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.util.List;

/**
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/28 14:28
 */
@Service
public class DictionaryService {

    @Autowired
    private DictionaryRepository dictionaryRepository;

    /**
     * 根据常量类别获取该类别下的所有常量
     * @param dicCat 常量类别
     * @author pam
     * @return
     */
    public List<Dictionary> getConstantByDicCat(int dicCat){
        Assert.notNull(dicCat, "常量类别不能为空！");
        return dictionaryRepository.findByDicCatEquals(dicCat);
    }


}
