package com.nokia.smartfarm.service.platform.processor;

import com.nokia.smartfarm.config.SystemConfig;
import com.nokia.smartfarm.enums.AlarmStatus;
import com.nokia.smartfarm.model.AlarmCountModel;
import com.nokia.smartfarm.model.TemperatureCalModel;
import com.nokia.smartfarm.model.platform.BaseModel;
import com.nokia.smartfarm.model.platform.NodeModel;
import com.nokia.smartfarm.pojo.Node;
import com.nokia.smartfarm.pojo.Piggy;
import com.nokia.smartfarm.service.NodeService;
import com.nokia.smartfarm.service.PiggyService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPool;

import java.sql.Timestamp;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
@Slf4j
public class BindingProcessor implements Processor{
    @Autowired
    private JedisPool jedisPool;

    @Override
    public void process(List<BaseModel> baseModels) {
        Jedis jedis = jedisPool.getResource();
        try {
            for (BaseModel model : baseModels) {
                NodeModel nodeModel = (NodeModel) model;
                String serialNumber = nodeModel.getSerialNumber();
                String sensorId = nodeModel.getSensorId();
                String bindingKey = "binding" + sensorId;
                if(!jedis.exists(bindingKey)) {
                    Map<String, String> map = new HashMap<String, String>();
                    map.put(serialNumber, String.valueOf(0));
                    jedis.hmset(bindingKey,map);
                } else {
                    Map map = jedis.hgetAll(bindingKey);
                    Object o = map.get(serialNumber);
                    int count = 0;
                    if(o != null) {
                        try {
                            count = Integer.parseInt(o.toString());
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                    map.put(serialNumber, String.valueOf(count + 1));
                    jedis.hmset(bindingKey, map);
                }
            }
        }catch (Exception e) {
            e.printStackTrace();
        }finally {
            if(jedis != null) {
                try {
                    jedis.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }

    }
}
