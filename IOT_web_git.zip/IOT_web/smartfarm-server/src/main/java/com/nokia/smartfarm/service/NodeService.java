package com.nokia.smartfarm.service;

import com.nokia.smartfarm.pojo.Node;
import com.nokia.smartfarm.pojo.Piggy;
import com.nokia.smartfarm.repository.NodeRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

/**
 * @author pam
 * @version 1.0
 * @description
 * @date 2019/8/28 14:28
 */
@Service
public class NodeService {

    @Autowired
    private NodeRepository nodeRepository;

    /**
     * 获取所有耳标数量
     * @author pam
     * @return
     */
    public Long getNodeCount(){
        return nodeRepository.count();
    }

    /**
     * 获取所有错误耳标数量
     * @author pam
     * @time 2019年10月21日16:32:12
     * @return
     */
    public int getErrorNodeCount(){
        return nodeRepository.countByStatusEquals(0);
    }

    public boolean checkIfNodeExist(String sn) {
        return nodeRepository.existsBySnEquals(sn);
    }

    public Node findNodeBySn(String sn) {
        List<Node> nodes = nodeRepository.findNodeBySn(sn);
        if(nodes != null && nodes.size()>0) return nodes.get(0);
        return null;
    }

    public Node save(Node node) {
        return nodeRepository.save(node);
    }

    public List<Node> getAllNodes() {
        return nodeRepository.findAll();
    }

    public Optional<Node> getNodeById(Integer nodeId) {
        return nodeRepository.findById(nodeId);
    }
}
