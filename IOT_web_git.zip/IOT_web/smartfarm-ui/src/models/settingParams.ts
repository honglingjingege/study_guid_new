import { getSettingParams, updateSettingParams } from '@/services/settings';

export interface StateType {
  alarmAbsLowTempDiff: number,
  alarmAbsHighTempDiff: number,
  alarmDodLowTempDiff: number,
  alarmDodHighTempDiff: number,
  alarmPopLowTempDiff: number,
  alarmPopHighTempDiff: number,
  alarmInfoCount: number,
  alarmWarningCount: number,
  alarmErrorCount: number,
  reportInterval: number,
  pigstyBoundary: string,
  diagnoseResult: boolean
}
const SettingParams = {
  namespace: 'settingParams',

  state: {
    alarmAbsLowTempDiff: 1.5,
    alarmAbsHighTempDiff: 1.5,
    alarmDodLowTempDiff: 1.5,
    alarmDodHighTempDiff: 1.5,
    alarmPopLowTempDiff: 1.5,
    alarmPopHighTempDiff: 1.5,
    alarmInfoCount: 3,
    alarmWarningCount: 2,
    alarmErrorCount: 1,
    reportInterval: 15,
    pigstyBoundary: 'sameGateway',
    diagnoseResult: false,
  },
  effects: {
    *getSettingParams(_: any, { call, put }: any) {
      const response = yield call(getSettingParams);
      yield put({
        type: 'saveSettingParams',
        payload: response,
      });
    },
    *updateSettingParams({ payload }: any, { call, put }: any) {
      const response = yield call(updateSettingParams, payload);
      yield put({
        type: 'saveDiagnoseResult',
        payload: response,
      });
    },
  },

  reducers: {
    saveSettingParams(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        alarmAbsLowTempDiff: payload.alarm_abs_low_temp_diff,
        alarmAbsHighTempDiff: payload.alarm_abs_high_temp_diff,
        alarmDodLowTempDiff: payload.alarm_dod_low_temp_diff,
        alarmDodHighTempDiff: payload.alarm_dod_high_temp_diff,
        alarmPopLowTempDiff: payload.alarm_pop_low_temp_diff,
        alarmPopHighTempDiff: payload.alarm_pop_high_temp_diff,
        alarmInfoCount: payload.alarm_info_count,
        alarmWarningCount: payload.alarm_warning_count,
        alarmErrorCount: payload.alarm_error_count,
        reportInterval: payload.report_interval,
        pigstyBoundary: payload.pigsty_boundary,
      };
    },
    saveDiagnoseResult(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        diagnoseResult: payload.success,
      };
    },
  },
}
export default SettingParams;
