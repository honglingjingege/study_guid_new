import { getQueryCondition, getAllPiggyData, getGatewayMapData } from '@/services/allPiggy';

export interface StateType {
  periodStatusList: [],
  sickPiggyPage: [];
  filterCount: number;
  pageSize: number;
  diagnoseResult: boolean;
  gatewayMapData: [];
}

const Model = {
  namespace: 'allPiggy',

  state: {
    periodStatusList: [],
    sickPiggyPage: [],
    filterCount: 0,
    pageSize: 10,
    diagnoseResult: false,
    gatewayMapData: [],
  },

  effects: {
    * getQueryCondition(_: any, { call, put }: any) {
      const response = yield call(getQueryCondition);
      yield put({
        type: 'saveQueryCondition',
        payload: response,
      });
    },
    * getAllPiggyData({ payload }: any, { call, put }: any) {
      const response = yield call(getAllPiggyData, payload);
      yield put({
        type: 'saveTableData',
        payload: response,
      });
    },
    * getGatewayMapData({ payload }: any, { call, put }: any) {
      const response = yield call(getGatewayMapData, payload);
      yield put({
        type: 'saveGatewayMapData',
        payload: response,
      });
    },
  },
  reducers: {
    saveQueryCondition(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        periodStatusList: payload.periodStatusList,
      };
    },
    saveTableData(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        sickPiggyPage: payload.sickPiggyPage,
        filterCount: payload.filterCount,
        pageSize: payload.pageSize,
      };
    },
    saveGatewayMapData(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        gatewayMapData: payload
      };
    },
  },
};

export default Model;
