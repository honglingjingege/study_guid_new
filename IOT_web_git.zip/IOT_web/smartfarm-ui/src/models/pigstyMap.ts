import { getPigstyMap, getPigstyMapList, getPigstyList, getGatewayList, insertPigstyMap } from '@/services/pigstyMap';

export interface StateType {
  pigstyMap: { pigstyGatewayList:[], pigstyList:[], gatewayList:[] },
  pigstyMapList: [],
  gatewayList: [],
  pigstyList: [],
  diagnoseResult: boolean
}

const PigstyMap = {
  namespace: 'pigstyMap',
  state: {
    pigstyMap: { pigstyGatewayList: [], pigstyList: [], gatewayList: [] },
    pigstyMapList: [],
    gatewayList: [],
    pigstyList: [],
    diagnoseResult: false,
  },
  effects: {
    * getPigstyMap(_: any, { call, put }: any) {
        const response = yield call(getPigstyMap);
        yield put({
          type: 'savePigstyMap',
          payload: response,
        });
      },
    * getPigstyMapList(_: any, { call, put }: any) {
      const response = yield call(getPigstyMapList);
      yield put({
        type: 'savePigstyMapList',
        payload: response,
      });
    },
    * getPigstyList(_: any, { call, put }: any) {
      const response = yield call(getPigstyList);
      yield put({
        type: 'savePigstyList',
        payload: response,
      });
    },
    * getGatewayList(_: any, { call, put }: any) {
      const response = yield call(getGatewayList);
      yield put({
        type: 'saveGatewayList',
        payload: response,
      });
    },
    * insertPigstyMap({ payload }: any, { call, put }: any) {
      const response = yield call(insertPigstyMap, payload);
      yield put({
        type: 'saveDiagnoseResult',
        payload: response,
      });
    },
    // * getGatewayListByPigstyId(_: any, { call, put }: any) {
    //   const response = yield call(getGatewayListByPigstyId);
    //   yield put({
    //     type: 'savegatewayChoiceList',
    //     payload: response,
    //   });
    // },
  },
  reducers: {
    savePigstyMap(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        pigstyMap: payload,
      };
    },
    savePigstyMapList(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        pigstyMapList: payload.pigstyMapList,
      };
    },
    savePigstyList(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        pigstyMapList: payload.pigstyList,
      };
    },
    saveGatewayList(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        pigstyMapList: payload.gatewayList,
      };
    },
    saveDiagnoseResult(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        diagnoseResult: payload.success,
      };
    },
    // savegatewayChoiceList(state: any, action: { payload: any; }) {
    //   const { payload } = action;
    //   return {
    //     ...state,
    //     gatewayChoiceList: payload,
    //   };
    // },
  },
}
export default PigstyMap;
