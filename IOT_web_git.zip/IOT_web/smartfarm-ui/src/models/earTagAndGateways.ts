import { getEarTagAndGateway } from '@/services/earTagAndGateway';

export interface StateType {
  earTagAndGateway : {earTagList:[], gatewayList:[]}
}

const EarTagAndGateway = {
  namespace: 'earTagAndGateway',
  state: {
    earTagAndGateway: { earTagList: [], gatewayList: [] },
  },
  effects: {
    * getEarTagAndGateway(_: any, { call, put }: any) {
      const response = yield call(getEarTagAndGateway);
      yield put({
        type: 'saveEarTagAndGateway',
        payload: response,
      });
    },
  },
  reducers: {
    saveEarTagAndGateway(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        earTagAndGateway: payload,
      };
    },
  },
}
export default EarTagAndGateway;
