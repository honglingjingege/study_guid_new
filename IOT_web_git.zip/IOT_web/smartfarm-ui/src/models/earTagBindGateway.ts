import { getPiggyBindGetway, getPiggyBindGetwayByEarIdOrPeriod } from '@/services/earTagBindGateway';


export interface StateType {
  earTagBindGateway : any[]
}

const EarTagBindGateway = {
  namespace: 'earTagBindGateway',
  state: {
    earTagBindGateway: [],
  },
  effects: {
    * getPiggyBindGetway(_: any, { call, put }: any) {
      const response = yield call(getPiggyBindGetway);
      yield put({
        type: 'savePiggyBindGetway',
        payload: response,
      });
    },
    *getPiggyBindGetwayByEarIdOrPeriod({ payload }: any, { call, put }: any) {
      const response = yield call(getPiggyBindGetwayByEarIdOrPeriod, payload);
      console.log('response', response)
      yield put({
        type: 'savePiggyBindGetway',
        payload: response,
      });
    },
  },
  reducers: {
    savePiggyBindGetway(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        earTagBindGateway: payload,
      };
    },
  },
}
export default EarTagBindGateway;
