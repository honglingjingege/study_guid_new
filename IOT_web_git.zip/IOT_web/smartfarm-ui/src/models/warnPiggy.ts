import { getWarnPiggyNum, getWarnPiggyData, updateAlarmStatus, getGatewayMapData } from '@/services/warnPiggy';

export interface StateType {
  piggyCount: number;
  alarmPiggyCount: number;
  periodStatusList: any[],
  pigstyWithAlarmPiggy: any[],
  sickPiggyPage: any[];
  gatewayMapData: any[];
  filterCount: number;
  pageSize: number;
  diagnoseResult: boolean;
}

const Model = {
  namespace: 'warnPiggy',

  state: {
    piggyCount: 0,
    alarmPiggyCount: 0,
    periodStatusList: [],
    pigstyWithAlarmPiggy: [],
    sickPiggyPage: [],
    gatewayMapData: [],
    filterCount: 0,
    pageSize: 10,
    diagnoseResult: false,
  },

  effects: {
    *getWarnPiggyNum({ payload }: any, { call, put }: any) {
      const response = yield call(getWarnPiggyNum, payload);
      yield put({
        type: 'saveWarnPiggyNum',
        payload: response,
      });
    },
    *getWarnPiggyData({ payload }: any, { call, put }: any) {
      const response = yield call(getWarnPiggyData, payload);
      yield put({
        type: 'saveTableData',
        payload: response,
      });
    },
    *updateAlarmStatus({ payload }: any, { call, put }: any) {
      const response = yield call(updateAlarmStatus, payload);
      yield put({
        type: 'saveDiagnoseResult',
        payload: response,
      });
    },
    *getGatewayMapData({ payload }: any, { call, put }: any) {
      const response = yield call(getGatewayMapData, payload);
      yield put({
        type: 'saveGatewayMapData',
        payload: response,
      });
    },
  },

  reducers: {
    saveWarnPiggyNum(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        piggyCount: payload.piggyCount,
        alarmPiggyCount: payload.alarmPiggyCount,
        periodStatusList: payload.periodStatusList,
        pigstyWithAlarmPiggy: payload.pigstyWithAlarmPiggy,
      };
    },
    saveTableData(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        sickPiggyPage: payload.sickPiggyPage,
        filterCount: payload.filterCount,
        pageSize: payload.pageSize,
      };
    },
    saveDiagnoseResult(state: any, action: { payload: any; }) {
        const { payload } = action;
        return {
          ...state,
          diagnoseResult: payload.success,
        };
    },
    saveGatewayMapData(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        gatewayMapData: payload,
      };
    },
  },
};

export default Model;
