import { getDiseasePiggyData, getQueryCondition, deletePiggy, getUpdateCondition, savePiggy, getPiggyInfo, getGatewayMapData } from '@/services/diseasePiggy';

export interface StateType {
  periodStatusList: any[],
  diseasePiggyPage: any[],
  deleteResult: boolean,
  filterCount: number,
  pageSize: number,
  nodeList: any[],
  pigstyList: any[],
  entireList: any[],
  savePiggyResult: boolean,
  piggyInfo: object,
  gatewayMapData: any[],
}

const Model = {
  namespace: 'diseasePiggy',

  state: {
    periodStatusList: [],
    diseasePiggyPage: [],
    deleteResult: false,
    filterCount: 0,
    pageSize: 10,
    nodeList: [],
    pigstyList: [],
    entireList: [],
    savePiggyResult: false,
    piggyInfo: [],
    gatewayMapData: [],
  },

  effects: {
    * getQueryCondition(_: any, { call, put }: any) {
      const response = yield call(getQueryCondition);
      yield put({
        type: 'saveQueryCondition',
        payload: response,
      });
    },
    *getDiseasePiggyData({ payload }: any, { call, put }: any) {
      const response = yield call(getDiseasePiggyData, payload);
      yield put({
        type: 'saveTableData',
        payload: response,
      });
    },
    *deletePiggy({ payload }: any, { call, put }: any) {
      const response = yield call(deletePiggy, payload);
      yield put({
        type: 'saveDeleteResult',
        payload: response,
      });
    },
    *getUpdateCondition(_: any, { call, put }: any) {
      const response = yield call(getUpdateCondition);
      yield put({
        type: 'saveUpdateCondition',
        payload: response,
      });
    },
    *savePiggy({ payload }: any, { call, put }: any) {
      const response = yield call(savePiggy, payload);
      yield put({
        type: 'savePiggyResult',
        payload: response,
      });
    },
    *getPiggyInfo({ payload }: any, { call, put }: any) {
      const response = yield call(getPiggyInfo, payload);
      yield put({
        type: 'savePiggyInfo',
        payload: response,
      });
    },
    *getGatewayMapData({ payload }: any, { call, put }: any) {
      const response = yield call(getGatewayMapData, payload);
      yield put({
        type: 'saveGatewayMapData',
        payload: response,
      });
    },
  },
  reducers: {
    saveQueryCondition(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        periodStatusList: payload.periodStatusList,
      };
    },
    saveTableData(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        diseasePiggyPage: payload.diseasePiggyPage,
        filterCount: payload.filterCount,
        pageSize: payload.pageSize,
      };
    },
    saveDeleteResult(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        deleteResult: payload.success,
      };
    },
    saveUpdateCondition(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        periodStatusList: payload.periodStatusList,
        nodeList: payload.nodeList,
        pigstyList: payload.pigstyList,
        entireList: payload.entireList,
      };
    },
    savePiggyResult(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        savePiggyResult: payload.success,
      };
    },
    savePiggyInfo(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        piggyInfo: JSON.parse(payload.piggy),
      };
    },
    saveGatewayMapData(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        gatewayMapData: payload,
      };
    },
  },
};

export default Model;
