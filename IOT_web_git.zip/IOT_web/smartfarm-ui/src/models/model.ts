import { queryTags } from '@/services/service';

const Model = {
  namespace: 'home',

  state: {
    tags: [],
  },

  effects: {
    *fetchTags1(_: any, { call, put }: any) {
      const response = yield call(queryTags);
      yield put({
        type: 'saveTags',
        payload: response.list,
      });
    },
  },

  reducers: {
    saveTags(state: any, action: { payload: any; }) {
      return {
        ...state,
        tags: action.payload,
      };
    },
  },
};

export default Model;
