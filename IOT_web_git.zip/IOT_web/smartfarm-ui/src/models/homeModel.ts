import { getCardsContent, getHomeChart } from '@/services/homeService';

export interface StateType {
  nodeCount: number;
  errorNodeCount: number;
  gatewayCount: number;
  errorGatewayCount: number;
  piggyCount: number;
  alarmPiggyCount: number;
  envTemp: number;
  envHumidity: number;
  pigstyWithAlarmPiggy: any;
  sickPiggyPage: [];
  sickPiggyCount: number;
}

const Model = {
  namespace: 'homeModel',

  state: {
    nodeCount: 0,
    errorNodeCount: 0,
    gatewayCount: 0,
    errorGatewayCount: 0,
    piggyCount: 0,
    alarmPiggyCount: 0,
    envTemp: 0,
    envHumidity: 0,
    pigstyWithAlarmPiggy: [],
    sickPiggyPage: [],
    sickPiggyCount: 0,
  },

  effects: {
    *getCardsContent({ payload }: any, { call, put }: any) {
      const response = yield call(getCardsContent, payload);
      yield put({
        type: 'saveCardsContent',
        payload: response,
      });
    },
    *getHomeChart({ payload }: any, { call, put }: any) {
      const response = yield call(getHomeChart, payload);
      yield put({
        type: 'saveHomeChart',
        payload: response,
      });
    },
  },

  reducers: {
    saveCardsContent(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        nodeCount: payload.nodeCount,
        errorNodeCount: payload.errorNodeCount,
        gatewayCount: payload.gatewayCount,
        errorGatewayCount: payload.errorGatewayCount,
        piggyCount: payload.piggyCount,
        alarmPiggyCount: payload.alarmPiggyCount,
        envTemp: payload.envTemp,
        envHumidity: payload.envHumidity,
        pigstyWithAlarmPiggy: payload.pigstyWithAlarmPiggy,
        sickPiggyPage: payload.sickPiggyPage,
        sickPiggyCount: payload.sickPiggyCount,
      };
    },
    saveHomeChart(state: any, action: { payload: any; }) {
      const { payload } = action;
      return {
        ...state,
        pigstyWithAlarmPiggy: payload.pigstyWithAlarmPiggy,
      };
    },
  },
};

export default Model;
