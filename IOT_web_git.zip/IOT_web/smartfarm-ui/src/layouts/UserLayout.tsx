import { MenuDataItem, getMenuData, getPageTitle } from '@ant-design/pro-layout';
import GlobalFooter from '@/components/GlobalFooter';
import DocumentTitle from 'react-document-title';
import Link from 'umi/link';
import React, { Fragment } from 'react';
import { Icon } from 'antd';
import { connect } from 'dva';
import { formatMessage, setLocale } from 'umi-plugin-react/locale';

import { ConnectProps, ConnectState } from '@/models/connect';
import logo from '../assets/logo.svg';
import styles from './UserLayout.less';

export interface UserLayoutProps extends ConnectProps {
  breadcrumbNameMap: { [path: string]: MenuDataItem };
}

const UserLayout: React.SFC<UserLayoutProps> = props => {
  setLocale('zh-CN', false);// 设置默认语言，防止浏览器清空缓存后变为英文@pam
  const copyright = (
    <Fragment>Copyright <Icon type="copyright" />2019 Nokia IOT Application</Fragment>
  )
  const {
    route = {
      routes: [],
    },
  } = props;
  const { routes = [] } = route;
  const {
    children,
    location = {
      pathname: '',
    },
  } = props;
  const { breadcrumb } = getMenuData(routes);

  return (
    <DocumentTitle
      title={getPageTitle({
        pathname: location.pathname,
        breadcrumb,
        formatMessage,
        ...props,
      })}
    >
      <div className={styles.container}>
        <div className={styles.content}>
          <div className={styles.top}>
            <div className={styles.header}>
              <Link to="/">
                <img alt="logo" className={styles.logo} src={logo} />
                <span className={styles.title}>祥欣科技</span>
              </Link>
            </div>
            <div className={styles.desc}>物联网应用平台</div>
          </div>
          {children}
        </div>
        <GlobalFooter copyright={copyright} />
      </div>
    </DocumentTitle>
  );
};

export default connect(({ settings }: ConnectState) => ({
  ...settings,
}))(UserLayout);
