import dva from 'dva';
import { Component } from 'react';
import createLoading from 'dva-loading';
import history from '@tmp/history';

let app = null;

export function _onCreate() {
  const plugins = require('umi/_runtimePlugin');
  const runtimeDva = plugins.mergeConfig('dva');
  app = dva({
    history,
    
    ...(runtimeDva.config || {}),
    ...(window.g_useSSR ? { initialState: window.g_initialData } : {}),
  });
  
  app.use(createLoading());
  (runtimeDva.plugins || []).forEach(plugin => {
    app.use(plugin);
  });
  
  app.model({ namespace: 'allPiggy', ...(require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/models/allPiggy.ts').default) });
app.model({ namespace: 'diseasePiggy', ...(require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/models/diseasePiggy.ts').default) });
app.model({ namespace: 'earTagAndGateways', ...(require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/models/earTagAndGateways.ts').default) });
app.model({ namespace: 'earTagBindGateway', ...(require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/models/earTagBindGateway.ts').default) });
app.model({ namespace: 'global', ...(require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/models/global.ts').default) });
app.model({ namespace: 'homeModel', ...(require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/models/homeModel.ts').default) });
app.model({ namespace: 'login', ...(require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/models/login.ts').default) });
app.model({ namespace: 'model', ...(require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/models/model.ts').default) });
app.model({ namespace: 'pigstyMap', ...(require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/models/pigstyMap.ts').default) });
app.model({ namespace: 'setting', ...(require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/models/setting.ts').default) });
app.model({ namespace: 'settingParams', ...(require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/models/settingParams.ts').default) });
app.model({ namespace: 'tempCurve', ...(require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/models/tempCurve.ts').default) });
app.model({ namespace: 'user', ...(require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/models/user.ts').default) });
app.model({ namespace: 'warnPiggy', ...(require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/models/warnPiggy.ts').default) });
  return app;
}

export function getApp() {
  return app;
}

export class _DvaContainer extends Component {
  render() {
    const app = getApp();
    app.router(() => this.props.children);
    return app.start()();
  }
}
