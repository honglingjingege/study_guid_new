import React from 'react';
import { Router as DefaultRouter, Route, Switch } from 'react-router-dom';
import dynamic from 'umi/dynamic';
import renderRoutes from 'umi/lib/renderRoutes';
import history from '@tmp/history';
import RendererWrapper0 from 'C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/pages/.umi/LocaleWrapper.jsx';
import _dvaDynamic from 'dva/dynamic';

const Router = require('dva/router').routerRedux.ConnectedRouter;

const routes = [
  {
    path: '/user',
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () =>
            import(/* webpackChunkName: "layouts__UserLayout" */ '../../layouts/UserLayout'),
          LoadingComponent: require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/components/PageLoading/index')
            .default,
        })
      : require('../../layouts/UserLayout').default,
    routes: [
      {
        path: '/user',
        redirect: '/user/login',
        exact: true,
      },
      {
        name: 'login',
        path: '/user/login',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__user__login" */ '../user/login'),
              LoadingComponent: require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/components/PageLoading/index')
                .default,
            })
          : require('../user/login').default,
        exact: true,
      },
      {
        component: () =>
          React.createElement(
            require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
      },
    ],
  },
  {
    path: '/',
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () =>
            import(/* webpackChunkName: "layouts__SecurityLayout" */ '../../layouts/SecurityLayout'),
          LoadingComponent: require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/components/PageLoading/index')
            .default,
        })
      : require('../../layouts/SecurityLayout').default,
    routes: [
      {
        path: '/',
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "layouts__BasicLayout" */ '../../layouts/BasicLayout'),
              LoadingComponent: require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/components/PageLoading/index')
                .default,
            })
          : require('../../layouts/BasicLayout').default,
        authority: ['admin', 'user'],
        routes: [
          {
            path: '/',
            redirect: '/data/home',
            exact: true,
          },
          {
            path: '/data',
            name: 'data',
            icon: 'line-chart',
            routes: [
              {
                path: '/data/home',
                name: 'home',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../data/home'),
                      LoadingComponent: require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../data/home').default,
                exact: true,
              },
              {
                path: '/data/warnPiggies',
                name: 'warnPiggies',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../data/warnPiggies'),
                      LoadingComponent: require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../data/warnPiggies').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/management',
            name: 'management',
            icon: 'key',
            routes: [
              {
                path: '/management/piggy',
                name: 'piggy',
                routes: [
                  {
                    path: '/management/piggy/disease',
                    name: 'disease',
                    component: __IS_BROWSER
                      ? _dvaDynamic({
                          component: () =>
                            import(/* webpackChunkName: "layouts__BasicLayout" */ '../management/piggy/disease'),
                          LoadingComponent: require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/components/PageLoading/index')
                            .default,
                        })
                      : require('../management/piggy/disease').default,
                    exact: true,
                  },
                  {
                    path: '/management/piggy/disease/update',
                    name: 'updatePiggy',
                    component: __IS_BROWSER
                      ? _dvaDynamic({
                          component: () =>
                            import(/* webpackChunkName: "layouts__BasicLayout" */ '../management/piggy/disease/update'),
                          LoadingComponent: require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/components/PageLoading/index')
                            .default,
                        })
                      : require('../management/piggy/disease/update').default,
                    hideInMenu: true,
                    exact: true,
                  },
                  {
                    path: '/management/piggy/temperature',
                    name: 'temperature',
                    component: __IS_BROWSER
                      ? _dvaDynamic({
                          component: () =>
                            import(/* webpackChunkName: "layouts__BasicLayout" */ '../management/piggy/temperature'),
                          LoadingComponent: require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/components/PageLoading/index')
                            .default,
                        })
                      : require('../management/piggy/temperature').default,
                    exact: true,
                  },
                  {
                    path: '/management/piggy/temperature/curve',
                    name: 'curve',
                    component: __IS_BROWSER
                      ? _dvaDynamic({
                          component: () =>
                            import(/* webpackChunkName: "layouts__BasicLayout" */ '../management/piggy/temperature/curve'),
                          LoadingComponent: require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/components/PageLoading/index')
                            .default,
                        })
                      : require('../management/piggy/temperature/curve')
                          .default,
                    hideInMenu: true,
                    exact: true,
                  },
                  {
                    component: () =>
                      React.createElement(
                        require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                          .default,
                        { pagesPath: 'src/pages', hasRoutesInConfig: true },
                      ),
                  },
                ],
              },
              {
                component: () =>
                  React.createElement(
                    require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/setting',
            name: 'setting',
            icon: 'setting',
            routes: [
              {
                path: '/setting/warn',
                name: 'warn',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../setting/warn'),
                      LoadingComponent: require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../setting/warn').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            path: '/deviceManagement',
            name: 'deviceManagement',
            icon: 'unordered-list',
            routes: [
              {
                path: '/deviceManagement/eartagsAndGateways',
                name: 'eartagsAndGateways',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../deviceManagement/eartagsAndGateways'),
                      LoadingComponent: require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../deviceManagement/eartagsAndGateways').default,
                exact: true,
              },
              {
                path: '/deviceManagement/pigstyMap',
                name: 'pigstyMap',
                component: __IS_BROWSER
                  ? _dvaDynamic({
                      component: () =>
                        import(/* webpackChunkName: "layouts__BasicLayout" */ '../deviceManagement/pigstyMap'),
                      LoadingComponent: require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/components/PageLoading/index')
                        .default,
                    })
                  : require('../deviceManagement/pigstyMap').default,
                exact: true,
              },
              {
                component: () =>
                  React.createElement(
                    require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                      .default,
                    { pagesPath: 'src/pages', hasRoutesInConfig: true },
                  ),
              },
            ],
          },
          {
            component: __IS_BROWSER
              ? _dvaDynamic({
                  component: () =>
                    import(/* webpackChunkName: "p__404" */ '../404'),
                  LoadingComponent: require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/components/PageLoading/index')
                    .default,
                })
              : require('../404').default,
            exact: true,
          },
          {
            component: () =>
              React.createElement(
                require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
                  .default,
                { pagesPath: 'src/pages', hasRoutesInConfig: true },
              ),
          },
        ],
      },
      {
        component: __IS_BROWSER
          ? _dvaDynamic({
              component: () =>
                import(/* webpackChunkName: "p__404" */ '../404'),
              LoadingComponent: require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/components/PageLoading/index')
                .default,
            })
          : require('../404').default,
        exact: true,
      },
      {
        component: () =>
          React.createElement(
            require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
              .default,
            { pagesPath: 'src/pages', hasRoutesInConfig: true },
          ),
      },
    ],
  },
  {
    component: __IS_BROWSER
      ? _dvaDynamic({
          component: () => import(/* webpackChunkName: "p__404" */ '../404'),
          LoadingComponent: require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/src/components/PageLoading/index')
            .default,
        })
      : require('../404').default,
    exact: true,
  },
  {
    component: () =>
      React.createElement(
        require('C:/N-5CG7022BNQ-Data/ychang/Desktop/IOT_web/smartfarm-ui/node_modules/umi-build-dev/lib/plugins/404/NotFound.js')
          .default,
        { pagesPath: 'src/pages', hasRoutesInConfig: true },
      ),
  },
];
window.g_routes = routes;
const plugins = require('umi/_runtimePlugin');
plugins.applyForEach('patchRoutes', { initialValue: routes });

export { routes };

export default class RouterWrapper extends React.Component {
  unListen = () => {};

  constructor(props) {
    super(props);

    // route change handler
    function routeChangeHandler(location, action) {
      plugins.applyForEach('onRouteChange', {
        initialValue: {
          routes,
          location,
          action,
        },
      });
    }
    this.unListen = history.listen(routeChangeHandler);
    routeChangeHandler(history.location);
  }

  componentWillUnmount() {
    this.unListen();
  }

  render() {
    const props = this.props || {};
    return (
      <RendererWrapper0>
        <Router history={history}>{renderRoutes(routes, props)}</Router>
      </RendererWrapper0>
    );
  }
}
