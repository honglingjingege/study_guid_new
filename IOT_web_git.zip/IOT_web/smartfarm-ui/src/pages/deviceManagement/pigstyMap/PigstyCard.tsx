import React, { Component } from 'react';
import { Button, Icon } from 'antd';
import styles from '@/pages/deviceManagement/pigstyMap/style.less';

export interface PigstyCardProp {
  showParticalCard: boolean;
}

export default class PigstyCardComponent extends Component<PigstyCardProp> {
  constructor(props: PigstyCardProp) {
    super(props);
    this.state = {
      showParticalCard: true,
    };
  }

  componentWillReceiveProps(nextProps:any) {

  }

  showPigstyMap= (param:any) => {
    this.setState({ checkedId: param })
    this.props.changePigstyId(param)
  }

  foldCard= () => {
    this.setState({ showParticalCard: true })
  }

  unfoldCard= () => {
    this.setState({ showParticalCard: false })
  }

  render() {
    const showCardLenth = 6;
    // @ts-ignore
    const { pigstyList } = this.props;
    const showPigstyList = this.state.showParticalCard ?
      pigstyList.slice(0, showCardLenth) : pigstyList;
    const checkedId = this.state.checkedId ? this.state.checkedId :
      (showPigstyList[0] ? showPigstyList[0].pigstyId : 0);
    const pigstyDom = showPigstyList.map((pigsty: { pigstyId: React.ReactNode; }, key: number) => (
      <Button key={key} className={styles.pigsyCard_size} type={checkedId === pigsty.pigstyId ? 'primary' : ''} onClick={(event) => { this.showPigstyMap(pigsty.pigstyId) }}>{pigsty.pigstyName}</Button>
      ));
    pigstyDom.length >= showCardLenth ? (this.state.showParticalCard ? pigstyDom.push(<span key={showPigstyList.length} onClick={this.unfoldCard} className={styles.a_link_color}><span>展开更多</span><Icon type="double-right"/></span>) :
      pigstyDom.push(<span key={showPigstyList.length} onClick={this.foldCard} className={styles.a_link_color}><span>收起</span><Icon type="double-left"/></span>)) : pigstyDom;
    return (pigstyDom);
  }
}
