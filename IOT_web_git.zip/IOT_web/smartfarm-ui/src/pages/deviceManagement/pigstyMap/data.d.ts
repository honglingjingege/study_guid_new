export interface TagType {
  name: string;
  value: string;
  type: string;
}
