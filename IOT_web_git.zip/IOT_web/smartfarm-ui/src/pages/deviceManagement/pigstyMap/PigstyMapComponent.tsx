// data-set 可以按需引入，除此之外不要引入别的包
import React from 'react';
import {
  Chart,
  Geom,
  Axis,
  Tooltip,
  Label,
} from 'bizcharts';
import styles from '@/pages/deviceManagement/pigstyMap/style.less';
import {Col, message} from 'antd';

interface PigstyMapModalProp {
  location: {x: number, y: number};
  pigstyScale:{x:number, y:number}
  gateWayList:[{x:number, y:number, gatewayId: number, gatewayName: string}]
  enAbleClick: boolean
}

export default class PigstyMap extends React.Component<PigstyMapModalProp> {
  constructor(props: PigstyMapModalProp) {
    super(props);
    const { source, cols } =
      this.getEmptyScale(props.pigstyScale, props.gateWayList, props.location);
    this.state = {
      pigstyScale: props.pigstyScale,
      gateWayList: props.gateWayList,
      source,
      cols,
      enAbleClick: props.enAbleClick,
      location: props.location,
    };
  }

  componentWillReceiveProps(nextProps:any) {
    const { source, cols } =
      this.getEmptyScale(nextProps.pigstyScale, nextProps.gateWayList, nextProps.location);
    this.setState({
      pigstyScale: nextProps.pigstyScale,
      gateWayList: nextProps.gateWayList,
      enAbleClick: nextProps.enAbleClick,
      source,
      cols,
      location: nextProps.location,
    })
  }

  planPigystMap = (newData:{any: any}) => {
    newData = newData._origin ? newData._origin : newData;
    // @ts-ignore
    let { gateWayList } = this.state;
    // @ts-ignore
    const { pigstyScale } = this.state;
    delete newData.gateway;
    const strNewData = JSON.stringify(newData)
    const checkwithGatewayList = newData.gatewayId ? strNewData.split('gatewayId')[0] : strNewData.substring(0, strNewData.length - 1)
    if (this.state.enAbleClick) {
      if (!JSON.stringify(gateWayList).includes(checkwithGatewayList)) {
        this.props.showGatewayList(newData, gateWayList)
      } else {
        this.props.showEditOrDeleteGateway(newData, gateWayList)
      }
      const { source, cols } = this.getEmptyScale(pigstyScale, gateWayList, this.state.location);
      this.setState({ source, cols, gateWayList })
    }
  }

  getEmptyScale =(pigstyScale:{x:number, y:number},
                  gateWayList:[{x:number, y:number, gatewayId: number, gatewayName: string}],
                  location:{x:number, y:number}) => {
    const cols = {
      x: {
        type: 'cat',
        values: [],
        alias: '长度',
      },
      y: {
        type: 'cat',
        values: [],
        alias: '宽度',
      },
      gateway: {
        alias: '网关',
      },
    };
    const source = [];
    for (let i = 0; i < pigstyScale.x; i ++) {
      cols.x.values.push(i);
      for (let j = 0; j < pigstyScale.y; j++) {
        if (cols.y.values.length < pigstyScale.y) {
          cols.y.values.push(j);
        }
        const obj = {
          x: i,
          y: j,
          gateway: '',
        };
        source.push(obj);
      }
    }
    // console.log('gateWayList', gateWayList)
    if (pigstyScale.x && pigstyScale.y) {
      for (let i = 0; i < gateWayList.length; i++) {
        if (gateWayList[i].x !== null && gateWayList[i].y !== null &&
          gateWayList[i].x >= 0 && gateWayList[i].y >= 0) {
          const index = gateWayList[i].x * cols.y.values.length + gateWayList[i].y;
          if (source.length >= index) {
            source[index].gateway = gateWayList[i].gatewayName ? `${gateWayList[i].gatewayName}` : '';
          } else {
            message.error('网关最大边界超出猪舍边界范围，请重新设置猪舍长宽或解除相关网关的绑定！');
          }
        }
      }

      // @ts-ignore
      if (location.x >= 0 && location.y >= 0) {
        const index = location.x * cols.y.values.length + location.y;
        if (source.length >= index) {
          source[index].gateway = location.gatewayName ? ` ${location.gatewayName} ` : '';
        } else {
          message.error('网关最大边界超出猪舍边界范围，请重新设置猪舍长宽或解除相关网关的绑定！');
        }
      }
    }
    return { source, cols };
  }

  render() {
    const title = {
      offset: 30, // 设置标题 title 距离坐标轴线的距离
      textStyle: {
        fontSize: '12',
        textAlign: 'center',
        fill: '#999',
        // rotate: {角度}
      },
      position: 'center',
    }
    // @ts-ignore
    return (
      <div>
        <Col xl={23}>
          <Chart
            onPlotClick={ev => {
              this.planPigystMap(ev.data)
            }}
            height={300}
            data={this.state.source}
            scale={this.state.cols}
            padding={[20, 0, 40, 40]}
            forceFit
          >
            <Axis
              name="x"
              title={title}
              grid={{
                align: 'center',
                lineStyle: {
                  lineWidth: 1,
                  stroke: '#f0f0f0',
                },
              }}
            />
            <Axis
              name="y"
              title={title}
              grid={{
                align: 'center',
                lineStyle: {
                  lineWidth: 1,
                  stroke: '#f0f0f0',
                },
              }}
            />
            <Tooltip
              showTitle={false}
              crosshairs={{
                type: 'cross',
                style: {
                  stroke: '#2799FF',
                  strokeOpacity: '1',
                  lineDash: '5',
                },
              }}
            />
            <Geom
              select={true}
              type="polygon"
              position="x*y"
              color={['gateway', (gateway) => {
                if (gateway === '') return '#F0F0F0'; // 空白点
                if (gateway.length !== gateway.trim().length) return '#2894FF'; // 强调点
                return '#d0d0d0';// 正常点
              }]}
              style={{
                stroke: '#AAAAAA',
                lineWidth: 1,
              }}

              tooltip="x*y*gateway"
            >
              <Label
                content="gateway"
                offset={-2}
                textStyle={{
                  fill: 'black',
                 // fontWeight: 'bold',
                  shadowBlur: 1,
                  shadowColor: 'rgba(0, 0, 0, .45)',
                }}
                // htmlTemplate= {text => (text ? (<span><Icon type="gateway" /></span>) : '')}
              />
            </Geom>
          </Chart>
        </Col>
        <Col xl={1} className={styles.directionCol}>
          <span className={styles.direction}>↑</span>北
        </Col>
      </div>
    );
  }
}
