import { Row, message } from 'antd';
import React, { Component } from 'react';

import { GridContent } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { StateType } from '@/models/pigstyMap';
import { Dispatch } from 'redux';
import PigstyMap from './PigstyMapComponent';
import PigstyCardComponent from './PigstyCard';
import EditPigstyMapComponent from './EditPigstyMap';
import styles from '@/pages/deviceManagement/pigstyMap/style.less';

interface MonitorProps {
  pigstyMap: StateType;
  dispatch: Dispatch<any>;
  loading: boolean;
}

@connect(
  ({
     pigstyMap,
     loading,
   }: {
    pigstyMap: StateType;
    loading: {
      models: { [key: string]: boolean };
    };
  }) => ({
    pigstyMap,
    loading: loading.models.monitor,
  }),
)
class Monitor extends Component<MonitorProps> {
  state = {
    showPigstyId: '',
    pigstyGatewayList: [],
  }

  componentDidMount() {
    // @ts-ignore
    const { dispatch } = this.props;
    dispatch({
      type: 'pigstyMap/getPigstyMap',
    }).then(() => {
      const { pigstyMap } = this.props.pigstyMap
      const { pigstyGatewayList } = pigstyMap
      this.setState({ pigstyGatewayList })
    })
  }

  changePigstyId= (params:any) => {
    this.setState({ showPigstyId: params })
  }

  submitMapEdit= (pigstyId: number, pigstyScale: {x: number, y: number}, gateWayList:
    {x:number, y:number, gatewayId: number}) => {
    const { dispatch } = this.props;
    // @ts-ignore
    dispatch({
      type: 'pigstyMap/insertPigstyMap',
      payload: {
        pigstyId,
        pigstyScale: JSON.stringify(pigstyScale),
        gateWayList: JSON.stringify(gateWayList),
      },
    }).then(() => {
      const { pigstyMap } = this.props;
      const { diagnoseResult } = pigstyMap;
      if (diagnoseResult) {
        message.success('操作成功！');
      } else {
        message.error('操作失败！');
      }
      dispatch({
        type: 'pigstyMap/getPigstyMap',
      }).then(() => {
        const { pigstyMap } = this.props.pigstyMap
        const { pigstyGatewayList } = pigstyMap
        this.setState({ pigstyGatewayList })
      });
    })
  }

  render() {
     const { pigstyMap } = this.props.pigstyMap;
     const { pigstyGatewayList, pigstyList, gatewayList } = pigstyMap
     const hash = {};
     const pigstyIdList = Array.isArray(pigstyGatewayList) ? pigstyGatewayList
       .map((params) => params.pigsty_id)
         .reduce((item, next) => {
           hash[next] ? '' : hash[next] = true && item.push(next);
           return item;
         }, []).sort((a: number, b: number) =>
         a - b) : []
     const pigstyIdObjList: any[] | { pigstyId: any; pigstyName: any; }[] = []
     const bindedPigstyList: number[] = []; const bindedGatewayList: number[] = [];
     const pigstyMapData = pigstyIdList.map((pigstyId: any) => {
         const pigstyMapObj = {
           pigstyId,
           pigstyScale: { x: 0, y: 0 },
           gateWayList: [],
         };
       pigstyGatewayList.forEach((pigsty) => {
             if (!bindedPigstyList.includes(pigsty.pigsty_id)) {
               bindedPigstyList.push(pigsty.pigsty_id)
             }
             if (!bindedGatewayList.includes(pigsty.gateway_id)) {
               bindedGatewayList.push(pigsty.gateway_id)
             }
             if (pigsty.pigsty_id === pigstyId) {
               // @ts-ignore
               pigstyMapObj.gateWayList.push({
                 x: pigsty.point_x,
                 y: pigsty.point_y,
                 gatewayId: pigsty.gateway_id,
                 gatewayName: pigsty.gateway_name });
               pigstyMapObj.pigstyScale = { x: pigsty.width, y: pigsty.high }
               if (!JSON.stringify(pigstyIdObjList)
                 .includes(JSON.stringify({ pigstyId, pigstyName: pigsty.pigstyname }))) {
                   pigstyIdObjList.push({
                     pigstyId,
                     pigstyName: pigsty.pigstyname,
                   })
               }
             }
         });
         return pigstyMapObj
     })
     let showPigstyScale = { x: 0, y: 0 };
     let showGateWayList: never[] | [{ x: number; y: number; }] = [];
     if (pigstyMapData[0]) {
       const showPigstyMapData = pigstyMapData.find((item: { pigstyId: any; }) =>
           (this.state.showPigstyId ? item.pigstyId === this.state.showPigstyId : '')) || pigstyMapData[0];
       showPigstyScale = showPigstyMapData.pigstyScale;
       showGateWayList = showPigstyMapData.gateWayList;
     }
     const pigstyListOption = Array.isArray(pigstyList) ? pigstyList
       .filter((pigsty:{id: number}) => !bindedPigstyList.includes(pigsty.id)) : []
     // @ts-ignore
       const gatewayListOption: [{gatewayId: number, gatewayName: string}] = []
      if (Array.isArray(gatewayList)) {
        gatewayList.forEach((gateway:{id: number, name: string}) => {
          if (!bindedGatewayList.includes(gateway.id)) {
            gatewayListOption.push({ gatewayId: gateway.id, gatewayName: gateway.name })
          }
        })
      }
     return (
      <GridContent>
        <Row className={styles.text_align_center}><h2>猪舍地图列表</h2></Row>
          <Row className={styles.pigsty_ids}>
            <PigstyCardComponent pigstyId={this.state.showPigstyId} pigstyList={pigstyIdObjList}
                                 changePigstyId={this.changePigstyId} showParticalCard/>
          </Row>
          <Row>
            <EditPigstyMapComponent
            pigstyId={this.state.showPigstyId ? this.state.showPigstyId : pigstyIdList[0]}
            gateWayList={showGateWayList} pigstyScale={showPigstyScale}
            gatewayListOption={gatewayListOption} submitMapEdit={this.submitMapEdit}
            pigstyListOption={pigstyListOption} pigstyList={pigstyList}
            changePigstyId={this.changePigstyId} pigstyCardLsit={this.state.pigstyGatewayList}
            />
          </Row>
          {this.state.pigstyGatewayList.length === 0 ?
            (<Row>
              <span className={styles.noData_tips_style}>暂无猪舍，请添加！</span>
            </Row>) :
            (<Row><PigstyMap gateWayList={showGateWayList}
                              pigstyScale={showPigstyScale}
                              enAbleClick={false}
                              bindGatewayClick={false}
                              location={{ x: -1, y: -1 }}/>
            </Row>)}
      </GridContent>
    );
  }
}

export default Monitor;
