import { Modal, Button, Row, Col, Icon, message, Select, Table, Tooltip } from 'antd';
import React, { Component } from 'react';
import Input from 'antd/lib/input';
import styles from '@/pages/deviceManagement/pigstyMap/style.less';
import { blue, green, red, yellow } from '@ant-design/colors/lib';
import PigstyMap from './PigstyMapComponent';

const { Option } = Select;
export default class EditPigstyMapComponent extends React.Component {
  state = {
    visible: false,
    gatewayListVisible: false,
    editOrdeleteGatewayVisible: false,
    enAbleClick: true,
    pigstyScale: { x: 5, y: 8 },
    gateWayList: [],
    pigstyId: '',
    editPigstyId: '',
    pigstyScalex: '',
    pigstyScaley: '',
    columns: [],
    dataSource: [],
    sessionGatewayList: [],
    showPigstyName: '',
    pigstyCardLsit: [],
    editStatus : false,
  };

  componentWillReceiveProps(nextProps:any) {
    const { columns, dataSource } = this.tableData(nextProps.gatewayListOption)
    this.setState({
      editPigstyScale: nextProps.pigstyScale,
      editGateWayList: nextProps.gateWayList,
      pigstyId: nextProps.pigstyId,
      editPigstyId: nextProps.pigstyId,
      gatewayListOption: nextProps.gatewayListOption,
      pigstyListOption: nextProps.pigstyListOption,
      pigstyList: nextProps.pigstyList,
      showPigstyName: nextProps.pigstyList[0] ?
        (this.getPigstyNameById(nextProps.pigstyList, nextProps.pigstyId) ?
          this.getPigstyNameById(nextProps.pigstyList, nextProps.pigstyId).name : '') : '',
      columns,
      dataSource,
      sessionGatewayList: [],
      pigstyCardLsit: nextProps.pigstyCardLsit,
    })
  }

  getPigstyNameById = (pigstyNameList:any, pigstyId:any) => pigstyNameList
      .find((pigstyItem:any) => pigstyItem.id === pigstyId)

  tableData = (gatewayListOption: []) => {
    const columns = [{
      title: '网关列表',
      dataIndex: 'gatewayName',
      key: 'gatewayName',
      render: (text: any) => <a>{ text }</a>,
    }]
    const dataSource = gatewayListOption ? gatewayListOption.sort()
      .map((gateway: any, index: number) => {
        const obj = { key: index, gatewayId: gateway.gatewayId, gatewayName: gateway.gatewayName }
        return obj
      }) : []
    return { columns, dataSource }
  }

  bindGateway = () => {
    // @ts-ignore
    const { editPigstyScale, editGateWayList, editPigstyId, pigstyList } = this.state
    this.setState({
      pigstyScale: editPigstyScale,
      gateWayList: JSON.parse(JSON.stringify(editGateWayList)), // editGateWayList.concat(),
      pigstyId: editPigstyId,
      showPigstyName: pigstyList[0] ? (this.getPigstyNameById(pigstyList, editPigstyId) ? this.getPigstyNameById(pigstyList, editPigstyId).name : '') : '',
      visible: true,
      editStatus: true,
    });
  };

  showModal= () => {
    this.setState({
      pigstyScale: { x: 5, y: 8 },
      gateWayList: [],
      pigstyId: '',
      showPigstyName: '',
      pigstyScalex: '',
      pigstyScaley: '',
      visible: true,
      editStatus: false,
    });
  }

  handleOk = e => {
    if (!this.state.pigstyId) {
      message.info('请输入猪舍编号！');
    } else {
      const { gateWayList, pigstyScale, pigstyId } = this.state
      if (!gateWayList[0]) {
        message.info('请绑定网关！');
      } else {
        this.props.submitMapEdit(pigstyId, pigstyScale, gateWayList)
        this.setState({
          visible: false,
        });
      }
    }
  };

  handleCancel = e => {
    this.rollbackGatewayList()
    this.setState({
      visible: false,
    });
  };

  resetGateWay = () => {
    const showPigstyName = this.state.editStatus ? this.state.showPigstyName : ''
    this.setState({ gateWayList: [], pigstyId: '', showPigstyName, pigstyScale: { x: 5, y: 8 }, pigstyScalex: '', pigstyScaley: '' })
    this.rollbackGatewayList()
  };

  mapXChange= (event: { target: { value: any; }; }) => {
    const maxWidth = 20
    const minWidth = this.getMaxBundery('x')
    console.log('minHigh', minWidth)
    if (this.checkNumber(event.target.value)) {
      if (Number(event.target.value) <= maxWidth) {
        if (Number(event.target.value) >= minWidth) {
          this.setState({
            pigstyScale: { x: Number(event.target.value), y: this.state.pigstyScale.y },
            pigstyScalex: Number(event.target.value) });
        } else {
          message.error('猪舍宽度边界小于网关最大边界，请重新设置猪舍宽或解除相关网关的绑定！');
        }
      } else {
        message.info(`请设置小于${maxWidth}的地图宽度！`);
        this.setState({ pigstyScalex: event.target.value });
      }
    } else {
      this.setState({ pigstyScalex: event.target.value });
    }
  };

  mapYChange= (event: { target: { value: any; }; }) => {
    const maxHigh = 20
    const minHigh = this.getMaxBundery('y')
    if (this.checkNumber(event.target.value)) {
      if (Number(event.target.value) <= maxHigh) {
        if (Number(event.target.value) >= minHigh) {
          this.setState({
            pigstyScale: { x: this.state.pigstyScale.x, y: Number(event.target.value) },
            pigstyScaley: Number(event.target.value) });
        } else {
          message.error('猪舍宽度边界小于网关最大边界，请重新设置猪舍宽或解除相关网关的绑定！');
        }
      } else {
        message.info(`请设置小于${maxHigh}的地图宽度！`);
        this.setState({ pigstyScaley: event.target.value });
      }
    } else {
      this.setState({ pigstyScaley: event.target.value });
    }
  };

  getMaxBundery= (assia : string) => {
    const gatewayList = JSON.parse(JSON.stringify(this.state.gateWayList))
    const minX = gatewayList[0] ? gatewayList.map((gateway : any) => gateway.x)
      .sort((a: number, b: number) => b - a)[0] + 1 : 0
    const minY = gatewayList[0] ? gatewayList.map((gateway : any) => gateway.y)
      .sort((a: number, b: number) => b - a)[0] + 1 : 0
    return assia === 'x' ? minX : minY
  }

  pigstyId= (value: number) => {
    // @ts-ignore
    const { pigstyList } = this.state
    this.setState({
      pigstyId: Number(value),
      showPigstyName: pigstyList[0] ? (this.getPigstyNameById(pigstyList, value) ? this.getPigstyNameById(pigstyList, value).name : '') : '',
    });
  }

  checkNumber= (input:string) => {
    const numberReg = /^[0-9]*$/;
    if (!input.match(numberReg)) {
      message.info('请输入数字！');
      return false;
    }
      return true;
  };

  selecteOk = e => {
    console.log('this.state.rowId', this.state.rowId)
    if (this.state.rowId !== -1) {
      const gatewayId = this.state.rowId
      // @ts-ignore
      const { newData, gateWayList, gatewayListOption, sessionGatewayList } = this.state
      newData.gatewayId = gatewayId.gatewayId
      newData.gatewayName = gatewayId.gatewayName
      gateWayList.forEach((item: { x: number; y: number, gatewayId: number, gatewayName: string }) => {
        if ((item.x === newData.x && item.y === newData.y) || (item.x === null && item.y === null)) {
            item.x = -1
            item.y = -1
          gatewayListOption.push({ gatewayId: item.gatewayId, gatewayName: item.gatewayName })
          }
      })
      // @ts-ignore
      sessionGatewayList.push({ gatewayId: newData.gatewayId, gatewayName: newData.gatewayName })
      gateWayList.push(newData)
      const newGatewayListOption = gatewayListOption
      .filter((gateway:any) => gateway.gatewayId !== gatewayId.gatewayId)
      const { columns, dataSource } = this.tableData(newGatewayListOption)
      this.setState({
        rowId: -1,
        gateWayList,
        gatewayListVisible: false,
        gatewayListOption: newGatewayListOption,
        columns,
        dataSource,
      });
    } else {
      this.setState({
        gatewayListVisible: false,
      });
    }
  }

  rollbackGatewayList = () => {
    const { sessionGatewayList, gatewayListOption, gateWayList } = this.state
    const newGateWayList = gateWayList.filter(gateway =>
      !JSON.stringify(sessionGatewayList).includes(gateway.gatewayName))
    sessionGatewayList.forEach(gateway => {
      if (!JSON.stringify(gatewayListOption).includes(gateway)) {
        gatewayListOption.push(gateway)
      }
    })
    gatewayListOption.sort((a: any, b: any) => a.gatewayId - b.gatewayId)
    const { columns, dataSource } = this.tableData(gatewayListOption)
    this.setState({
      gatewayListOption,
      sessionGatewayList: [],
      gateWayList: newGateWayList,
      columns,
      dataSource,
      rowId: -1,
    });
  }

  selecteCancel = e => {
    // this.rollbackGatewayList()
    this.setState({
      gatewayListVisible: false,
      rowId: -1,
    });
  }

  showGatewayList= (newData: any, gateWayList: { filter: (arg0: (item:
                   { x: number; y: number, gatewayId: number, gatewayName: string })
      => boolean) => void; }) => {
    // console.log('this.state.pigstyId', this.state.pigstyId)
    if (!this.state.pigstyId && !this.state.editPigstyId) {
      message.info('请输入猪舍编号')
      return
    }
    this.setState({
      newData,
      gateWayList,
      gatewayListVisible: true,
    });
  }

  showEditOrDeleteGateway= (newData: any, gateWayList:
    { x: number; y: number, gatewayId: number, gatewayName: string }) => {
    if (!this.state.pigstyId && !this.state.editPigstyId) {
      message.info('请输入猪舍编号！')
      return
    }
    this.setState({
      newData,
      // @ts-ignore
      gateWayListEdit: gateWayList.concat(),
      editOrdeleteGatewayVisible: true,
    });
  }

  bindThisGateway= () => {
    this.setState({
      editOrdeleteGatewayVisible: false,
      gatewayListVisible: true,
    });
  }

  cancelThisBind= () => {
    // @ts-ignore
    const { gateWayListEdit, newData, gatewayListOption, rowId } = this.state
    gateWayListEdit.forEach((item:
                    { x: number, y: number, gatewayId: number, gatewayName: string }) => {
      if (item.x === newData.x && item.y === newData.y) {
        item.x = -1
        item.y = -1
        gatewayListOption.push({ gatewayId: item.gatewayId, gatewayName: item.gatewayName })
      }
    })
    const { columns, dataSource } = this.tableData(gatewayListOption)
    const gateWayList = gateWayListEdit
    this.setState({
      editOrdeleteGatewayVisible: false,
      gatewayListVisible: false,
      gateWayList,
      columns,
      dataSource,
    });
    // this.props.changePigstyId(this.state.pigstyId)
  }

  onClickRow = record => ({
      onClick: event => {
        this.setState({
          rowId: record,
        });
      },
    })

  setRowClassName = record => (record.gatewayId === (this.state.rowId ? this.state.rowId.gatewayId : this.state.rowId) ? styles.selected_table_row : '')


  render() {
    // @ts-ignore
    const { columns, dataSource, pigstyListOption } = this.state
    // @ts-ignore
    const pigstyOptionList = pigstyListOption ? pigstyListOption.map((pigsty:{}, index:number) =>
      // @ts-ignore
      (<Option key={index} value={pigsty.id}>{pigsty.name}</Option>)) : []
    const setGatewayTips = '提示:鼠标单击单元格并选择要绑定的网关，可设置或修改网关在猪舍地图的位置。'
    return (
      <Row>
        <Row className={styles.modular_space}>
          <a onClick={this.showModal}><Icon type="plus"/><span>新建平面图</span></a>
          {this.state.pigstyCardLsit.length === 0 ? null : (<a className={styles.edit_button_style} onClick={this.bindGateway}><span><Icon type="edit"/>编辑</span></a>)}
          {this.state.pigstyCardLsit.length === 0 ? null : (<span className={styles.graphTitle}>网关布局图</span>)}
        </Row>
        <Row>
          <Modal
            bodyStyle={{ height: 400 }}
            width={1000}
            centered
            mask
            visible={this.state.visible}
            onOk={this.handleOk}
            onCancel={this.handleCancel}
          >
            猪舍： <Select disabled={!!this.state.editStatus} value={this.state.showPigstyName} style={{ width: 180 }} onChange={this.pigstyId}>{pigstyOptionList}</Select> <span className={styles.margin_left_20px}>猪舍长度：  <Input onChange={this.mapXChange} value={this.state.pigstyScalex} placeholder="猪圈长度" style= {{ width: '80px' }}/></span>
            <span className={styles.margin_left_20px}>猪舍宽度：  <Input className={styles.input_width_80px} onChange={this.mapYChange} value={this.state.pigstyScaley} placeholder="猪圈宽度"/></span> <span className={styles.margin_left_20px}><Button onClick={this.resetGateWay}>重置</Button></span><Tooltip title={setGatewayTips}><span className={styles.tooltips_stylse_pigmapEdit}>提示:点击单元格可标记网关位置</span></Tooltip>
            <Row className={styles.modular_space} >
              <PigstyMap gateWayList={this.state.gateWayList}
                         pigstyScale={this.state.pigstyScale} enAbleClick={this.state.enAbleClick}
                         showGatewayList={this.showGatewayList} location={{ x: -1, y: -1 }}
                         showEditOrDeleteGateway={this.showEditOrDeleteGateway}/>
            </Row>
          </Modal>
        </Row>
        <Row>
          <Modal
            bodyStyle={{ height: 400 }}
            width={300}
            centered
            mask
            visible={this.state.gatewayListVisible}
            onOk={this.selecteOk}
            onCancel={this.selecteCancel}
          >
            <Table onRow={this.onClickRow} rowClassName={this.setRowClassName} pagination={ false }
                   columns={columns} dataSource={dataSource} scroll={{ y: 300 }}/>
          </Modal>
        </Row>
        <Row>
          <Modal
            bodyStyle={{ height: 100 }}
            width={300}
            centered
            mask
            visible={this.state.editOrdeleteGatewayVisible}
            confirmLoading={false}
            footer={null}
            onCancel={ () => {
              this.setState({
                editOrdeleteGatewayVisible: false,
              })
            }}
          >
            <Button onClick={this.bindThisGateway}>绑定</Button><Button onClick={this.cancelThisBind}>删除</Button>
          </Modal>
        </Row>
      </Row>
    );
  }
}
