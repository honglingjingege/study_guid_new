import React, { Component } from 'react';
import PigstyCardComponent from '../pigstyMap/PigstyCard';
import { Modal, Row, Table } from 'antd';
import PigstyMap from '@/pages/deviceManagement/pigstyMap/PigstyMapComponent';
import styles from '@/pages/deviceManagement/pigstyMap/style.less';

interface GatewayListComponentProps {
  gatewatList: any[];
}
export default class GatewayListComponent extends Component<GatewayListComponentProps> {
  state = {
    gatewatList: this.props.gatewatList,
    pigstyList: [],
    dataSource: [],
    columns: [],
    mapedTableData: [],
    location: null,
    gateWayList: null,
    pigstyScale: null,
    pigstyName: '',
  };

  componentWillReceiveProps(nextProps: any) {
    const { gatewayList } = nextProps;
    const mapedTableData = this.mapTableData(gatewayList);
    const pigstyId = this.getPigstyIdList(gatewayList)[0]
      ? this.getPigstyIdList(gatewayList)[0].pigstyId
      : 1;
    const { dataSource, columns } = this.showTableByPigstyId(mapedTableData, pigstyId);
    this.setState({
      gatewayList,
      mapedTableData,
      dataSource,
      columns,
      pigstyList: this.getPigstyIdList(gatewayList),
    });
  }

  changeEarTagTable = (params: any) => {
    const { mapedTableData } = this.state;
    const { dataSource, columns } = this.showTableByPigstyId(mapedTableData, params);
    this.setState({ pigstyId: params, dataSource, columns });
  };

  getPigstyIdList = (earTagList: []) => {
    const reducePara = {};
    return earTagList
      .map(item => {
        const obj = {
          pigstyId: item.pigsty_id,
          pigstyName: item.pigsty_name ? item.pigsty_name : '未分配',
        };
        return obj;
      })
      .reduce((item, next) => {
        reducePara[next.pigstyId] ? '' : (reducePara[next.pigstyId] = true && item.push(next));
        return item;
      }, [])
      .sort(
        (a, b) =>
          // @ts-ignore
          a.pigstyId - b.pigstyId,
      );
  };

  mapTableData = (earTagList: []) =>
    earTagList.map((gatewayItem, index: number) => {
      const gateway = {
        key: index,
        gatewayName: gatewayItem.gateway_name,
        pigstyId: gatewayItem.pigsty_id,
        pigstyName: gatewayItem.pigsty_name,
        nearestCheckTime: gatewayItem.updated_at,
        responsePerson: gatewayItem.manager_name,
        gatewayLocation: `${gatewayItem.point_x},${gatewayItem.point_y}`,
        gatewayId: gatewayItem.gateway_id,
        pigstyScale: { x: gatewayItem.width, y: gatewayItem.high },
      };
      return gateway;
    });

  utc2beijing = (utDatetime: any) => {
    // 转为正常的时间格式 年-月-日 时:分:秒
    utDatetime = utDatetime.replace(/\.[\d]{3}.*/, 'Z');
    const Tpos = utDatetime.indexOf('T');
    const Zpos = utDatetime.indexOf('Z');
    const yearmonthday = utDatetime.substr(0, Tpos);
    const hourminutesecond = utDatetime.substr(Tpos + 1, Zpos - Tpos - 1);
    const newdatetime = `${yearmonthday} ${hourminutesecond}`; // 2017-03-31 08:02:06

    // 处理成为时间戳
    let timestamp: number = new Date(Date.parse(newdatetime));
    timestamp = timestamp.getTime();
    timestamp /= 1000;

    // 增加8个小时，北京时间比utc时间多八个时区
    timestamp += 8 * 60 * 60;

    // 时间戳转为时间
    const beijingDatetime = new Date(parseInt(timestamp) * 1000)
      .toLocaleString()
      .replace(/年|月/g, '-')
      .replace(/日/g, ' ');
    return beijingDatetime;
  };

  showTableByPigstyId = (allDataSource: any, pigstyId: number) => {
    const dataSource = allDataSource.filter((item: any) => item.pigstyId === pigstyId);
    const columns = [
      {
        title: '异常网关名称',
        dataIndex: 'gatewayName',
        key: 'gatewayName',
      },
      {
        title: '最近检测时间',
        dataIndex: 'nearestCheckTime',
        key: 'nearestCheckTime',
        render: (time: any) => <span>{this.utc2beijing(time)}</span>,
      },
      {
        title: '负责人',
        dataIndex: 'responsePerson',
        key: 'responsePerson',
        render: (responsePerson: string) => <span>{responsePerson || '暂无'}</span>,
      },
      {
        title: '位置',
        dataIndex: 'gatewayLocation',
        key: 'gatewayLocation',
        render: (text: any, record: any, index: any) => (
          <span>
            {Number(text.split(',')[0]) >= 0 && Number(text.split(',')[1]) >= 0 ? (
              <a
                onClick={e => {
                  this.showGatewayMap(record);
                }}
              >
                {text}
              </a>
            ) : (
              '暂无'
            )}
          </span>
        ),
      },
    ];
    return { dataSource, columns };
  };

  changeGatewayTable = (params: any) => {
    const { mapedTableData } = this.state;
    const { dataSource, columns } = this.showTableByPigstyId(mapedTableData, params);
    this.setState({ pigstyId: params, dataSource, columns });
  };

  showGatewayMap = (gateway: any) => {
    const location = {
      x: Number(gateway.gatewayLocation.split(',')[0]),
      y: Number(gateway.gatewayLocation.split(',')[1]),
      gatewayId: gateway.gatewayId,
      gatewayName: gateway.gatewayName,
    };
    // const pigstyId = record.pigstyId
    // @ts-ignore
    const { gatewayList } = this.state;
    const newGatewayList: any[] = [];
    gatewayList.forEach((item: any) => {
      if (item.pigsty_id === gateway.pigstyId) {
        newGatewayList.push({
          x: item.point_x,
          y: item.point_y,
          gatewayId: item.gateway_id,
          gatewayName: item.gateway_name,
        });
      }
    });
    this.setState({
      location,
      pigstyScale: gateway.pigstyScale,
      gateWayList: newGatewayList,
      pigstyName: gateway.pigstyName ? gateway.pigstyName : '未分配',
      visible: true,
    });
  };

  handleOk = e => {
    this.setState({
      visible: false,
    });
  };

  handleCancel = e => {
    this.setState({
      visible: false,
    });
  };

  render() {
    const { dataSource, columns, pigstyList } = this.state;
    return (
      <Row>
        <Row>
          <PigstyCardComponent
            pigstyList={pigstyList}
            pigstyId={this.state.pigstyId}
            changePigstyId={this.changeGatewayTable}
            showParticalCard
          />
        </Row>
        <Row>
          <Table dataSource={dataSource} columns={columns} />
        </Row>
        <Row>
          <Modal
            bodyStyle={{ height: 400 }}
            width={1000}
            centered
            mask
            visible={this.state.visible}
            onOk={this.handleOk}
            onCancel={this.handleCancel}
            footer={null}
          >
            <Row>
              <span className={styles.pigsty_name_padding}>猪舍：{this.state.pigstyName}</span>
            </Row>
            <PigstyMap
              gateWayList={this.state.gateWayList}
              pigstyScale={this.state.pigstyScale}
              enAbleClick={false}
              location={this.state.location}
            />
          </Modal>
        </Row>
      </Row>
    );
  }
}
