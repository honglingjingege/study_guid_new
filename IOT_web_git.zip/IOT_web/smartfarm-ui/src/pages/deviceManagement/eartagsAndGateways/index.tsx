import { Row, Tabs } from 'antd';
import React, { Component } from 'react';

import { GridContent } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { StateType } from '@/models/earTagAndGateways';
import { Dispatch } from 'redux';
import EarTagListComponent from './EarTagList';
import GatewayListComponent from './GatewayList';


const { TabPane } = Tabs;
interface MonitorProps {
  earTagAndGateway: StateType;
  dispatch: Dispatch<any>;
  loading: boolean;
}

@connect(
  ({
     earTagAndGateway,
     loading,
   }: {
    earTagAndGateway: StateType;
    loading: {
      models: { [key: string]: boolean };
    };
  }) => ({
    earTagAndGateway,
    loading: loading.models.monitor,
  }),
)
class Monitor extends Component<MonitorProps> {
  componentDidMount() {
    // @ts-ignore
    const { dispatch } = this.props;
    dispatch({
      type: 'earTagAndGateway/getEarTagAndGateway',
    });
  }

  render() {
    const { earTagAndGateway, location } = this.props;
    const { earTagList, gatewayList } = earTagAndGateway.earTagAndGateway;
    return (
      <GridContent>
          <Row>
            <Tabs defaultActiveKey={ location.query.k === undefined ? '1' : '2' } tabBarStyle={{ alignItems: 'center' }} >
              <TabPane tab=" 耳标列表 " key="1" forceRender>
                <EarTagListComponent earTagList={earTagList} showParticalCard/>
              </TabPane>
              <TabPane tab=" 网关列表 " key="2" forceRender>
                <GatewayListComponent gatewayList={gatewayList} showParticalCard/>
              </TabPane>
            </Tabs>
          </Row>
      </GridContent>
    );
  }
}

export default Monitor;
