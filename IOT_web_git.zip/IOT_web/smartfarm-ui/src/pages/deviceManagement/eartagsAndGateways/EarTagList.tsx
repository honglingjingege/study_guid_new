import React, { Component } from 'react';
import { Modal, Row, Table } from 'antd';
import PigstyCardComponent from '../pigstyMap/PigstyCard';
import styles from '@/pages/deviceManagement/pigstyMap/style.less';
import PigstyMap from '@/pages/deviceManagement/pigstyMap/PigstyMapComponent';


interface EarTagListComponentProps {
  earTagList: any[]
}

export default class EarTagListComponent extends Component<EarTagListComponentProps> {
  state = {
    earTagList: this.props.earTagList,
    visible: false,
    pigstyList: [],
    dataSource: [],
    columns: [],
    mapedTableData: [],
    location: null,
    gateWayList: null,
    pigstyScale: null,
    pigstyName: '',

  }

  componentWillReceiveProps(nextProps:any) {
    const { earTagList } = nextProps
    const mapedTableData = this.mapTableData(earTagList)
    const pigstyId = this.getPigstyIdList(earTagList)[0] ?
      this.getPigstyIdList(earTagList)[0].pigstyId : 1
    const { dataSource, columns } = this.showTableByPigstyId(mapedTableData, pigstyId)
    this.setState({
      earTagList,
      mapedTableData,
      dataSource,
      columns,
      pigstyList: this.getPigstyIdList(earTagList),
    })
  }

  changeEarTagTable = (params:any) => {
    const { mapedTableData } = this.state
    const { dataSource, columns } = this.showTableByPigstyId(mapedTableData, params)
    this.setState({ pigstyId: params, dataSource, columns })
  }

  getPigstyIdList = (earTagList: []) => {
    const reducePara = {}
    return earTagList.map(item => {
      const obj = {
        pigstyId: item.pigsty_id,
        pigstyName: item.pigstyname ? item.pigstyname : '未分配',
      }
      return obj;
    }).reduce((item, next) => {
      reducePara[next.pigstyId] ? '' : reducePara[next.pigstyId] = true && item.push(next);
      return item;
    }, []).sort((a, b) =>
      // @ts-ignore
      a.pigstyId - b.pigstyId,
    );
  }

  mapTableData = (earTagList: []) => (Array.isArray(earTagList) ?
    earTagList.map((earTagitem, index: number) => {
        const earTag = {
              key: index,
              earTagIndex: earTagitem.earcard,
              warnTagIndex: earTagitem.nodename,
              gatewayLocation: `${earTagitem.point_x},${earTagitem.point_y}`,
              pigstyId: earTagitem.pigsty_id,
              pigstyName: earTagitem.pigstyname,
              nearestCheckTime: earTagitem.updated_at,
              responsePerson: earTagitem.managername,
              gatewayId: earTagitem.gateway_id,
              gatewayName: earTagitem.gateway_name,
              pigstyScale: { x: earTagitem.width, y: earTagitem.high },
        }
        return earTag
      }) : [])

  showTableByPigstyId = (allDataSource: any, pigstyId: number) => {
    const dataSource = allDataSource.filter((item: any) => item.pigstyId === pigstyId);
    const columns = [
      {
        title: '耳号',
        dataIndex: 'earTagIndex',
        key: 'earTagIndex',
      },
      {
        title: '异常耳标编号',
        dataIndex: 'warnTagIndex',
        key: 'warnTagIndex',
      },
      {
        title: '网关位置',
        dataIndex: 'gatewayLocation',
        key: 'gatewayLocation',
        render: (text:any, record:any, index:any) => (
          <span>{Number(text.split(',')[0]) >= 0 && Number(text.split(',')[1]) >= 0 ? (<a onClick={(e) => { this.showGatewayMap(record) }}>{text}</a>) : '暂无' }</span>
        ),
      },
      {
        title: '最近检测时间',
        dataIndex: 'nearestCheckTime',
        key: 'nearestCheckTime',
        render: (time:any) => (<span>{this.utc2beijing(time)}</span>),
      },
      {
        title: '负责人',
        dataIndex: 'responsePerson',
        key: 'responsePerson',
        render: (responsePerson:string) => (<span>{responsePerson || '暂无'}</span>),
      },
    ];
    return { dataSource, columns }
  }

  showGatewayMap = (pigstyIdItem:any) => {
    const location =
      { x: Number(pigstyIdItem.gatewayLocation.split(',')[0]), y: Number(pigstyIdItem.gatewayLocation.split(',')[1]), gatewayId: pigstyIdItem.gatewayId, gatewayName: pigstyIdItem.gatewayName }
    const { earTagList } = this.state
    const gateWayList: any[] = []
    earTagList.forEach((item: any) => {
      if (item.pigsty_id === pigstyIdItem.pigstyId) {
        gateWayList.push({ x: item.point_x, y: item.point_y, gatewayId: item.gateway_id, gatewayName: item.gateway_name })
      }
    })
    this.setState({
      location,
      pigstyScale: pigstyIdItem.pigstyScale,
      gateWayList,
      pigstyName: pigstyIdItem.pigstyName ? pigstyIdItem.pigstyName : '未分配',
      visible: true,
    });
  }

  handleOk = e => {
      this.setState({
        visible: false,
      });
  };

  handleCancel = e => {
    this.setState({
      visible: false,
    });
  };

  utc2beijing = (utDatetime:any) => {
    // 转为正常的时间格式 年-月-日 时:分:秒
    utDatetime = utDatetime.replace(/\.[\d]{3}.*/, 'Z');
    const Tpos = utDatetime.indexOf('T');
    const Zpos = utDatetime.indexOf('Z');
    const yearmonthday = utDatetime.substr(0, Tpos);
    const hourminutesecond = utDatetime.substr(Tpos + 1, Zpos - Tpos - 1);
    const newdatetime = `${yearmonthday} ${hourminutesecond}`; // 2017-03-31 08:02:06

    // 处理成为时间戳
    let timestamp: number = new Date(Date.parse(newdatetime));
    timestamp = timestamp.getTime();
    timestamp /= 1000;

    // 增加8个小时，北京时间比utc时间多八个时区
    timestamp += 8 * 60 * 60;

    // 时间戳转为时间
    const beijingDatetime = new Date(parseInt(timestamp) * 1000).toLocaleString().replace(/年|月/g, '-').replace(/日/g, ' ');
    return beijingDatetime;
  }

  render () {
    // @ts-ignore
    const { dataSource, columns, pigstyList } = this.state;
    return (
      <Row>
        <Row>
          <PigstyCardComponent pigstyList={pigstyList} changePigstyId={this.changeEarTagTable}
                               showParticalCard/>
        </Row>
        <Row className={styles.modular_space}>
          <Table dataSource={dataSource} columns={columns}/>
        </Row>
        <Row>
          <Modal
            bodyStyle={{ height: 400 }}
            width={1000}
            centered
            mask
            visible={this.state.visible}
            onOk={this.handleOk}
            onCancel={this.handleCancel}
            footer={null}
          >
            <Row><span className={styles.pigsty_name_padding}>
                猪舍：{this.state.pigstyName}</span></Row>
            <PigstyMap gateWayList={this.state.gateWayList} pigstyScale={this.state.pigstyScale}
                       enAbleClick={false} location={this.state.location}/>
          </Modal>
        </Row>
      </Row>
    )
  }
}
