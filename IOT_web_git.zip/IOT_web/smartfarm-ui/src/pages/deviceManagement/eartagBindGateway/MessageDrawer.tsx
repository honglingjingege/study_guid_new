import { TreeSelect } from 'antd';
import React, { Component } from 'react';

const { TreeNode } = TreeSelect;

export interface MessageDrawerProp {
  showList: any[];
}

export default class MessageDrawerComponent extends Component<MessageDrawerProp> {
  state = {
    value: undefined,
  };

  onChange = value => {
    console.log(value);
    this.setState({ value });
  };
  onClick = value => {
    console.log(value);
  };

  render() {
    const domList = this.props.showList.map(dom => (
      <TreeNode value={dom} title={dom} key="random" />
    ));
    return (
      <TreeSelect
        showSearch
        style={{ width: 100 }}
        value={this.state.value}
        dropdownStyle={{ maxHeight: 400, overflow: 'auto' }}
        placeholder="Please select"
        allowClear
        treeDefaultExpandAll
        onChange={this.onChange}
        onClick={this.onClick}
      >
        {domList}
      </TreeSelect>
    );
  }
}
