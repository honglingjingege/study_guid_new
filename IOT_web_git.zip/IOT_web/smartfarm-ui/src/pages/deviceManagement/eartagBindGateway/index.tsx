import { Col, Row, Input, Button, Table, Icon } from 'antd';
import React, { Component } from 'react';

import { GridContent } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { StateType } from '@/models/earTagBindGateway';
import { Dispatch } from 'redux';
import MessageDrawerComponent from './MessageDrawer';
import Upload from 'antd/lib/upload';

interface MonitorProps {
  allPiggy: StateType;
  dispatch: Dispatch<any>;
  loading: boolean;
}

@connect(
  ({
     earTagBindGateway,
     loading,
   }: {
    earTagBindGateway: StateType;
    loading: {
      models: { [key: string]: boolean };
    };
  }) => ({
    earTagBindGateway,
    loading: loading.models.monitor,
  }),
)
class Monitor extends Component<MonitorProps> {
  state = {
    id: -1,
    period: -1,
  }

  componentDidMount() {
    // @ts-ignore
    const { dispatch } = this.props;
    dispatch({
      type: 'earTagBindGateway/getPiggyBindGetway',
    });
  }

  search= () => {
    const params = this.state;
    const { dispatch } = this.props;
    dispatch({
      type: 'earTagBindGateway/getPiggyBindGetwayByEarIdOrPeriod',
      payload: params,
    });
  }


  earTagHandleChange= (event: { target: { value: any; }; }) => {
    this.setState({ id: event.target.value });
  }

  periodHandleChange= (event: { target: { value: any; }; }) => {
    this.setState({ period: event.target.value });
  }

  render() {
    console.log(this.props.earTagBindGateway.earTagBindGateway)
    const dataSource = this.props.earTagBindGateway.earTagBindGateway.map((piggy, index) => {
      const obj = {
        key: '',
        earTagIndex: '',
        pigsty: '',
        headerName: '',
        earTags: ['tags1', 'tags2'],
        gateWays: ['gateway1', 'gateway2'],
      }
      obj.key = index + 1;
      obj.earTagIndex = piggy.earcard;
      obj.pigsty = piggy.pigsty_id;
      obj.headerName = piggy.name;
      return obj;
    })
    const columns = [
      {
        title: '猪只耳号',
        dataIndex: 'earTagIndex',
        key: 'earTagIndex',
      },
      {
        title: '猪舍',
        dataIndex: 'pigsty',
        key: 'pigsty',
      },
      {
        title: '负责人',
        dataIndex: 'headerName',
        key: 'headerName',
      },
      {
        title: '耳标',
        dataIndex: 'earTags',
        key: 'earTags',
        render: earTags => (
          <span>
            <MessageDrawerComponent showList={earTags}/>
          </span>
        ),
      },
      {
        title: '网关',
        dataIndex: 'gateWays',
        key: 'gateWays',
        render: gateWays => (
          <span>
            <MessageDrawerComponent showList={gateWays}/>
          </span>
        ),
      },
    ];

    const uploadProps = {
      name: 'file',
      action: 'https://www.mocky.io/v2/5cc8019d300000980a055e76',
      headers: {
        authorization: 'authorization-text',
      },
      onChange(info) {
        if (info.file.status !== 'uploading') {
          console.log(info.file, info.fileList);
        }
        if (info.file.status === 'done') {
          message.success(`${info.file.name} file uploaded successfully`);
        } else if (info.file.status === 'error') {
          message.error(`${info.file.name} file upload failed.`);
        }
      },
    };
    return (
      <GridContent>
        <React.Fragment>
          <Row>
            <Col span={8}>
              猪只耳号: <Input onChange={this.earTagHandleChange} placeholder="猪只耳号" style= {{ width: '150px' }}/>
            </Col>
            <Col span={8}>
              生产周期: <Input onChange={this.periodHandleChange} placeholder="生产周期" style= {{ width: '150px' }}/>
            </Col >
            <Col span={5}>
              <Button onClick={(event) => { this.search() }}>查询</Button>
            </Col>
          </Row>
          <Row>
            <Col span={3}>
              <Icon type="download" />
              <a href="">
                下载模板
              </a>
            </Col>
            <Col span={6}>
              <Col span={2}>
                <Icon type="folder-open" />
              </Col>
                <Upload {...uploadProps}>
                  <a href="">
                    批量导入
                  </a>
                </Upload>
            </Col>
          </Row>
          <Row>
            <Table dataSource={dataSource} columns={columns} />;
          </Row>
        </React.Fragment>
      </GridContent>
    );
  }
}

export default Monitor;
