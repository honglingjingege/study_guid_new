import { Col, Row, Input, Select, DatePicker, Button, Table, Popconfirm, message, Icon, Modal, ConfigProvider } from 'antd';
import React, { Component } from 'react';
import Link from 'umi/link';
import moment from 'moment';
import { GridContent } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { StateType } from '@/models/warnPiggy';
import { MyTags } from '@/components/MyTag';
import { Dispatch } from 'redux';
import styles from './index.less';
import PigstyMap from '@/pages/deviceManagement/pigstyMap/PigstyMapComponent';

const { Option } = Select;
const { RangePicker } = DatePicker;
const { confirm } = Modal;
interface MonitorProps {
  warnPiggy: StateType;
  dispatch: Dispatch<any>;
  loading: boolean;
}

// 以下变量记录选中值
let eartagVal = '';
let periodStatusVal = '';
let startTimeVal = '';
let endTimeVal = '';
let pigstyVal = '';
let selectPageSize = 10;
let current = 1;
// 监听事件
function eartagInputOnchange(e: any) {
  eartagVal = e.target.value;
}
function periodStatusInputOnchange(value: any) {
  periodStatusVal = value;
}
function rangePickerOnchange(dates: any, dateStrings: [string, string]) {
  startTimeVal = dateStrings[0];
  endTimeVal = dateStrings[1];
}

// 修饰温度值字符串
function decorateTemp(text: React.ReactNode, record: { name: React.ReactNode; }) {
  let dom;
  if (!text && text !== 0) {
    dom = (<span>暂无</span>);
  } else if (text > 0) {
    dom = (<span>+{text}℃</span>);
  } else {
    dom = (<span>{text}℃</span>);
  }
  return dom;
}
// 修饰文字
function decorate(text: React.ReactNode, record: { name: React.ReactNode; }) {
  let dom;
  if (!text) {
    dom = (<span>暂无</span>);
  } else {
    dom = (<span>{text}</span>);
  }
  return dom;
}
function disabledDate(current) {
  return current && current > moment().endOf('second');
}

@connect(
  ({
     warnPiggy,
     loading,
   }: {
    warnPiggy: StateType;
    loading: {
      models: { [key: string]: boolean };
    };
  }) => ({
    warnPiggy,
    loading: loading.models.monitor,
  }),
)

class Monitor extends Component<MonitorProps> {
  state = {
    selectedRowKeys: [], // 选中的行id(rowkey)
    visible: false,
    tagsFromServer: [],
    pigstyName: '',
  };

  componentDidMount() {
    this.getWarnPiggyNum();
    this.fetch({
      pageSize: selectPageSize,
      pageNum: current,
    });
  }

  // 弹出还是隐藏对话框
  showConfirm = () => {
    const { selectedRowKeys } = this.state;
    if (!selectedRowKeys || selectedRowKeys.length === 0) {
      message.warning('请至少选中一项！');
      return;
    }
    confirm({
      title: '确认批量排除异常吗?',
      content: '批量排除异常',
      okType: 'danger',
      onOk: () => {
        this.batchUpdate(selectedRowKeys);
      },
    });
  };

  // 子组件-标签选中触发
  refreshParent = (selectElement: object[]) => {
    pigstyVal = selectElement.join();
    this.submit();
  }

  // 提交查询
  submit = () => {
    const param = {
      earcard: eartagVal,
      periodStatus: periodStatusVal,
      alarmStart: startTimeVal,
      alarmEnd: endTimeVal,
    };
    this.getWarnPiggyNum(param);
    current = 1;// 初始化当前页
    param.pageSize = selectPageSize;
    param.pageNum = current;
    param.pigstyId = pigstyVal;
    this.fetch(param);
  }

  // 分页插件变动回调函数
  handleTableChange = (pagination: { current: any; pageSize: any; }) => {
    selectPageSize = pagination.pageSize;
    current = pagination.current;
    this.fetch({
      pageSize: selectPageSize,
      pageNum: current,
      earcard: eartagVal,
      periodStatus: periodStatusVal,
      alarmStart: startTimeVal,
      alarmEnd: endTimeVal,
      pigstyId: pigstyVal,
    });
  };

  // 获取首行疾病猪只数量
  getWarnPiggyNum = (params = {}) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'warnPiggy/getWarnPiggyNum',
      payload: params,
    }).then(() => {
      const { warnPiggy } = this.props;
      const { alarmPiggyCount, pigstyWithAlarmPiggy } = warnPiggy;
      // 猪舍筛选条件
      const tagsFromServer = [];
      let signedPiggyCount = 0;
      if (pigstyWithAlarmPiggy) {
        pigstyWithAlarmPiggy.forEach(pigsty => {
          const count = pigsty.count || 0;
          tagsFromServer.push({ name: `${pigsty.name}(${count})`, id: `${pigsty.id}` });
          signedPiggyCount += count;
        })
      }
      const unsignPiggyCount = alarmPiggyCount - signedPiggyCount;
      tagsFromServer.unshift({ name: `全部(${alarmPiggyCount})`, id: -1 });
      tagsFromServer.push({ name: `未分配(${unsignPiggyCount < 0 ? 0 : unsignPiggyCount})`, id: -2 });
      this.setState({ tagsFromServer });
    });
  }

  // 获取table数据
  fetch = (params = {}) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'warnPiggy/getWarnPiggyData',
      payload: params,
    });
  }

  // 批量排除异常
  batchUpdate = (selectedRowKeys: any) => {
    this.confirm(selectedRowKeys, 0);
    this.setState({ selectedRowKeys: [] });// 清空选中行记录
  }

  // 确诊疾病和非疾病
  confirm = (piggyIds: any[], alarmStatus: number) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'warnPiggy/updateAlarmStatus',
      payload: { piggyIds, alarmStatus },
    }).then(() => {
      const { warnPiggy } = this.props;
      const { diagnoseResult } = warnPiggy;
      if (diagnoseResult) {
        message.success('操作成功！');
      } else {
        message.success('操作失败！');
      }
      this.submit();
    });
  }

  // 展示网关地图
  showGatewayMap = (item:any) => {
      const { dispatch } = this.props;
      let location: { x: any; y: any; gatewayId: any; gatewayName: any; }
      const gatewayList : any[] = []
      const pigstyScale = { x: item.width, y: item.high }
      dispatch({
        type: 'warnPiggy/getGatewayMapData',
        payload: { pigstyId: item.pigstyid },
      }).then(() => {
        const { gatewayMapData } = this.props.warnPiggy
        gatewayMapData.forEach((mapDataItem) => {
          const obj = {
            x: mapDataItem.point_x,
            y: mapDataItem.point_y,
            gatewayId: mapDataItem.gateway_id,
            gatewayName: mapDataItem.gatewayname,
          }
          gatewayList.push(obj)
          if (obj.x === item.point_x && obj.y === item.point_y) {
            location = obj
          }
        })
        this.setState({
          location,
          pigstyScale,
          gatewayList,
          pigstyName: gatewayMapData[0] ? gatewayMapData[0].pigsty_name : '未分配',
          visible: true,
        });
      });
  }

  // 网关地图弹框确定
  handleOk = e => {
    this.setState({
      visible: false,
    });
  };

  // 网关地图弹框取消
  handleCancel = e => {
    this.setState({
      visible: false,
    });
  };

   customizeRenderEmpty = () => (
    <div style={{ textAlign: 'center' }}>
      <Icon type="smile" style={{ fontSize: 20 }} />
      <p>没有符合该条件的数据</p>
    </div>
  );

  render() {
    const { selectedRowKeys, tagsFromServer } = this.state;
    const { warnPiggy } = this.props;
    const { piggyCount, alarmPiggyCount, periodStatusList, sickPiggyPage,
      filterCount, pageSize } = warnPiggy;
    const paginationProp =
      { showSizeChanger: true, showQuickJumper: true, total: filterCount, pageSize, current };
    // 表格多选触发
    const rowSelection = {
      selectedRowKeys,
      onChange: (selectedRowKeysT: any) => {
        this.setState({ selectedRowKeys: selectedRowKeysT });
      },
    };

    // 生产周期筛选条件
    const optionDom = [];
    if (periodStatusList) {
      periodStatusList.forEach(psl => {
        optionDom.push(<Option value={psl.dicCode}>{psl.dicValue}</Option>);
      })
    }

    // 表格标题列
    const columns = [
      {
        title: '猪只耳号',
        dataIndex: 'earcard',
        align: 'center',
        render: (text: any, record: { name: React.ReactNode; }) => decorate(text, record),
      },
      {
        title: '猪舍',
        dataIndex: 'pigstyname',
        align: 'center',
        width: 120,
        render: (text: any, record: { name: React.ReactNode; }) => decorate(text, record),
      },
      {
        title: '网关位置',
        dataIndex: 'coordinate',
        render: (text: any, record: { name: React.ReactNode; }) => <span>{record.point_x != null && record.point_y != null ? (<a onClick={e => { this.showGatewayMap(record) }}>{`${record.point_x},${record.point_y}`}</a>) : '暂无'}</span>,
        align: 'center',
      },
      {
        title: '当前温度',
        dataIndex: 'curr_temp',
        align: 'center',
        render: (text: any, record: { name: React.ReactNode; }) => {
          if (!text && text !== 0) return (<span>暂无</span>);
          return (<span>{text}℃</span>);
        },
      },
      {
        title: '绝对温差',
        dataIndex: 'abs_temp',
        align: 'center',
        render: (text: any, record: { name: React.ReactNode; }) => decorateTemp(text, record),
      },
      {
        title: '同比温差',
        dataIndex: 'dod_temp',
        align: 'center',
        render: (text: any, record: { name: React.ReactNode; }) => decorateTemp(text, record),
      },
      {
        title: '环比温差',
        dataIndex: 'pop_temp',
        align: 'center',
        render: (text: any, record: { name: React.ReactNode; }) => decorateTemp(text, record),
      },
      {
        title: '报警时间',
        dataIndex: 'alarm_at',
        align: 'center',
        width: 110,
        render: (text: any, record: { name: React.ReactNode; }) => decorate(text, record),
      },
      {
        title: '生产阶段',
        dataIndex: 'periodname',
        align: 'center',
        render: (text: any, record: { name: React.ReactNode; }) => decorate(text, record),
      },
      {
        title: '全部',
        dataIndex: 'entire',
        align: 'center',
        render: (text: any, record: { name: React.ReactNode; }) => decorate(text, record),
      },
      {
        title: '负责人',
        dataIndex: 'managername',
        align: 'center',
        render: (text: any, record: { name: React.ReactNode; }) => decorate(text, record),
      },
      {
        title: '操作',
        key: 'action',
        align: 'center',
        width: 65,
        render: (text: any, record: { id: any; }) => (
          <span>
            <div><Popconfirm
              title="确诊疾病?"
              onConfirm={() => this.confirm([record.id], 3)}
            ><a>确诊疾病</a></Popconfirm>
            </div>
            <hr/>
            <div><Popconfirm
              title="非疾病?"
              onConfirm={() => this.confirm([record.id], 0)}
            ><a>非疾病</a></Popconfirm>
            </div>
          </span>
        ),
      },
      {
        title: '详情',
        key: 'detail',
        align: 'center',
        render: (text: any, record: { id: any; earcard: any; pigstyname: any; }) => {
          const piggyId = record.id;
          const earTag = record.earcard;
          const pigsty = record.pigstyname;
          return (
            <span>
              <Link to={`/management/piggy/temperature/curve?piggyId=${piggyId}&earTag=${earTag}&pigsty=${escape(escape(pigsty))}`}>
                <a>详情</a>
              </Link>
            </span>
          )
        },
      },
    ];


    return (
      <GridContent>
        <React.Fragment>
          <Row gutter={24}>
            <Col xl={24} lg={24} md={24} sm={24} xs={24}>
              <div className={styles.alarmPiggyTop}>报警猪只个数&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                <span className={styles.alarmPiggyCount}>{alarmPiggyCount}</span>/{piggyCount}
              </div>
            </Col>
          </Row>
          <Row gutter={24}>
            <table className={styles.queryTableStyle}>
              <tbody>
                <tr>
                  <td className={styles.queryKey}>猪只耳号:</td>
                  <td><Input placeholder="请输入" className={styles.earTagQuery} allowClear onChange={eartagInputOnchange}/></td>&nbsp;&nbsp;
                  <td className={styles.queryKey}>生产周期:</td>
                  <td><Select placeholder="请选择" allowClear className={styles.periodStatusQuery} onChange={periodStatusInputOnchange}>{optionDom}</Select></td>&nbsp;&nbsp;
                  <td className={styles.queryKey}>选择日期:</td>
                  <td><RangePicker className={styles.rangePicker} onChange={rangePickerOnchange}
                    showTime disabledDate={disabledDate}
                    ranges={{
                      今天: [moment().startOf('day'), moment().endOf('day')],
                      本月: [moment().startOf('month'), moment().endOf('month')],
                    }}
                  />
                  </td>
                  <td>&nbsp;&nbsp;&nbsp;&nbsp;<Button type="primary" onClick={this.submit}>查询</Button></td>
                </tr>
              </tbody>
            </table>
          </Row>
          <Row className={styles.pigstySelectRow}>
          <div className={styles.pigstySelectTitle}>猪舍</div>
          <div className={styles.pigstySelectRow}>
            <MyTags tagsFromServer={tagsFromServer} refreshParent={this.refreshParent}
                    style={{ minWidth: '90px', height: '45px', textAlign: 'center', lineHeight: '45px', cursor: 'pointer' }}/>
          </div>
        </Row>
        <Row className={styles.actionRow}>
          <div>
            <Icon type="block" /><a className={styles.batchAction} onClick={this.showConfirm}>批量排除异常</a>
          </div>
        </Row>
        <Row className={styles.tableStyle}>
          <ConfigProvider renderEmpty={this.customizeRenderEmpty}>
            <Table columns={columns} dataSource={sickPiggyPage} rowKey="id"
                   pagination={paginationProp}
                   onChange={this.handleTableChange}
                   rowSelection={rowSelection}
            />
          </ConfigProvider>
        </Row>
        <Row>
          <Modal
            bodyStyle={{ height: 400 }}
            width={1000}
            centered
            mask
            visible={this.state.visible}
            onOk={this.handleOk}
            onCancel={this.handleCancel}
            footer={null}
          >
            <Row><span className={styles.pigsty_name_padding}>
                猪舍：{this.state.pigstyName}</span></Row>
            <PigstyMap gateWayList={this.state.gatewayList} pigstyScale={this.state.pigstyScale}
                       enAbleClick={false} location={this.state.location}/>
          </Modal>
        </Row>
        </React.Fragment>
      </GridContent>
    );
  }
}

export default Monitor;
