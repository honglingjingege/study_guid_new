import { Card, Col, Row, Icon, Tabs, Table } from 'antd';
import React, { Component } from 'react';
import Link from 'umi/link';
import { routerRedux } from 'dva/router';
import { MyPie } from '@/components/MyPie';

import { GridContent } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { StateType } from '@/models/homeModel';
import { Dispatch } from 'redux';
import {
  G2,
  Chart,
  Geom,
  Axis,
  Tooltip,
  Coord,
  Label,
  Legend,
  View,
  Guide,
  Shape,
  Facet,
  Util,
} from 'bizcharts';
import Link from 'react-router-dom';
import styles from './index.less';

const { TabPane } = Tabs;

interface MonitorProps {
  homeModel: StateType;
  dispatch: Dispatch<any>;
  loading: boolean;
}

// 修饰文字
function decorate(text: React.ReactNode, record: { name: React.ReactNode }) {
  let dom;
  if (!text) {
    dom = <span>暂无</span>;
  } else {
    dom = <span>{text}</span>;
  }
  return dom;
}
// 修饰温度值字符串
function decorateTemp(text: React.ReactNode, record: { name: React.ReactNode }) {
  let dom;
  if (!text && text !== 0) {
    dom = <span>暂无</span>;
  } else if (text > 0) {
    dom = (
      <span>
        +{text}℃<Icon type="caret-up" className={styles.redIcon} />
      </span>
    );
  } else {
    dom = <span>{text}℃</span>;
  }
  return dom;
}
// 时间前补“0”
function appendZero(obj: number) {
  if (obj < 10) return `0${obj}`;
  return obj;
}

@connect(
  ({
    homeModel,
    loading,
  }: {
    homeModel: StateType;
    loading: {
      models: { [key: string]: boolean };
    };
  }) => ({
    homeModel,
    loading: loading.models.monitor,
  }),
)
class Monitor extends Component<MonitorProps> {
  private timer: NodeJS.Timeout | undefined;

  private refreshInterval = 1; // 刷新时间间隔（分钟）

  state = {
    orderBy: 'num', // 汇总排行排序
  };

  componentDidMount() {
    this.getData(this.state.orderBy);
    this.timer = setInterval(() => {
      this.getData(this.state.orderBy);
    }, this.refreshInterval * 60000);
  }

  componentWillUnmount() {
    if (this.timer != null) {
      clearInterval(this.timer);
    }
  }

  // 获取数据
  getData = (orderBy: string) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'homeModel/getCardsContent',
      payload: { orderBy },
    });
  };

  // tab切换回调
  callback = (key: any) => {
    this.setState({ orderBy: key });
    const { dispatch } = this.props;
    dispatch({
      type: 'homeModel/getHomeChart',
      payload: { orderBy: key },
    });
  };

  // 柱状图点击
  onPlotClick = (ev: any) => {
    // alert(ev.data.point.psid);
    const { dispatch } = this.props;
    dispatch(routerRedux.push('/data/warnPiggies'));
  };

  render() {
    const { homeModel } = this.props;
    const {
      nodeCount,
      errorNodeCount,
      gatewayCount,
      errorGatewayCount,
      piggyCount,
      alarmPiggyCount,
      envTemp,
      envHumidity,
      pigstyWithAlarmPiggy,
      sickPiggyPage,
      sickPiggyCount,
    } = homeModel;
    // 上次更新时间
    const day = new Date();
    const previousRefreshTime = `${day.getFullYear()}-${appendZero(
      day.getMonth() + 1,
    )}-${appendZero(day.getDate())}
                                ${appendZero(day.getHours())}:${appendZero(day.getMinutes())}`;
    // 列表标题
    const columns = [
      {
        title: '猪只耳号',
        dataIndex: 'earcard',
        align: 'center',
        render: (text: any, record: { name: React.ReactNode }) => decorate(text, record),
      },
      {
        title: '当前温度',
        dataIndex: 'curr_temp',
        sorter: (a: { curr_temp: number }, b: { curr_temp: number }) => a.curr_temp - b.curr_temp,
        align: 'center',
        render: (text: any, record: { name: React.ReactNode }) => {
          let dom;
          if (!text && text !== 0) {
            dom = <span>暂无</span>;
          } else {
            dom = <span>{text}℃</span>;
          }
          return dom;
        },
      },
      {
        title: '绝对温差',
        dataIndex: 'abs_temp',
        align: 'center',
        sorter: (a: { abs_temp: number }, b: { abs_temp: number }) => a.abs_temp - b.abs_temp,
        render: (text: any, record: { name: React.ReactNode }) => decorateTemp(text, record),
      },
      {
        title: '同比温差',
        dataIndex: 'dod_temp',
        align: 'center',
        sorter: (a: { dod_temp: number }, b: { dod_temp: number }) => a.dod_temp - b.dod_temp,
        render: (text: any, record: { name: React.ReactNode }) => decorateTemp(text, record),
      },
      {
        title: '环比温差',
        dataIndex: 'pop_temp',
        align: 'center',
        sorter: (a: { pop_temp: number }, b: { pop_temp: number }) => a.pop_temp - b.pop_temp,
        render: (text: any, record: { name: React.ReactNode }) => decorateTemp(text, record),
      },
      {
        title: '疾病类型',
        dataIndex: 'dic_value',
        align: 'center',
        width: 100,
        render: (text: any, record: { name: React.ReactNode }) => decorate(text, record),
      },
    ];

    const formatter = (text: any, item: any, index: any) => {
      const strs = text.split('');
      let s = '';
      for (let i = 0; i < strs.length; i += 1) {
        s += strs[i];
        if (i % 3 === 0 && i !== 0) {
          s += '\n';
        }
        if (i === 2 * 3) {
          s += '...';
          break;
        }
      }
      return text;
    };

    const label = {
      offset: 10,
      textStyle: {
        textBaseline: 'top', // 文本基准线，可取 top middle bottom，默认为middle
      },
      formatter,
    };
    const labelDown = {
      offset: 40,
      textStyle: {
        textBaseline: 'top', // 文本基准线，可取 top middle bottom，默认为middle
      },
      formatter,
    };

    // 每个饼状图的宽度
    // const attribute = document.getElementById('chartDiv').getAttribute('width');
    // eslint-disable-next-line max-len
    // const width = pigstyWithAlarmPiggy.length * 60
    // (pigstyWithAlarmPiggy && pigstyWithAlarmPiggy.length !== 0) ? 400 / pigstyWithAlarmPiggy.length : 0;
    const dom = [];
    let imageMap = {};
    let width_chart = pigstyWithAlarmPiggy.length * 80;
    if (pigstyWithAlarmPiggy) {
      // eslint-disable-next-line no-restricted-syntax
      // for (const pd,i of pigstyWithAlarmPiggy) {
      //   let name = parseInt(pd.rate*100);
      //   imageUrl[i].name = i;
      //   console.log(imageUrl)

      // }
      for (let i = 0; i < pigstyWithAlarmPiggy.length; i++) {
        let rate = parseInt(pigstyWithAlarmPiggy[i].rate * 100);
        let url = './image_pie/' + rate + '.png';
        let name = pigstyWithAlarmPiggy[i].name;
        imageMap[name] = url;
      }
    }

    return (
      <GridContent>
        <div>
          <Row gutter={24}>
            <Col xl={24} lg={24} md={24} sm={24} xs={24}>
              <div className={styles.freshTime}>
                上次更新时间：{previousRefreshTime} (每 {this.refreshInterval} 分钟更新一次)
              </div>
            </Col>
          </Row>
          <Row gutter={24} className={styles.cardsRow}>
            <Col xl={6} lg={24} md={24} sm={24} xs={24}>
              <Card bordered={false} size="small">
                <Row>
                  <Icon type="gateway" className={styles.cardIcon} />
                  <Col className={styles.textAlignCenter}>
                    <span>异常网关个数</span>
                  </Col>
                </Row>
                <Row>
                  <Col className={styles.cardBigNum}>
                    <Link
                      to="/deviceManagement/eartagsAndGateways?k=2"
                      style={errorGatewayCount ? { color: 'red' } : { color: 'black' }}
                    >
                      <span>{errorGatewayCount || '0'}</span>
                    </Link>
                  </Col>
                </Row>
                <Row>
                  <Col className={styles.cardSum}>网关总数 {gatewayCount || '0'} 个</Col>
                </Row>
              </Card>
            </Col>
            <Col xl={6} lg={24} md={24} sm={24} xs={24}>
              <Card bordered={false} size="small">
                <Row>
                  <Icon type="tags" className={styles.cardIcon} />
                  <Col className={styles.textAlignCenter}>
                    <span>异常耳标个数</span>
                  </Col>
                </Row>
                <Row>
                  <Col className={styles.cardBigNum}>
                    <Link
                      to={{
                        pathname: '/deviceManagement/eartagsAndGateways',
                      }}
                      style={errorNodeCount ? { color: 'red' } : { color: 'black' }}
                    >
                      <span>{errorNodeCount || '0'}</span>
                    </Link>
                  </Col>
                </Row>
                <Row>
                  <Col className={styles.cardSum}>耳标总数 {nodeCount || '0'} 个</Col>
                </Row>
              </Card>
            </Col>
            <Col xl={6} lg={24} md={24} sm={24} xs={24}>
              <Card bordered={false} size="small">
                <Row>
                  <Icon type="warning" className={styles.cardIcon} />
                  <Col className={styles.textAlignCenter}>
                    <span>报警猪只个数</span>
                  </Col>
                </Row>
                <Row>
                  <Col className={styles.cardBigNum}>
                    <Link
                      to={{
                        pathname: '/data/warnPiggies',
                      }}
                      style={alarmPiggyCount ? { color: 'red' } : { color: 'black' }}
                    >
                      <span>{alarmPiggyCount || '0'}</span>
                    </Link>
                  </Col>
                </Row>
                <Row>
                  <Col className={styles.cardSum}>猪只总数{piggyCount || '0'}个</Col>
                </Row>
              </Card>
            </Col>
            <Col xl={6} lg={24} md={24} sm={24} xs={24}>
              <Card bordered={false} size="small">
                <Row>
                  <Icon type="home" className={styles.cardIcon} />
                  <Col className={styles.textAlignCenter}>
                    <span>环境温度&nbsp;&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp;&nbsp;&nbsp;环境湿度</span>
                  </Col>
                </Row>
                <Row>
                  <Col xl={13} className={styles.cardBigNum}>
                    {envTemp || envTemp === 0 ? `${envTemp}℃` : '暂无'}
                  </Col>
                  <Col className={styles.cardBigNum}>
                    {envHumidity || envHumidity === 0 ? `${envHumidity}%` : '暂无'}
                  </Col>
                </Row>
                <Row>
                  <Col className={styles.cardSum}>&nbsp;</Col>
                </Row>
              </Card>
            </Col>
          </Row>
          <Row className={styles.secondRow}>
            <Col xl={11}>
              <span className={styles.alarmPiggyTitle}>猪舍报警猪只汇总排行</span>&nbsp;&nbsp;&nbsp;
              <span className={styles.alarmPiggySeeAll}>
                <Link
                  to={{
                    pathname: '/data/warnPiggies',
                  }}
                >
                  <a>查看全部&gt;</a>
                </Link>
              </span>
              <Tabs
                defaultActiveKey="1"
                onChange={this.callback}
                tabBarGutter={0}
                size="small"
                className={styles.overflow}
              >
                <TabPane tab="按报警数量降序" key="num" className={styles.scroll}>
                  <div className={styles.chartLegend}>
                    <Icon type="bar-chart" />
                    <span className={styles.chartLegendFont}>报警猪只数量</span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <Icon type="pie-chart" />
                    &nbsp;<span className={styles.chartLegendFont}>该猪舍报警猪只占比</span>
                  </div>
                  {/* <table className={styles.pieTable}>
                    <tbody>
                      <tr>
                        { dom }
                      </tr>
                    </tbody>
                  </table> */}
                  <Row>
                    <Col xl={24}>
                      <div>
                        <Chart
                          height={250}
                          data={pigstyWithAlarmPiggy}
                          padding={[40, 'auto', 60, 'auto']}
                          width={width_chart}
                          onPlotClick={this.onPlotClick}
                        >
                          <Axis name="name" label={label} />
                          {/* <Axis name="num" /> */}
                          <Tooltip
                            crosshairs={{
                              type: 'rect',
                            }}
                          />
                          <Geom
                            type="interval"
                            position="name*num"
                            size={30}
                            tooltip={[
                              'name*num',
                              (name, num) => ({
                                name: '报警猪只数量',
                                value: num,
                              }),
                            ]}
                          ></Geom>
                          <Geom
                            type="point"
                            position="name*num"
                            size={30}
                            tooltip={[
                              'name*num*sum*rate',
                              (name, num, sum, rate) => ({
                                name: '报警猪只占比',
                                value: parseInt(rate * 100) + '%',
                              }),
                            ]}
                            shape={[
                              'name',
                              function(name) {
                                return ['image', imageMap[name]];
                              },
                            ]}
                          ></Geom>
                        </Chart>
                      </div>
                    </Col>
                  </Row>
                </TabPane>
                <TabPane tab="按报警占比降序" key="rate" className={styles.scroll}>
                  <div className={styles.chartLegend}>
                    <Icon type="bar-chart" />
                    <span className={styles.chartLegendFont}>报警猪只数量</span>
                    &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <Icon type="pie-chart" />
                    &nbsp;<span className={styles.chartLegendFont}>该猪舍报警猪只占比</span>
                  </div>
                  <Row>
                    <Col xl={24}>
                      <div>
                        <Chart
                          height={250}
                          data={pigstyWithAlarmPiggy}
                          padding={[40, 'auto', 60, 'auto']}
                          width={width_chart}
                          onPlotClick={this.onPlotClick}
                        >
                          <Coord />
                          <Axis name="name" label={label} />
                          <Axis name="num" />
                          <Tooltip
                            crosshairs={{
                              type: 'rect',
                            }}
                          />
                          <Geom
                            type="interval"
                            position="name*num"
                            size={30}
                            tooltip={[
                              'name*num',
                              (name, num) => ({
                                name: '报警猪只数量',
                                value: num,
                              }),
                            ]}
                          >
                            {/* <Label content="num" offset={-10}
                              textStyle={{
                                fill: '#404040', // 文本的颜色
                              }}
                            ></Label> */}
                          </Geom>
                          <Geom
                            type="point"
                            position="name*num"
                            size={30}
                            tooltip={[
                              'name*num*sum*rate',
                              (name, num, sum, rate) => ({
                                name: '报警猪只占比',
                                value: parseInt(rate * 100) + '%',
                              }),
                            ]}
                            shape={[
                              'name',
                              function(name) {
                                return ['image', imageMap[name]];
                              },
                            ]}
                          ></Geom>
                        </Chart>
                      </div>
                    </Col>
                  </Row>
                </TabPane>
              </Tabs>
            </Col>
            <Col xl={1}></Col>
            <Col xl={12} className={styles.right_table}>
              <span className={styles.manageSickPiggy}>疾病猪只管理</span>&nbsp;&nbsp;&nbsp;
              <span className={styles.allSickPiggy}>
                <Link
                  to={{
                    pathname: '/management/piggy/disease',
                  }}
                >
                  <a>全部疾病猪只({sickPiggyCount}) &gt;</a>
                </Link>
              </span>
              <Table
                rowKey="id"
                columns={columns}
                dataSource={sickPiggyPage}
                className={styles.sickPiggyTable}
                size="middle"
                // scroll={{ y: 450 }}
                pagination={false}
              />
            </Col>
          </Row>
        </div>
      </GridContent>
    );
  }
}

export default Monitor;
