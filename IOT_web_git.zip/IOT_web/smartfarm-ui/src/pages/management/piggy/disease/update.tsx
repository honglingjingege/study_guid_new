import { Button, Icon, Input, message, Row, Table, Form, Select } from 'antd';
import React, { Component } from 'react';

import { GridContent } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { StateType } from '@/models/diseasePiggy';
import { Dispatch } from 'redux';
import { routerRedux } from 'dva/router';
import styles from './update.less';

const { Option } = Select;

interface MonitorProps {
  diseasePiggy: StateType;
  dispatch: Dispatch<any>;
  loading: boolean;
}

@connect(
  ({
     diseasePiggy,
     loading,
   }: {
    diseasePiggy: StateType;
    loading: {
      models: { [key: string]: boolean };
    };
  }) => ({
    diseasePiggy,
    loading: loading.models.monitor,
  }),
)
class Monitor extends Component<MonitorProps> {
  componentDidMount() {
    this.getUpdateCondition();
    const { piggyId } = this.props.location.state;
    if (piggyId) {
      this.getPiggyInfo(piggyId);
    }
  }

  // 获取查询条件常量
  getUpdateCondition = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'diseasePiggy/getUpdateCondition',
    });
  }

  getPiggyInfo = (piggyId: string) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'diseasePiggy/getPiggyInfo',
      payload: { piggyId },
    });
  }

  handleSubmit = (e: any) => {
    e.preventDefault();
    this.props.form.validateFieldsAndScroll((err: any, values: any) => {
      if (err) { return; }
      const { dispatch } = this.props;
      dispatch({
        type: 'diseasePiggy/savePiggy',
        payload: { ...values },
      }).then(() => {
        const { diseasePiggy } = this.props;
        const { savePiggyResult } = diseasePiggy;
        if (savePiggyResult) {
          message.success('保存成功！');
          this.props.dispatch(routerRedux.push({
            pathname: '/management/piggy/disease',
          }))
        } else {
          message.success('保存失败！');
        }
      });
    });
  };

  goBack = () => {
    window.history.back()
  }

  render() {
    const { diseasePiggy, location, form } = this.props;
    const { periodStatusList, nodeList, pigstyList, entireList, piggyInfo } = diseasePiggy;

    const defaultId = location.state.piggyId ? piggyInfo.id : null;
    const defaultNodeId = location.state.piggyId ? piggyInfo.nodeId : null;
    const defaultPeriodStatus = location.state.piggyId ? piggyInfo.periodStatus : null;
    const defaultPigstyId = location.state.piggyId ? piggyInfo.pigstyId : null;
    const defaultEntire = location.state.piggyId ? piggyInfo.entire : null;

    const { getFieldDecorator } = form;
    const formItemLayout = { labelCol: { sm: { span: 8 } }, wrapperCol: { sm: { span: 8 } } };

    // 秒秒测序列号
    const mmcDom = [];
    if (nodeList) {
      nodeList.forEach(psl => {
        mmcDom.push(<Option value={psl.id}>{psl.sn}</Option>);
      })
    }
    // 猪只周期状态
    const periodDom = [];
    if (periodStatusList) {
      periodStatusList.forEach(psl => {
        periodDom.push(<Option value={psl.dicCode}>{psl.dicValue}</Option>);
      })
    }
    // 猪舍
    const pigstyDom = [];
    if (pigstyList) {
      pigstyList.forEach(psl => {
        pigstyDom.push(<Option value={psl.id}>{psl.name}</Option>);
      })
    }
    // 全部
    const entireDom = [];
    if (entireList) {
      entireList.forEach(psl => {
        entireDom.push(<Option value={psl.dicCode}>{psl.dicValue}</Option>);
      })
    }

    return (
      <GridContent>
        <React.Fragment>
          <Form {...formItemLayout} onSubmit={this.handleSubmit}>
            <Form.Item label="秒秒测序列号">
              {getFieldDecorator('nodeId', {
                initialValue: defaultNodeId,
                rules: [
                  {
                    required: true,
                    message: '请输入秒秒测序列号！',
                  },
                ],
              })(<Select
                showSearch
                placeholder="搜索序列号"
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                }
              >{mmcDom}</Select>)}
            </Form.Item>
            <Form.Item label="猪只周期状态">
              {getFieldDecorator('periodStatus', {
                initialValue: defaultPeriodStatus,
              })(<Select allowClear>{periodDom}</Select>)}
            </Form.Item>
            <Form.Item label="猪舍">
              {getFieldDecorator('pigstyId', {
                initialValue: defaultPigstyId,
                rules: [
                  {
                    required: true,
                    message: '请选择猪只所在猪舍!',
                  },
                ],
              })(<Select
                showSearch
                optionFilterProp="children"
                filterOption={(input, option) =>
                  option.props.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                }
              >{pigstyDom}</Select>)}
            </Form.Item>
            <Form.Item label="全部">
              {getFieldDecorator('entire', {
                initialValue: defaultEntire,
              })(<Select allowClear>{entireDom}</Select>)}
            </Form.Item>
            <Form.Item label="唯一标识" className={styles.hideId}>
              {getFieldDecorator('id', {
                initialValue: defaultId,
              })(<Input type="hidden" name="id"/>)}
            </Form.Item>
            <Form.Item wrapperCol={{ span: 12, offset: 10 }}>
              <Button type="primary" htmlType="submit">
                保存
              </Button>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
              <Button type="default" onClick={this.goBack}>
                取消
              </Button>
            </Form.Item>
          </Form>
        </React.Fragment>
      </GridContent>
    );
  }
}

export default Form.create({ name: 'updatePiggy' })(Monitor);
