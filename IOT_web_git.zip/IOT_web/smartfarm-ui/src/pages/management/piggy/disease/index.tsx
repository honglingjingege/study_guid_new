import {Button, Col, Icon, Input, message, Modal, Popconfirm, Row, Table} from 'antd';
import React, { Component } from 'react';

import { GridContent } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { StateType } from '@/models/diseasePiggy';
import { Dispatch } from 'redux';
import styles from './index.less';
import { SingleCheckTag } from '@/components/SingleCheckTag';
import Link from 'umi/link';
import { routerRedux } from 'dva/router';
import PigstyMap from '@/pages/deviceManagement/pigstyMap/PigstyMapComponent';

interface MonitorProps {
  diseasePiggy: StateType;
  dispatch: Dispatch<any>;
  loading: boolean;
}
// 以下变量记录选中值
let eartagVal = '';
let periodStatusVal: number | null = null;
let selectPageSize = 10;
let current = 1;

// 监听事件
function eartagInputOnchange(e: any) {
  eartagVal = e.target.value;
}
// 修饰文字
function decorate(text: React.ReactNode, record: { name: React.ReactNode; }) {
  let dom;
  if (!text) {
    dom = (<span>暂无</span>);
  } else {
    dom = (<span>{text}</span>);
  }
  return dom;
}
// 修饰温度值字符串
function decorateTemp(text: React.ReactNode, record: { name: React.ReactNode; }) {
  let dom;
  if (!text && text !== 0) {
    dom = (<span>暂无</span>);
  } else if (text > 0) {
    dom = (<span>+{text}℃<Icon type="caret-up" className={styles.redIcon}/></span>);
  } else {
    dom = (<span>{text}℃</span>);
  }
  return dom;
}

@connect(
  ({
     diseasePiggy,
     loading,
   }: {
    diseasePiggy: StateType;
    loading: {
      models: { [key: string]: boolean };
    };
  }) => ({
    diseasePiggy,
    loading: loading.models.monitor,
  }),
)
class Monitor extends Component<MonitorProps> {
  state = {
    selectedRowKeys: [], // 选中的行id(rowkey)
    visible: false,
    pigstyName: '',
  };

  componentDidMount() {
    this.getQueryCondition();
    this.fetch({
      pageSize: selectPageSize,
      pageNum: current,
    });
  }

  // 获取查询条件常量
  getQueryCondition = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'diseasePiggy/getQueryCondition',
    });
  }

  // 分页插件变动回调函数
  handleTableChange = (pagination: { current: any; pageSize: any; },
                       filters: any, sorter: any, extra: { currentDataSource: [] }) => {
    selectPageSize = pagination.pageSize;
    current = pagination.current;
    this.fetch({
      pageSize: selectPageSize,
      pageNum: current,
      earcard: eartagVal,
      periodStatus: periodStatusVal,
      orderby: sorter.columnKey,
      sortDirection: sorter.order,
    });
  };

  // 时间切换
  refreshParent = (selectElement: number) => {
    periodStatusVal = selectElement;
    this.submit();
  }

  // 确认删除
  confirm = (piggyIds: string) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'diseasePiggy/deletePiggy',
      payload: { piggyIds },
    }).then(() => {
      const { diseasePiggy } = this.props;
      const { deleteResult } = diseasePiggy;
      if (deleteResult) {
        message.success('删除成功！');
      } else {
        message.success('删除失败！');
      }
      this.submit();
    });
  }

  // 提交查询
  submit = () => {
    current = 1;
    this.fetch({
      pageSize: selectPageSize,
      pageNum: current,
      earcard: eartagVal,
      periodStatus: periodStatusVal,
    });
  }

  // 获取table数据
  fetch = (params = {}) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'diseasePiggy/getDiseasePiggyData',
      payload: params,
    });
  }

  jumpToUpdate = () => {
    const { selectedRowKeys } = this.state;
    if (selectedRowKeys.length !== 1) {
      message.warning('请选中一项进行编辑！');
      return;
    }
    this.props.dispatch(routerRedux.push({
      pathname: '/management/piggy/disease/update',
      state: {
        piggyId: selectedRowKeys.join(),
      },
    }))
  }

  // 网关地图弹框确定
  handleOk = e => {
    this.setState({
      visible: false,
    });
  };

  // 网关地图弹框取消
  handleCancel = e => {
    this.setState({
      visible: false,
    });
  };

  // 展示网关地图
  showGatewayMap = (item:any) => {
    const { dispatch } = this.props;
    let location: { x: any; y: any; gatewayId: any; gatewayName: any; }
    const gatewayList : any[] = []
    const pigstyScale = { x: item.width, y: item.high }
    dispatch({
      type: 'diseasePiggy/getGatewayMapData',
      payload: { pigstyId: item.pigstyid },
    }).then(() => {
      const { gatewayMapData } = this.props.diseasePiggy
      gatewayMapData.forEach((mapDataItem) => {
        const obj = {
          x: mapDataItem.point_x,
          y: mapDataItem.point_y,
          gatewayId: mapDataItem.gateway_id,
          gatewayName: mapDataItem.gatewayname,
        }
        gatewayList.push(obj)
        if (obj.x === item.point_x && obj.y === item.point_y) {
          location = obj
        }
      })
      this.setState({
        location,
        pigstyScale,
        gatewayList,
        pigstyName: gatewayMapData[0] ? gatewayMapData[0].pigsty_name : '未分配',
        visible: true,
      });
    });
  }

  render() {
    const { diseasePiggy } = this.props;
    const { periodStatusList, diseasePiggyPage, filterCount, pageSize } = diseasePiggy;
    const paginationProp =
      { showSizeChanger: true, showQuickJumper: true, total: filterCount, pageSize, current };

    // 生产周期筛选条件
    const tagsFromServer = [];
    if (periodStatusList) {
      tagsFromServer.push({ name: '全部', id: -1 });
      periodStatusList.forEach(psl => {
        tagsFromServer.push({ name: psl.dicValue, id: psl.dicCode });
      })
    }

    // 表格标题列
    const columns = [
      {
        title: '猪只耳号',
        dataIndex: 'earcard',
        align: 'center',
        render: (text: any, record: { name: React.ReactNode; }) => decorate(text, record),
      },
      {
        title: '猪舍',
        dataIndex: 'pigstyname',
        align: 'center',
        render: (text: any, record: { name: React.ReactNode; }) => decorate(text, record),
      },
      {
        title: '网关位置',
        dataIndex: 'point_x',
        align: 'center',
        render: (text: any, record: { point_x: any; point_y: any; }) => <span>{record.point_x != null && record.point_y != null ? (<a onClick={e => { this.showGatewayMap(record) }}>{`${record.point_x},${record.point_y}`}</a>) : '暂无'}</span>,
      },
      {
        title: '当前温度',
        dataIndex: 'curr_temp',
        align: 'center',
        key: 'curr_temp',
        sorter: (a: any, b: any) => {},
        render: (text: any, record: { name: React.ReactNode; }) => {
          if (!text && text !== 0) return (<span>暂无</span>);
          return (<span>{text}℃</span>);
        },
      },
      {
        title: '绝对温差',
        dataIndex: 'abs_temp',
        align: 'center',
        key: 'abs_temp',
        sorter: (a: any, b: any) => {},
        render: (text: any, record: { name: React.ReactNode; }) => decorateTemp(text, record),
      },
      {
        title: '同比温差',
        dataIndex: 'dod_temp',
        align: 'center',
        key: 'dod_temp',
        sorter: (a: any, b: any) => {},
        render: (text: any, record: { name: React.ReactNode; }) => decorateTemp(text, record),
      },
      {
        title: '环比温差',
        dataIndex: 'pop_temp',
        align: 'center',
        key: 'pop_temp',
        sorter: (a: any, b: any) => {},
        render: (text: any, record: { name: React.ReactNode; }) => decorateTemp(text, record),
      },
      {
        title: '所处周期',
        dataIndex: 'periodname',
        align: 'center',
        render: (text: any, record: { name: React.ReactNode; }) => decorate(text, record),
      },
      {
        title: '疾病类型',
        dataIndex: 'diseasename',
        width: 160,
        align: 'center',
        render: (text: any, record: { name: React.ReactNode; }) => decorate(text, record),
      },
      {
        title: '操作',
        key: 'action',
        align: 'center',
        render: (text: any, record: { piggy_id: string; }) => (
          <span>
            <div>
              <Popconfirm
                title="确认删除?"
                onConfirm={() => this.confirm(record.piggy_id)}>
              <a>删除</a></Popconfirm>
            </div>
          </span>
        ),
      },
      {
        title: '详情',
        key: 'detail',
        render: (text: any, record: { piggy_id: any; earcard: any; pigstyname: any; }) => {
          const piggyId = record.piggy_id;
          const earTag = record.earcard;
          const pigsty = record.pigstyname;
          return (
            <span>
              <Link to={`/management/piggy/temperature/curve?piggyId=${piggyId}&earTag=${earTag}&pigsty=${escape(escape(pigsty))}`}>
                <a>详情</a>
              </Link>
            </span>
          )
        },
        align: 'center',
      },
    ];

    const { selectedRowKeys } = this.state;
    // 表格多选触发
    const rowSelection = {
      selectedRowKeys,
      onChange: (selectedRowKeysT: any) => {
        this.setState({ selectedRowKeys: selectedRowKeysT });
      },
    };

    return (
      <GridContent>
        <React.Fragment>
          <Row gutter={24}>
            <Col xl={24} lg={24} md={24} sm={24} xs={24} style={{ marginBottom: 24 }}>
              猪只耳号：&nbsp;&nbsp;
              <Input placeholder="输入猪只耳号查询对应猪只" className={styles.earTagQuery} allowClear onChange={eartagInputOnchange}/>&nbsp;&nbsp;
              <Button type="primary" onClick={this.submit}>查询</Button>
            </Col>
          </Row>
          <Row gutter={24}>
            <Col xl={24} lg={24} md={24} sm={24} xs={24} style={{ marginBottom: 24 }}>
              <div className={styles.periodTitle}>生产阶段：</div>
              <div className={styles.period}>
                <SingleCheckTag refreshParent={this.refreshParent} tagsFromServer={tagsFromServer}
                style={{ height: '30px', textAlign: 'center', lineHeight: '25px', fontSize: '14px', cursor: 'pointer' }}/>
              </div>
            </Col>
          </Row>
          <Row>
            <div>
              <Icon type="plus" />
              <Link to={{ pathname: '/management/piggy/disease/update', state: {} }}>
                <a>新增猪只</a>
              </Link>
              &nbsp;&nbsp;&nbsp;&nbsp;
              <Icon type="form" /><a onClick={this.jumpToUpdate}>编辑</a>
            </div>
          </Row>
          <Row className={styles.tableRow}>
            <Table columns={columns} rowKey="piggy_id" pagination={paginationProp} onChange={this.handleTableChange}
                   dataSource={diseasePiggyPage} rowSelection={rowSelection}/>
          </Row>
          <Row>
            <Modal
              bodyStyle={{ height: 400 }}
              width={1000}
              centered
              mask
              visible={this.state.visible}
              onOk={this.handleOk}
              onCancel={this.handleCancel}
              footer={null}
            >
              <Row><span className={styles.pigsty_name_padding}>
                猪舍：{this.state.pigstyName}</span></Row>
              <PigstyMap gateWayList={this.state.gatewayList} pigstyScale={this.state.pigstyScale}
                         enAbleClick={false} location={this.state.location}/>
            </Modal>
          </Row>
        </React.Fragment>
      </GridContent>
    );
  }
}

export default Monitor;
