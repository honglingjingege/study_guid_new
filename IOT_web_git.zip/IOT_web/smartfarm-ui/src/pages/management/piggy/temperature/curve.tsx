import { Col, Row, Button, Empty } from 'antd';
import React, { Component } from 'react';

import { GridContent } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { StateType } from '@/models/tempCurve';
import { SingleCheckTag } from '@/components/SingleCheckTag';
import { Dispatch } from 'redux';
import styles from '@/pages/management/piggy/temperature/curve.less';

import {
  Chart,
  Geom,
  Axis,
  Tooltip,
  Guide,
} from 'bizcharts';
import DataSet from '@antv/data-set';
import Slider from 'bizcharts-plugin-slider';

interface MonitorProps {
  curve: StateType;
  dispatch: Dispatch<any>;
  loading: boolean;
}

function getComponent(data: any[]) {
  let start;
  let end;
  if (data && data.length > 0) {
    start = data[data.length - 1].t;
    end = data[0].t;
  }
  const { RegionFilter } = Guide;
  const ds = new DataSet({
    state: {
      start: new Date(start).getTime(),
      end: new Date(end).getTime(),
    },
  });

  const dv = ds.createView().source(data);
  dv.transform({
    type: 'filter',

    callback(obj: any) {
      const time = new Date(obj.t).getTime(); // !注意：时间格式，建议转换为时间戳进行比较
      return time >= ds.state.start && time <= ds.state.end;
    },
  });
  function format(value: any) {
    return `${value}℃`;
  }
  const scale = {
    t: {
      type: 'time',
      mask: 'YYYY-MM-DD HH:mm',
      alias: '时间',
      nice: false,
    },
    mmcTemp: {
      type: 'linear',
      formatter: format,
      alias: '温度',
    },
  };

  class SliderChart extends React.Component {
    onChange = (obj: any) => {
      const { startValue, endValue } = obj;
      ds.setState('start', startValue);
      ds.setState('end', endValue);
    }

    render() {
      const grid = {
        type: 'line', // 网格的类型
        lineStyle: {
          lineWidth: 1, // 网格线的宽度复制代码
          lineDash: [10, 10], // 网格线的虚线配置，第一个参数描述虚线的实部占多少像素，第二个参数描述虚线的虚部占多少像素
        },
      }
      const html = (
        <div>
          <div className={styles.card}>
            <span className={styles.titleBlock}/>&nbsp;&nbsp;
            <span className={styles.title}>特殊时期汇总</span>&nbsp;&nbsp;&nbsp;&nbsp;
            <span className={styles.normalAlarm}/>
            <span className={styles.legend}>普通预警</span>
            <span className={styles.seriousAlarm}/>
            <span className={styles.legend}>严重预警</span>
            <span className={styles.dangerAlarm}/>
            <span className={styles.legend}>危险预警</span>
            <span className={styles.normalLine}/>
            <span className={styles.legend}>猪只日均温度</span>
          </div>
          <Chart
            height={window.innerHeight - 330}
            data={dv}
            scale={scale}
            forceFit
            padding={[20, 40, 40, 60]}
          >
            <Tooltip />
            <Axis name="mmcTemp" grid={grid}/>
            <Geom type="line" color="#fff" position="t*mmcTemp" shape="smooth"/>
            <Guide>
              <RegionFilter
                start={['min', -100]}
                end={['max', 24]}
                color="#FF5B31" // 危险预警
              />
              <RegionFilter
                start={['min', 24]}
                end={['max', 25]}
                color="#FF9D26" // 严重预警
              />
              <RegionFilter
                start={['min', 25]}
                end={['max', 26]}
                color="#FFE34F" // 普通预警
              />
              <RegionFilter
                start={['min', 26]}
                end={['max', 27]}
                color="#CCCCCC" // 正常
              />
              <RegionFilter
                start={['min', 27]}
                end={['max', 28]}
                color="#FFE34F" // 普通预警
              />
              <RegionFilter
                start={['min', 28]}
                end={['max', 29]}
                color="#FF9D26" // 严重预警
              />
              <RegionFilter
                start={['min', 29]}
                end={['max', 100]}
                color="#FF5B31" // 危险预警
              />
            </Guide>
          </Chart>
          <div>
            <Slider
              width="auto"
              height={30}
              padding={[0, 120, 0, 120]}
              xAxis="t"
              yAxis="mmcTemp"
              scales={{
                t: {
                  type: 'time',
                  mask: 'YYYY-MM-DD HH:mm',
                },
              }}
              data={data}
              backgroundChart={{
                type: 'line',
              }}
              onChange={this.onChange}
            />
          </div>
        </div>);

      return (
        <div>
          {(data && data.length > 0) ? html :
            (<Row><Empty image={null}
                         description={<span className={styles.noData_tips_style}>该范围暂无温度信息！</span>}/></Row>)}
        </div>
      );
    }
  }
  return SliderChart;
}

let piggyIdSave = '';
let earTagSave = '';
let pigstySave = '';

@connect(
  ({
     tempCurve,
     loading,
   }: {
    tempCurve: StateType;
    loading: {
      models: { [key: string]: boolean };
    };
  }) => ({
    tempCurve,
    loading: loading.models.monitor,
  }),
)

class Monitor extends Component<MonitorProps> {
  componentDidMount() {
    const { location } = this.props;
    const { query } = location;
    piggyIdSave = query.piggyId;
    earTagSave = query.earTag;
    pigstySave = unescape(query.pigsty);
    this.fetch({
      timeId: -1,
      piggyId: piggyIdSave,
    });
  }

  // 回退
  goBack = () => {
    window.history.go(-1);
  }

  // 时间切换
  refreshParent = (selectElement: number) => {
    this.fetch({
      timeId: selectElement,
      piggyId: piggyIdSave,
    });
  }

  // 获取table数据
  fetch = (params = {}) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'tempCurve/fetchTempData',
      payload: params,
    });
  }

  render() {
    const { tempCurve } = this.props;
    const { tempData } = tempCurve;
    const SliderChart = getComponent(tempData);
    const tagsFromServer = [
      { name: '今日', id: -1 },
      { name: '本周', id: 0 },
      { name: '本月', id: 1 },
    ];
    return (
      <GridContent>
        <React.Fragment>
          <Row gutter={24}>
            <Col xl={6} className={styles.goBack}>
              <Button size="small" type="link" icon="left" onClick={this.goBack}>返回</Button>
            </Col>
            <Col xl={12}>
              <div className={styles.nowPiggyInfo}>
                猪只: <span className={styles.numBold}>{earTagSave || '暂无'}</span>&nbsp;&nbsp;&nbsp;
                猪舍: <span className={styles.numBold}>{pigstySave || '暂无'}</span>&nbsp;&nbsp;&nbsp;
              </div>
            </Col>
            <Col xl={6}></Col>
          </Row>
          <Row gutter={24}>
            <div className={styles.timePeriod}>
              <SingleCheckTag refreshParent={this.refreshParent} tagsFromServer={tagsFromServer}
                              style={{ width: '50px', height: '25px', textAlign: 'center', lineHeight: '25px', fontSize: '14px', cursor: 'pointer' }}/>
            </div>
          </Row>
          <Row gutter={24}>
            <div className={styles.chart}>
              <SliderChart/>
            </div>
          </Row>
        </React.Fragment>
      </GridContent>
    );
  }
}

export default Monitor;
