import { Row, Input, Select, DatePicker, Button, Table, Icon, Modal } from 'antd';
import React, { Component } from 'react';
import Link from 'umi/link';
import moment from 'moment';
import { GridContent } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { StateType } from '@/models/allPiggy';
import { Dispatch } from 'redux';
import styles from './index.less';
import PigstyMap from '@/pages/deviceManagement/pigstyMap/PigstyMapComponent';

const { Option } = Select;
const { RangePicker } = DatePicker;
interface MonitorProps {
  allPiggy: StateType;
  dispatch: Dispatch<any>;
  loading: boolean;
}

// 以下变量记录选中值
let eartagVal = '';
let periodStatusVal = '';
let startTimeVal = '';
let endTimeVal = '';
let selectPageSize = 10;
let current = 1;
// 监听事件
function eartagInputOnchange(e: any) {
  eartagVal = e.target.value;
}
function periodStatusInputOnchange(value: any) {
  periodStatusVal = value;
}
function rangePickerOnchange(dates: any, dateStrings: [string, string]) {
  startTimeVal = dateStrings[0];
  endTimeVal = dateStrings[1];
}
function disabledDate(current) {
  return current && current > moment().endOf('second');
}

// 修饰温度值字符串
function decorateTemp(text: React.ReactNode, record: { name: React.ReactNode; }) {
  let dom;
  if (!text && text !== 0) {
    dom = (<span>暂无</span>);
  } else if (text > 0) {
    dom = (<span>+{text}℃<Icon type="caret-up" className={styles.redIcon}/></span>);
  } else {
    dom = (<span>{text}℃</span>);
  }
  return dom;
}

// 修饰文字
function decorate(text: React.ReactNode, record: { name: React.ReactNode; }) {
  let dom;
  if (!text) {
    dom = (<span>暂无</span>);
  } else {
    dom = (<span>{text}</span>);
  }
  return dom;
}


@connect(
  ({
     allPiggy,
     loading,
   }: {
    allPiggy: StateType;
    loading: {
      models: { [key: string]: boolean };
    };
  }) => ({
    allPiggy,
    loading: loading.models.monitor,
  }),
)

class Monitor extends Component<MonitorProps> {
  state = {
    visible: false,
    pigstyName: '',
  };

  componentDidMount() {
    this.getQueryCondition();
    this.fetch({
      pageSize: selectPageSize,
      pageNum: current,
    });
  }

  // 获取首行疾病猪只数量
  getQueryCondition = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'allPiggy/getQueryCondition',
    });
  }

  // 提交查询
  submit = () => {
    current = 1;
    this.fetch({
      pageSize: selectPageSize,
      pageNum: current,
      earcard: eartagVal,
      periodStatus: periodStatusVal,
      alarmStart: startTimeVal,
      alarmEnd: endTimeVal,
    });
  }

  // 分页插件变动回调函数
  handleTableChange = (pagination: { current: any; pageSize: any; },
                       filters: any, sorter: any, extra: { currentDataSource: [] }) => {
    selectPageSize = pagination.pageSize;
    current = pagination.current;
    this.fetch({
      pageSize: selectPageSize,
      pageNum: current,
      earcard: eartagVal,
      periodStatus: periodStatusVal,
      alarmStart: startTimeVal,
      alarmEnd: endTimeVal,
      orderby: sorter.columnKey,
      sortDirection: sorter.order,
    });
  };

  // 获取table数据
  fetch = (params = {}) => {
    const { dispatch } = this.props;
    dispatch({
      type: 'allPiggy/getAllPiggyData',
      payload: params,
    });
  }

  // 网关地图弹框确定
  handleOk = e => {
    this.setState({
      visible: false,
    });
  };

  // 网关地图弹框取消
  handleCancel = e => {
    this.setState({
      visible: false,
    });
  };

  // 展示网关地图
  showGatewayMap = (item:any) => {
    const { dispatch } = this.props;
    let location: { x: any; y: any; gatewayId: any; gatewayName: any; }
    const gatewayList : any[] = []
    const pigstyScale = { x: item.width, y: item.high }
    dispatch({
      type: 'allPiggy/getGatewayMapData',
      payload: { pigstyId: item.pigstyid },
    }).then(() => {
      const { gatewayMapData } = this.props.allPiggy
      gatewayMapData.forEach((mapDataItem) => {
        const obj = {
          x: mapDataItem.point_x,
          y: mapDataItem.point_y,
          gatewayId: mapDataItem.gateway_id,
          gatewayName: mapDataItem.gatewayname,
        }
        gatewayList.push(obj)
        if (obj.x === item.point_x && obj.y === item.point_y) {
          location = obj
        }
      })
      this.setState({
        location,
        pigstyScale,
        gatewayList,
        pigstyName: gatewayMapData[0] ? gatewayMapData[0].pigsty_name : '未分配',
        visible: true,
      });
    });
  }

  render() {
    const { allPiggy } = this.props;
    const { periodStatusList, sickPiggyPage, filterCount, pageSize } = allPiggy;
    const paginationProp =
      { showSizeChanger: true, showQuickJumper: true, total: filterCount, pageSize, current };

    // 生产周期筛选条件
    const optionDom = [];
    if (periodStatusList) {
      periodStatusList.forEach(psl => {
        optionDom.push(<Option value={psl.dicCode}>{psl.dicValue}</Option>);
      })
    }

    // 表格标题列
    const columns = [
      {
        title: '猪只耳号',
        dataIndex: 'earcard',
        align: 'center',
        render: (text: any, record: { name: React.ReactNode; }) => decorate(text, record),
      },
      {
        title: '猪舍',
        dataIndex: 'pigstyname',
        align: 'center',
        render: (text: any, record: { name: React.ReactNode; }) => decorate(text, record),
      },
      {
        title: '网关位置',
        dataIndex: 'point_x',
        align: 'center',
        render: (text: any, record: { point_x: any; point_y: any; }) => <span>{record.point_x != null && record.point_y != null ? (<a onClick={e => { this.showGatewayMap(record) }}>{`${record.point_x},${record.point_y}`}</a>) : '暂无'}</span>,
      },
      {
        title: '当前温度',
        dataIndex: 'curr_temp',
        align: 'center',
        key: 'curr_temp',
        sorter: (a: any, b: any) => {},
        render: (text: any, record: { name: React.ReactNode; }) => {
          if (!text && text !== 0) return (<span>暂无</span>);
          return (<span>{text}℃</span>);
        },
      },
      {
        title: '绝对温差',
        dataIndex: 'abs_temp',
        align: 'center',
        key: 'abs_temp',
        sorter: (a: any, b: any) => {},
        render: (text: any, record: { name: React.ReactNode; }) => decorateTemp(text, record),
      },
      {
        title: '同比温差',
        dataIndex: 'dod_temp',
        align: 'center',
        key: 'dod_temp',
        sorter: (a: any, b: any) => {},
        render: (text: any, record: { name: React.ReactNode; }) => decorateTemp(text, record),
      },
      {
        title: '环比温差',
        dataIndex: 'pop_temp',
        align: 'center',
        key: 'pop_temp',
        sorter: (a: any, b: any) => {},
        render: (text: any, record: { name: React.ReactNode; }) => decorateTemp(text, record),
      },
      {
        title: '报警时间',
        dataIndex: 'alarm_at',
        align: 'center',
        width: 110,
        render: (text: any, record: { name: React.ReactNode; }) => decorate(text, record),
      },
      {
        title: '生产阶段',
        dataIndex: 'periodname',
        align: 'center',
        render: (text: any, record: { name: React.ReactNode; }) => decorate(text, record),
      },
      {
        title: '负责人',
        dataIndex: 'managername',
        align: 'center',
        render: (text: any, record: { name: React.ReactNode; }) => decorate(text, record),
      },
      {
        title: '详情',
        key: 'detail',
        render: (text: any, record: { piggy_id: any; earcard: any; pigstyname: any; }) => {
          const piggyId = record.piggy_id;
          const earTag = record.earcard;
          const pigsty = record.pigstyname;
          return (
            <span>
             <Link to={`/management/piggy/temperature/curve?piggyId=${piggyId}&earTag=${earTag}&pigsty=${escape(escape(pigsty))}`}>
                <a>详情</a>
             </Link>
            </span>
          )
        },
        align: 'center',
      },
    ];

    return (
      <GridContent>
        <React.Fragment>
          <Row gutter={24}>
            <table className={styles.queryTableStyle}>
              <tbody>
              <tr>
                <td>猪只耳号:</td>
                <td><Input placeholder="请输入" className={styles.earTagQuery} allowClear onChange={eartagInputOnchange}/></td>
                <td>&nbsp;&nbsp;生产周期:</td>
                <td><Select placeholder="请选择" allowClear className={styles.periodStatusQuery} onChange={periodStatusInputOnchange}>{optionDom}</Select></td>
                <td>&nbsp;&nbsp;选择日期:</td>
                <td><RangePicker onChange={rangePickerOnchange} showTime
                                 className={styles.rangePicker}
                                 ranges={{
                                   今天: [moment().startOf('day'), moment().endOf('day')],
                                   本月: [moment().startOf('month'), moment().endOf('month')],
                                 }}
                                 disabledDate={disabledDate}
                />
                </td>
                <td>&nbsp;&nbsp;&nbsp;&nbsp;<Button type="primary" onClick={this.submit}>查询</Button></td>
              </tr>
              </tbody>
            </table>
          </Row>
          <Row className={styles.tableStyle}>
            <Table columns={columns} dataSource={sickPiggyPage} rowKey="piggy_id"
                   pagination={paginationProp}
                   onChange={this.handleTableChange}
            />
          </Row>
          <Row>
            <Modal
              bodyStyle={{ height: 400 }}
              width={1000}
              centered
              mask
              visible={this.state.visible}
              onOk={this.handleOk}
              onCancel={this.handleCancel}
              footer={null}
            >
              <Row><span className={styles.pigsty_name_padding}>
                猪舍：{this.state.pigstyName}</span></Row>
              <PigstyMap gateWayList={this.state.gatewayList} pigstyScale={this.state.pigstyScale}
                         enAbleClick={false} location={this.state.location}/>
            </Modal>
          </Row>
        </React.Fragment>
      </GridContent>
    );
  }
}

export default Monitor;
