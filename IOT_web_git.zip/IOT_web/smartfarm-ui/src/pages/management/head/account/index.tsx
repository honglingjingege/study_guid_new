import { Col, Row } from 'antd';
import React, { Component } from 'react';

import { GridContent } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { StateType } from '@/models/model';
import { Dispatch } from 'redux';

interface MonitorProps {
  home: StateType;
  dispatch: Dispatch<any>;
  loading: boolean;
}

@connect(
  ({
     home,
     loading,
   }: {
    home: StateType;
    loading: {
      models: { [key: string]: boolean };
    };
  }) => ({
    home,
    loading: loading.models.monitor,
  }),
)
class Monitor extends Component<MonitorProps> {
  componentDidMount() {
    // @ts-ignore
    const { dispatch } = this.props;
    dispatch({
      type: 'home/fetchTags1',
    });
  }

  render() {
    // const { home } = this.props;
    // const { tags } = home;
    return (
      <GridContent>
        <React.Fragment>
            <Row gutter={24}>
              <Col xl={18} lg={24} md={24} sm={24} xs={24} style={{ marginBottom: 24 }}>
erwerqwerqwer
              </Col>
            </Row>
        </React.Fragment>
      </GridContent>
    );
  }
}

export default Monitor;
