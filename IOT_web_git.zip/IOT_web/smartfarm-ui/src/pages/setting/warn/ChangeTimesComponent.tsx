import React, { Component } from 'react';
import {Input, Col, Row, Button, Tooltip, message} from 'antd';
import styles from '@/pages/setting/warn/style.less';

export interface ChangeWarnTimesProp {
  alarmInfoCount: number
  alarmWarningCount : number,
  alarmErrorCount: number,
}

export default class ChangeTimesComponent extends Component<ChangeWarnTimesProp> {
  constructor(props: ChangeWarnTimesProp) {
    super(props);
    this.state = {
      alarmInfoCount: props.alarmInfoCount,
      alarmWarningCount: props.alarmWarningCount,
      alarmErrorCount: props.alarmErrorCount,
    };
  }

  componentWillReceiveProps(nextProps:any) {
    this.setState({
      alarmInfoCount: nextProps.alarmInfoCount,
      alarmWarningCount: nextProps.alarmWarningCount,
      alarmErrorCount: nextProps.alarmErrorCount,
    });
  }

  checkNumber= (input: any) => {
    const numberReg = /^[0-9]*$/;
    if (!input.match(numberReg)) {
      message.info('请输入数字！');
      return false;
    }
    return true;
  };

  infoHandleChange= (event: { target: { value: any; }; }) => {
    if (this.checkNumber(event.target.value)) {
      this.setState({ alarmInfoCount: event.target.value });
    }
  }

  warningHandleChange= (event: { target: { value: any; }; }) => {
    this.setState({ alarmWarningCount: event.target.value });
  }

  errorHandleChange= (event: { target: { value: any; }; }) => {
    this.setState({ alarmErrorCount: event.target.value });
  }

  render() {
    // @ts-ignore
    const { alarmInfoCount, alarmWarningCount, alarmErrorCount } = this.state;
    // const infoTitle = '当满足绝对温差值的时候视为普通异常体温;普通异常报警规则：连续三次发生普通体温异常，触发报警'
    // const warnTitle = '当满足同比温差值的时候视为普通异常体温;严重异常报警规则：连续二次次发生普通体温异常，触发报警'
    // const errTitle = '当满足环比稳差值的时候视为普通异常体温;危险异常报警规则：连续一次发生普通体温异常，触发报警'
    return (
      <Row>
        <Row>
          <h3>报警标准设置</h3>
        </Row>
        <Row gutter={5} className={styles.secondBounderay}>
          <Col span={6}>
            {/* <Tooltip title={infoTitle}> */}
              普通异常连续次数
            {/* </Tooltip> */}
          </Col>
          <Col span={6}>
            <Input onChange={this.infoHandleChange} placeholder={alarmInfoCount}
                   className={styles.tempreture_tag_width}/>
          </Col>
          <Col span={3} align="right">
            <Button onClick={(event) => this.props.updateWarnTimes(this.state)}>设置</Button>
          </Col>
        </Row>
        <Row gutter={5} className={styles.secondBounderay}>
          <Col span={6}>
            {/* <Tooltip title={warnTitle}> */}
              严重异常连续次数
            {/* </Tooltip> */}
          </Col>
          <Col span={6}>
            <Input onChange={this.warningHandleChange} placeholder={alarmWarningCount}
                   className={styles.tempreture_tag_width}/>
          </Col>
          <Col span={3} align="right">
            <Button onClick={(event) => this.props.updateWarnTimes(this.state)}>设置</Button>
          </Col>
        </Row>
        <Row gutter={5} className={styles.secondBounderay}>
          <Col span={6}>
            {/* <Tooltip title={errTitle}> */}
              危险异常连续次数
            {/* </Tooltip> */}
          </Col>
          <Col span={6}>
            <Input onChange={this.errorHandleChange} placeholder={alarmErrorCount}
                   className={styles.tempreture_tag_width}/>
          </Col>
          <Col span={3} align="right">
            <Button onClick={(event) => this.props.updateWarnTimes(this.state)}>设置</Button>
          </Col>
        </Row>
      </Row>
    );
  }
}
