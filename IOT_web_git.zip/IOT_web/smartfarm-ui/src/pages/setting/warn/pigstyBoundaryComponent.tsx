import { Radio, Row } from 'antd';
import React, { Component } from 'react';
import styles from '@/pages/setting/warn/style.less';

interface PigstyBoundaryProp {
  pigstyBoundary: string
}
export default class PigstyBoundaryComp extends Component<PigstyBoundaryProp> {
  constructor(props: PigstyBoundaryProp) {
    super(props);
    this.state = {
        value: props.pigstyBoundary,
    }
  }

  componentWillReceiveProps(nextProps:any) {
      this.setState({
        value: nextProps.pigstyBoundary,
      });
  }

  onChange = (e: { target: { value: any; }; }) => {
    this.setState({
      value: e.target.value,
    });
    this.props.updatepigstyBoundary({ pigstyBoundary: e.target.value })
  };

  render() {
    // @ts-ignore
    const { value } = this.state;
    return (
      // @ts-ignore
      <Row>
        <Row>
           <h3>猪群范围定义</h3>
        </Row>
        <Row className={styles.secondBounderay}>
          <Radio.Group onChange={this.onChange} value={value}>
            <Radio value="sameGateway">相同网关下的猪群</Radio>
            <Radio disabled value="samePigsty">相同猪舍下的猪群</Radio>
          </Radio.Group>
        </Row>
      </Row>
    );
  }
}
