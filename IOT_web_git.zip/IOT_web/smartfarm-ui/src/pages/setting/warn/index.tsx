import { Button, Col, message, Row } from 'antd';
import React, { Component } from 'react';

import { GridContent } from '@ant-design/pro-layout';
import { connect } from 'dva';
import { StateType } from '@/models/settingParams';
import { Dispatch } from 'redux';
import TemperatureComponent from './TemperatureComponent';
import ChangeTimesComponent from './ChangeTimesComponent';
import CollectIntervalComponent from './CollectIntervalComponent';
import PigstyBoundaryComp from './pigstyBoundaryComponent';
import styles from './style.less';

interface MonitorProps {
  settingParams: StateType;
  dispatch: Dispatch<any>;
  loading: boolean;
}

@connect(
  ({
     settingParams,
     loading,
   }: {
    settingParams: StateType;
    loading: {
      models: { [key: string]: boolean };
    };
  }) => ({
    settingParams,
    loading: loading.models.monitor,
  }),
)
class Monitor extends Component<MonitorProps> {
  //constructor(props:MonitorProps) {
    super(props)
    // this.updateWarnTimes = this.updateWarnTimes.bind(this);
 // }

  state = {
    alarmAbsLowTempDiff: this.props.settingParams.alarmAbsLowTempDiff,
    alarmAbsHighTempDiff: this.props.settingParams.alarmAbsHighTempDiff,
    alarmDodLowTempDiff: this.props.settingParams.alarmDodLowTempDiff,
    alarmDodHighTempDiff: this.props.settingParams.alarmDodHighTempDiff,
    alarmPopLowTempDiff: this.props.settingParams.alarmPopLowTempDiff,
    alarmPopHighTempDiff: this.props.settingParams.alarmPopHighTempDiff,
    alarmInfoCount: this.props.settingParams.alarmInfoCount,
    alarmWarningCount: this.props.settingParams.alarmWarningCount,
    alarmErrorCount: this.props.settingParams.alarmErrorCount,
    reportInterval: this.props.settingParams.reportInterval,
    pigstyBoundary: this.props.settingParams.pigstyBoundary,
  }

  componentDidMount() {
    // @ts-ignore
    this.getSettingParms();
  }

  getSettingParms = () => {
    const { dispatch } = this.props;
    dispatch({
      type: 'settingParams/getSettingParams',
    });
  };

  updatepigstyBoundary = (changeValue: any) => {
    // this.setState({
    //   pigstyBoundary: changeValue.pigstyBoundary,
    // });
    this.updateParamsInterface({
      pigsty_boundary: changeValue.pigstyBoundary,
    })
  };

  updateReportdInterval = (changeValue: any) => {
    // this.setState({
    //   reportInterval: changeValue.currentInteral,
    // });
    this.updateParamsInterface({
      report_interval: changeValue.currentInteral,
    })
  };

  updateTemPeratureSetting= (changeValue: any) => {
    switch (changeValue.temperatureType) {
      case 'abs':
        // this.setState({
        //   alarmAbsLowTempDiff: changeValue.bottom,
        //   alarmAbsHighTempDiff: changeValue.top,
        // });
        this.updateParamsInterface({
          alarm_abs_low_temp_diff: changeValue.bottom,
          alarm_abs_high_temp_diff: changeValue.top,
        });
        break;
      case 'dod':
        // this.setState({
        //   alarmDodLowTempDiff: changeValue.bottom,
        //   alarmDodHighTempDiff: changeValue.top,
        // });
        this.updateParamsInterface({
          alarm_dod_low_temp_diff: changeValue.bottom,
          alarm_dod_high_temp_diff: changeValue.top,
        });
        break;
      default:
        // this.setState({
        //   alarmPopLowTempDiff: changeValue.bottom,
        //   alarmPopHighTempDiff: changeValue.top,
        // });
        this.updateParamsInterface({
          alarm_pop_low_temp_diff: changeValue.bottom,
          alarm_pop_high_temp_diff: changeValue.top,
        })
    }
  };

  updateWarnTimes= (warnTimes: any) => {
    // this.setState({
    //   alarmInfoCount: warnTimes.alarmInfoCount,
    //   alarmWarningCount: warnTimes.alarmWarningCount,
    //   alarmErrorCount: warnTimes.alarmErrorCount,
    // });

    this.updateParamsInterface({
      alarm_info_count: warnTimes.alarmInfoCount,
      alarm_warning_count: warnTimes.alarmWarningCount,
      alarm_error_count: warnTimes.alarmErrorCount,
    })
  }

  updateParamsInterface = (updateParams: any) => {
    console.log('updateParamsInterface', updateParams)
    const { dispatch } = this.props;
    dispatch({
      type: 'settingParams/updateSettingParams',
      payload: {
        settingParams: JSON.stringify(updateParams),
      },
    }).then(() => {
      const { settingParams } = this.props;
      const { diagnoseResult } = settingParams;
      if (diagnoseResult) {
        message.success('操作成功！');
      } else {
        message.success('操作失败！');
      }
      this.getSettingParms();
    })
  };

  render() {
    const { alarmAbsLowTempDiff, alarmAbsHighTempDiff, alarmDodLowTempDiff, alarmDodHighTempDiff,
            alarmPopLowTempDiff, alarmPopHighTempDiff, alarmInfoCount, alarmWarningCount,
            alarmErrorCount, reportInterval, pigstyBoundary } = this.props.settingParams;
    // console.log('settingparams', this.props.settingParams);
    return (
      <GridContent>
        <Row gutter={12}>
          <div className={styles.modelBounderay}>
            <Row>
              <h3>温差异常标准设置</h3>
            </Row>
            <Row>
              <Row className={styles.secondBounderay}>
                <TemperatureComponent
                  measures={{ top: alarmAbsHighTempDiff, bottom: alarmAbsLowTempDiff, temperatureType: 'abs' }}
                  updateTemPeratureSetting={this.updateTemPeratureSetting}/>
              </Row>
              <Row className={styles.secondBounderay}>
                <TemperatureComponent
                  measures={{ top: alarmDodHighTempDiff, bottom: alarmDodLowTempDiff, temperatureType: 'dod' }}
                  updateTemPeratureSetting={this.updateTemPeratureSetting}/>
              </Row>
              <Row className={styles.secondBounderay}>
                <TemperatureComponent
                  measures={{ top: alarmPopHighTempDiff, bottom: alarmPopLowTempDiff, temperatureType: 'pop' }}
                  updateTemPeratureSetting={this.updateTemPeratureSetting}/>
              </Row>
            </Row>
          </div>
          <div className={styles.modelBounderay}>
             <Row gutter={10}>
          <ChangeTimesComponent updateWarnTimes={this.updateWarnTimes}
                                alarmInfoCount={ alarmInfoCount }
                                alarmWarningCount={ alarmWarningCount }
                                alarmErrorCount={alarmErrorCount}
          />
        </Row>
          </div>
          <div className={styles.modelBounderay}>
            <Row gutter={10}>
            <CollectIntervalComponent updateReportdInterval={this.updateReportdInterval}
                                      interval={reportInterval}/>
          </Row>
          </div>
          <div className={styles.modelBounderay}>
          <Row gutter={10}>
            <PigstyBoundaryComp updatepigstyBoundary={this.updatepigstyBoundary}
                                pigstyBoundary={pigstyBoundary}/>
          </Row>
          </div>
        </Row>
      </GridContent>
    );
  }
}

export default Monitor;
