import React, { Component } from 'react';
import { Tag, Row, Button, Modal } from 'antd';
import styles from './style.less';

export interface CollectIntervalProp {
  interval: number
}
// interface SetCheckProp {
// //   isChecked:{
// //     currentInteral: number,
// //     localInterval: number
// //   }
// // }
/* class MyTag extends React.Component<SetCheckProp> {
  constructor(props: SetCheckProp) {
    super(props);
    this.stateChange = this.stateChange.bind(this);
    this.state = {
      currentInteral: props.isChecked.currentInteral,
      localInterval: props.isChecked.localInterval,
      unCheckedColor: '#2db7f5',
      checkedColor: '#87d068',
    }
  }

  stateChange = (localInterval:number) => {
    this.setState({
      currentInteral: localInterval,
    })
  };

  render() {
    // @ts-ignore
    const { localInterval, checkedColor, unCheckedColor } = this.state;
    // @ts-ignore
    const { currentInteral } = this.props;

    return (
      <Tag color={localInterval === currentInteral ? checkedColor : unCheckedColor}
           onClick={(event) => this.stateChange(localInterval)} >
        {localInterval}分钟
      </Tag>
    );
  }
} */

export default class CollectIntervalComponent extends Component<CollectIntervalProp> {
  constructor(props: CollectIntervalProp) {
    super(props);
    this.state = {
      currentInteral: props.interval,
      unCheckedColor: '#F0F0F0',
      checkedColor: '#8E8E8E',
      visible: false,
      localInterval: '',
    }
  }

  componentWillReceiveProps(nextProps:any) {
    if (nextProps.interval !== this.props.interval) {
      this.setState({
        currentInteral: nextProps.interval,
      });
    }
  }

  stateChange = (localInterval:number) => {
    this.setState({
      visible: true,
      localInterval,
    })
  };

  selecteCancel = e => {
    this.setState({
      visible: false,
    });
  }

  selecteOk = e => {
    // @ts-ignore
    const { localInterval } = this.state
    this.setState({
      visible: false,
      currentInteral: localInterval,
    });
    this.props.updateReportdInterval({ currentInteral: localInterval })
  }

  render() {
    const intervalParam = ['15', '30', '60', '120'];
    // @ts-ignore
    const { currentInteral, unCheckedColor, checkedColor } = this.state;
    return (
      <Row>
        <Row >
          <h3>数据采集时间间隔设置</h3>
        </Row>
        <Row className={styles.secondBounderay}>
          <Tag className={styles.intervalTag_size} color={intervalParam[0] === currentInteral ?
            checkedColor : unCheckedColor} onClick={event => this.stateChange(intervalParam[0])}>
            <h2>{intervalParam[0]}分钟</h2></Tag>
          <Tag className={styles.intervalTag_size} color={intervalParam[1] === currentInteral ?
            checkedColor : unCheckedColor} onClick={event => this.stateChange(intervalParam[1])}>
            <h2>{intervalParam[1]}分钟</h2></Tag>
          <Tag className={styles.intervalTag_size} color={intervalParam[2] === currentInteral ?
            checkedColor : unCheckedColor} onClick={event => this.stateChange(intervalParam[2])}>
            <h2>{intervalParam[2]}分钟</h2></Tag>
          <Tag className={styles.intervalTag_size} color={intervalParam[3] === currentInteral ?
            checkedColor : unCheckedColor} onClick={event => this.stateChange(intervalParam[3])}>
            <h2>{intervalParam[3]}分钟</h2></Tag>
        </Row>
        <Row>
          <Modal
            bodyStyle={{ height: 100 }}
            width={300}
            centered
            mask
            visible={this.state.visible}
            confirmLoading={false}
            onOk={this.selecteOk}
            onCancel={this.selecteCancel}
            // footer={null}
            // onCancel={ () => {
            //   this.setState({
            //     editOrdeleteGatewayVisible: false,
            //   })
            // }}
          >
            确定重新设置收集时间？
          </Modal>
        </Row>
      </Row>
    );
  }
}
