import { Button, Tag, Row, Col, Tooltip, Icon } from 'antd';
import React, { Component } from 'react';
import styles from './style.less';

export interface ChangeTemperatureProp {
  measures: {top : number, bottom: number, temperatureType: string};
}

export default class TemperatureComponent extends Component<ChangeTemperatureProp> {
  constructor(props: ChangeTemperatureProp) {
    super(props);
    this.state = {
      top: props.measures.top,
      bottom: props.measures.bottom,
      temperatureType: props.measures.temperatureType,
    };
  }

  componentWillReceiveProps(nextProps:any) {
      this.setState({
        top: nextProps.measures.top,
        bottom: nextProps.measures.bottom,
        temperatureType: nextProps.measures.temperatureType,
      });
    }

  addTopTemperature = (top: number) => {
    top = Math.round((Number(top) + 0.1) * 100) / 100;
     this.setState({ top });
     // this.props.updateTemPeratureSetting({ top, temperatureType: this.state.temperatureType});
  }

  deleTopTemperature = (top: number) => {
    top = top <= 0 ? Number(top) : Math.round((Number(top) - 0.1) * 100) / 100;
    this.setState({ top });
    // this.props.updateTemPeratureSetting({ top, temperatureType: this.state.temperatureType});
  }

  addBottomTemperature = (bottom: number) => {
    bottom = Math.round((Number(bottom) + 0.1) * 100) / 100;
    this.setState({ bottom });
    // this.props.updateTemPeratureSetting({ bottom, temperatureType: this.state.temperatureType});
  }

  deleBottomTemperature = (bottom: number) => {
    bottom = bottom <= 0 ? Number(bottom) : Math.round((Number(bottom) - 0.1) * 100) / 100;
    this.setState({ bottom });
    // this.props.updateTemPeratureSetting({ bottom, temperatureType: this.state.temperatureType});
  }

  render() {
    // @ts-ignore
    const { top, bottom, temperatureType } = this.state;
    const absTitle = '绝对温差值:单头猪只与猪舍内所有猪只的平均温度的差值。'
    const dodTitle = '同比温差值:目前时间点猪只体温和昨天相同时间点猪只体温的差值与目前时间点猪群体温和昨天猪群体温差值的差值。'
    const popTitle = '环比温差值:目前时间点猪只体温和相连的上一个时间点的猪只体温的差值与目前时间点猪群平均体温和相连的上一个时间点猪群平均体温差值的差值。'
    return (
      <Row>
        <Row>
          <Col align="left" span={2}>
            {temperatureType === 'abs' ? '绝对温差' : (temperatureType === 'dod' ? '同比温差' : '环比温差')}
            <Tooltip title={temperatureType === 'abs' ? absTitle : (temperatureType === 'dod' ? dodTitle : popTitle)}>
              &nbsp;<Icon type="question-circle" />
            </Tooltip>
          </Col>
          <Col align="center" span={5}>
            <Col align="center" span={7}>
              <Button shape="circle" icon="plus" onClick = {(event) => this.addTopTemperature(top)}/>
            </Col>
            <Col align="center" span={10}>
              <Tag  className={styles.tempreture_tag_width}><h2>{top} ℃</h2></Tag>
            </Col>
            <Col align="center" span={7}>
              <Button shape="circle" icon="minus" onClick = {(event) => this.deleTopTemperature(top)}/>
            </Col>
          </Col>
          <Col align="center" span={1}>
            <span className={styles.tempreture_tag_width}>正/负</span>
          </Col>
          <Col align="center"  span={5}>
            <Col align="center" span={7}>
              <Button shape="circle" icon="plus" onClick = {(event) => this.addBottomTemperature(bottom)}/>
            </Col>
            <Col align="center" span={10}>
              <Tag className={styles.tempreture_tag_width}><h2>{bottom} ℃</h2></Tag>
            </Col>
            <Col align="center" span={7}>
              <Button shape="circle" icon="minus" onClick = {(event) => this.deleBottomTemperature(bottom)}/>
            </Col>
          </Col>
          <Col align="right" span={2}>
            <Button
              onClick={(event) => this.props.updateTemPeratureSetting(this.state)}>设置</Button>
          </Col>
        </Row>
      </Row>
    );
  }
}
