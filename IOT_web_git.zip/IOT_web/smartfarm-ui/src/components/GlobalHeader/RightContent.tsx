import React from 'react';
import { connect } from 'dva';
// import { formatMessage } from 'umi-plugin-react/locale';
import { ConnectProps, ConnectState } from '@/models/connect';

import Avatar from './AvatarDropdown';
// import HeaderSearch from '../HeaderSearch';
import styles from './index.less';
import { Col, Row } from 'antd';

export type SiderTheme = 'light' | 'dark';
export interface GlobalHeaderRightProps extends ConnectProps {
  theme?: SiderTheme;
  layout: 'sidemenu' | 'topmenu';
}

const GlobalHeaderRight: React.SFC<GlobalHeaderRightProps> = props => {
  const { theme, layout } = props;
  let className = styles.right;

  if (theme === 'dark' && layout === 'topmenu') {
    className = `${styles.right}  ${styles.dark}`;
  }

  return (
    <Row gutter={24} className={styles.bannerRow}>
      <Col xl={2}>
        {/* banner居中对齐用 */}
      </Col>
      <Col xl={18}>
        <div className={styles.banner}>诺米（noimii）猪只体温异常报警系统</div>
      </Col>
      <Col xl={4}>
        <div className={className}>
          {/* <HeaderSearch */}
          {/*  className={`${styles.action} ${styles.search}`} */}
          {/*  placeholder={formatMessage({ */}
          {/*    id: 'component.globalHeader.search', */}
          {/*  })} */}
          {/*  dataSource={[ */}
          {/*    formatMessage({ */}
          {/*      id: 'component.globalHeader.search.example1', */}
          {/*    }), */}
          {/*    formatMessage({ */}
          {/*      id: 'component.globalHeader.search.example2', */}
          {/*    }), */}
          {/*    formatMessage({ */}
          {/*      id: 'component.globalHeader.search.example3', */}
          {/*    }), */}
          {/*  ]} */}
          {/*  onSearch={value => { */}
          {/*    console.log('input', value); */}
          {/*  }} */}
          {/*  onPressEnter={value => { */}
          {/*    console.log('enter', value); */}
          {/*  }} */}
          {/* /> */}
          <Avatar />
        </div>
      </Col>
    </Row>
  );
};

export default connect(({ settings }: ConnectState) => ({
  theme: settings.navTheme,
  layout: settings.layout,
}))(GlobalHeaderRight);
