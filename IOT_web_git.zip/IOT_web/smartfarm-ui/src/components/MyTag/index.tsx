/**
 * 全部  标签id默认-1
 */
import { Tag } from 'antd';
import React from 'react';

const { CheckableTag } = Tag;
const allTagId = -1;// ‘全部’标签的id

export interface TagsFromServerProps {
  tagsFromServer: object[];
  refreshParent: (nextSelectedTags: number[]) => void;
  style: any;
}

export class MyTags extends React.Component<TagsFromServerProps> {
  state = {
    selectedTags: [allTagId],
  };

  handleChange(tagId: never, checked: boolean) {
    // const { selectedTags } = this.state;
    // let nextSelectedTags: number[] | never[] = [];

    // if (tagId === allTagId) { // 只要选中‘全部’标签，则去掉子标签
    //   nextSelectedTags = [allTagId];
    // } else {
    //   nextSelectedTags = checked ? [...selectedTags, tagId] : selectedTags.filter(t => t !== tagId);
    //   nextSelectedTags = nextSelectedTags.filter(t => t !== allTagId);// 只要选中子标签，则去掉‘全部’标签
    //   if (nextSelectedTags.length === 0) {
    //     nextSelectedTags = [allTagId];
    //   }
    // }
    // console.log('You are interested in: ', nextSelectedTags);
    // this.setState({ selectedTags: nextSelectedTags });
    // this.props.refreshParent(nextSelectedTags);// 通知父组件

    this.setState({ selectedTags: [tagId] });
    this.props.refreshParent([tagId]);// 通知父组件
  }

  render() {
    const { selectedTags } = this.state;
    const { tagsFromServer } = this.props;
    const { style } = this.props;

    const dom = [];
    tagsFromServer.forEach(tag => {
      dom.push(<CheckableTag
        key={tag.id}
        checked={selectedTags.indexOf(tag.id) > -1}
        onChange={checked => this.handleChange(tag.id, checked)}
        style={style}
      >
        {tag.name}
      </CheckableTag>)
    })

    return (
      <div>
        {dom}
      </div>
    );
  }
}
