import { Tag } from 'antd';
import React from 'react';

const { CheckableTag } = Tag;

export interface TagsFromServerProps {
  tagsFromServer: object[];
  refreshParent: (nextSelectedTags: number) => void;
  style: {};
}

export class SingleCheckTag extends React.Component<TagsFromServerProps> {
  state = {
    selectedTags: -1,
  };

  handleChange(tagId: number, checked: boolean) {
    this.setState({ selectedTags: tagId });
    this.props.refreshParent(tagId);// 通知父组件
  }

  render() {
    const { selectedTags } = this.state;
    const { tagsFromServer } = this.props;
    const { style } = this.props;
    // this.handleChange(selectedTags, true);
    return (
      <div>
        {tagsFromServer.map(tag => (
          <CheckableTag
            key={tag.id}
            checked={selectedTags === tag.id}
            onChange={checked => this.handleChange(tag.id, checked)}
            style={style}
          >
            {tag.name}
          </CheckableTag>
        ))}
      </div>
    );
  }
}
