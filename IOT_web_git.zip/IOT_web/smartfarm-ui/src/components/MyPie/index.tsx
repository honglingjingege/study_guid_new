import React, { Component } from 'react';
import DataSet from '@antv/data-set';
import { Axis, Chart, Coord, Geom, Guide } from 'bizcharts';

export class MyPie extends Component {
  constructor(props: Readonly<{}>) {
    super(props);
    this.state = {
    }
  }

  render() {
    const { DataView } = DataSet;
    const { Html } = Guide;
    const { width } = this.props;
    const data = [
      {
        item: '疾病',
        count: this.props.data.num,
      },
      {
        item: '正常',
        count: this.props.data.sum - this.props.data.num,
      },
    ];
    const dv = new DataView();
    dv.source(data).transform({
      type: 'percent',
      field: 'count',
      dimension: 'item',
      as: 'percent',
    });
    const html = `<div style=font-size:10px;text-align: center;width: 10em;>
                ${Number(this.props.data.rate * 100).toFixed()}%</div>`;
    return (
        <Chart
          height={70}
          data={dv}
          padding={[10, 10, 10, 10]}
          width={width}
        >
          <Coord type="theta" radius={0.75} innerRadius={0.6} />
          <Axis name="percent" />
          <Guide>
            <Html
              position={['50%', '50%']}
              html={html}
            />
          </Guide>
          <Geom
            type="intervalStack"
            position="percent"
            color={['item', ['#389FFE', '#999999']]}
          >
          </Geom>
        </Chart>
    );
  }
}
