import request from '@/utils/request';

export async function getWarnPiggyNum(params: any) {
  return request('/api/warnPiggy/getWarnPiggyNum', {
    method: 'GET',
    params,
  });
}

export async function getWarnPiggyData(params: any) {
  return request('/api/warnPiggy/getTableData', {
    method: 'GET',
    params,
  });
}

export async function updateAlarmStatus(params: any) {
  return request('/api/warnPiggy/updateAlarmStatus', {
    method: 'POST',
    params,
  });
}

export async function getGatewayMapData(params: any) {
  return request('/api/warnPiggy/getGatewayMapData', {
    method: 'POST',
    params,
  });
}
