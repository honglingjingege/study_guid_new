import request from 'umi-request';

export interface LoginParamsType {
  username: string;
  password: string;
  type: string;
  mobile: string;
  captcha: string;
}

export async function fakeAccountLogin(params: LoginParamsType) {
  const formData = new FormData();
  formData.append('username', params.username);
  formData.append('password', params.password);
  formData.append('type', params.type);
  return request('/api/login', {
    method: 'POST',
    body: formData,
  });
}


// export async function fakeAccountLogin(params: LoginParamsType) {
//   return request('/api/login/account', {
//     method: 'POST',
//     data: params,
//   });
// }

export async function getFakeCaptcha(mobile: string) {
  return request(`/api/login/captcha?mobile=${mobile}`);
}

export async function fakeAccountLogout() {
  return request('/api/logout', {
    method: 'POST',
  });
}
