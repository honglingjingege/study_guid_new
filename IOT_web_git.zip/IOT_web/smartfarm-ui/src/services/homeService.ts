import request from '@/utils/request';

export async function getCardsContent(params: any) {
  return request('/api/home/getCardsContent', {
    method: 'GET',
    params,
  });
}

export async function getHomeChart(params: any) {
  return request('/api/home/getHomeChart', {
    method: 'GET',
    params,
  });
}
