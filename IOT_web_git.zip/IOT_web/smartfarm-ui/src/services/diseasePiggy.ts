import request from '@/utils/request';

export async function getQueryCondition() {
  return request('/api/diseasePiggy/getQueryCondition');
}

export async function getDiseasePiggyData(params: any) {
  return request('/api/diseasePiggy/getTableData', {
    method: 'GET',
    params,
  });
}

export async function deletePiggy(params: any) {
  return request('/api/diseasePiggy/deletePiggyAlarmStatus', {
    method: 'POST',
    params,
  });
}

export async function getUpdateCondition() {
  return request('/api/diseasePiggy/getUpdateCondition');
}

export async function savePiggy(params: any) {
  return request('/api/diseasePiggy/savePiggy', {
    method: 'POST',
    params,
  });
}

export async function getPiggyInfo(params: any) {
  return request('/api/diseasePiggy/getPiggyInfo', {
    method: 'GET',
    params,
  });
}

export async function getGatewayMapData(params: any) {
  return request('/api/diseasePiggy/getGatewayMapData', {
    method: 'GET',
    params,
  });
}
