import request from '@/utils/request';

export async function getQueryCondition() {
  return request('/api/allPiggy/getQueryCondition');
}

export async function getAllPiggyData(params: any) {
  return request('/api/allPiggy/getTableData', {
    method: 'GET',
    params,
  });
}

export async function fetchTempData(params: any) {
  return request('/api/allPiggy/fetchTempData', {
    method: 'GET',
    params,
  });
}

export async function getGatewayMapData(params: any) {
  return request('/api/allPiggy/getGatewayMapData', {
    method: 'GET',
    params,
  });
}
