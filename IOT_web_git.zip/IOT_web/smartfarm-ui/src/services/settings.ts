import request from 'umi-request';

export async function getSettingParams(): Promise<any> {
  return request('/api/settingParams/getSettingParams');
}

export async function updateSettingParams(params: any) {
  console.log('params', params)
  return request('/api/settingParams/updateSettingParams', {
    method: 'POST',
    params,
  });
}
