import request from 'umi-request';

export async function getPiggyBindGetway(): Promise<any> {
  return request('/api/allPiggy/getPiggyBindGetway');
}

export async function getPiggyBindGetwayByEarIdOrPeriod(params:any): Promise<any> {
  console.log('params', params)
  return request('/api/allPiggy/getPiggyBindGetwayByEarIdOrPeriod', {
    method: 'POST',
    params,
  });
}
