import request from 'umi-request';

export async function getEarTagAndGateway(): Promise<any> {
  return request('/api/earCardAndGateway/getEarTagAndGateway');
}
