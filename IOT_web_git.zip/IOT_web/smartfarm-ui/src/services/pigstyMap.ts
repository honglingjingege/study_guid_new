import request from 'umi-request';

export async function getPigstyMap(): Promise<any> {
  return request('/api/pigstyMap/getPigstyMap');
}
export async function getPigstyMapList(): Promise<any> {
  return request('/api/pigstyMap/getPigstyMapList');
}
export async function getPigstyList(): Promise<any> {
  return request('/api/pigstyMap/getPigstyList');
}
export async function getGatewayList(): Promise<any> {
  return request('/api/pigstyMap/getGatewayList');
}
export async function insertPigstyMap(params: any) {
  return request('/api/pigstyMap/insertPigstyMap', {
    method: 'POST',
    params,
  });
}

// export async function getGatewayListByPigstyId() {
//   return request('/api/pigstyMap/getGatewayListByPigstyId');
// }
